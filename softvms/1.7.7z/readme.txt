                              Soft VMS Win32
                             ----------------
             DreamCast Virtual Memory Unit emulator for windows

About
------
This compiled version of SoftVMS was compiled for windows 
by Atani Software in partnership with EmuCult, 
mostly because no one else wanted to do it, I guess.

-----------------------------------------------------------------
Made from the sourcecode made and distributed by Marcus Comstedt.
http://marcus.mangakai.org/dc/
-----------------------------------------------------------------

Info
-----
SoftVMS emulates the DreamCast Virtual Memory Unit (VMU) by
allowing computer users to run VMU software on the pc. It runs the VMS 
and LCD formats of VMU software.

Legal
------
EmuCult, Marcus Comstedt, and Atani software are not 
affiliated with Sega. Use this information at your own risk. 
"Sega" and "Dreamcast" are trademarks of Sega Enterprises, Ltd. 

Controls
---------
Arrow keys - up, down, left and right
M key - Mode button
Ctrl or A key- A button
Alt or B key - B button
S key - Sleep button