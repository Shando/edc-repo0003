DGen/SDL v1.33 for Windows (32 and 64 bit)

DGen is a Sega Genesis/Mega Drive emulator primarily used from the
command-line. Its configuration file (dgen.cfg) can be found in
your profile's Application Data/DGen directory, which is automatically
created the first time DGen is run.

Read dgen.1.txt for more information about the program and dgenrc.5.txt
for more information about dgen.cfg.
