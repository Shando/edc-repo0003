            Jaguar Tempest 2000 Emulator

(approximate)
Minimum Requirements: 500MHz or greater (should work with sound off and throttle)
Recommended Requirements: 1.2GHz or greater.

DirectX 9 is required. Windows XP may or may not be required.

Starscream 680x0 emulation library by Neill Corlett
(corlett@elwha.nrrc.ncsu.edu)


Keys:
----

F1 - Fullscreen toggle
F11 - Throttle toggle
O - option
P - pause (see below)
Z - A
X - B
C - C
Arrow keys
Numeric keypad (. is #)
Q - three-fingered salute to engage VLM
VLM: press Z (button A) twice to enter program mode, press O to engage
user programmable mode, then the numeric pad or numbers: first press is
bank, second press is effect in bank.

Joypads are supported.

Mouse-as-spinner mode is only loosely tested and probably not well
calibrated. Pause hits both pause keys so can be used to enable spinner
mode in game. Note that if spinner mode is enabled it is saved in the
EEPROM.



The game defaults to unthrottled operation, in which it assumes the blitter
and GPU have infinite speed. This makes Tempest 2000 run at 60fps at all
times. Throttling will take GPU and blitter into account and run more
realistically as in the real hardware. This also reduces the load on the host
CPU and will probably be required for processors under about 1.2GHz.

On very slow systems, disabling sound will also reduce processor usage - the
sound avoids stuttering by taking 'as much time as it needs' so the DSP will
eat up most of the time when throttling is on.

The emulator can yield unneeeded CPU time to the operating system. This may
cause stuttering on CPU's with dynamic clocking if the CPU ends up bouncing
between two power states. SpeedswitchXP is your friend.

Smoothing toggles between point sampling and bilinear interpolation filtering
of the upscale of the Jaguar screen. Select your preference accordingly for
chunky pixels or Telly-O-Vision.

EEPROM saves are placed in the All Users Application Data directory.

Note that save states will definitely not be compatible between versions.

In PAL mode (selected by adding -pal on the command line) you can see slightly
more of the web, but the 50Hz refresh rate will not look as smooth. The game
also feels very slightly different.


VLM Music
---------

Old method - attach a WAV file. This has no level control.

Preferred now: select 'Music input is output' from the settings menu, which will
take the currently running sound output. If there is more than one sound capture
device in the system it will offer you a choice. You may also need to double-click
the speaker icon in the taskbar, select properties/recording and map the input to
Wave or Stereo Mix (or similar using the sound card's own control).

The level will need to be adjusted to make VLM's triggers work properly - VLM
is at it's most fascinating when the levels are well balanced, and it's
particularly important for music genres like rock which are rich across the
entire spectrum. 

If you select 'Show music input' (F4) it will give a level graph, and the
input level scaling can be adjusted with the up and down keys while it is
displayed. Setting it so the peak red line tends to be around the blue guide
and rarely dramatically exceeds it should give reasonable results. You can
also use your music program's level control. This option works best on the
"Waiting for CD" screen - once VLM itself is running results will be less
consistent.

Another good option is to use Bank 3 effect 3 (swirling squares) - if this
is always very dark it's too quiet for VLM's internal triggers, while if it's
always extremely bright then it's probably too loud. A nice balance should give
excellent results.



Known / Suspected Bugs:
----------------------

This emulator only runs Tempest 2000 and the Jaguar CD-ROM BIOS VLM.

Couple of problems with the shaded part of the web, both of which exist on
other emulators as well: Thin black lines appear on left-of-centre,
exactly-horizontal strips, and the filled and line web do not exactly match
up. Probably related, probably something obscure in the GPU.

The game must be throttled to play the track bonus levels. Unless you like it tricky.

Yield mode is also frequently slightly drunken music mode.

EEPROM saving and loading is rather a bit less reliable than it should be. To be
certain of saving your keys and high scores, save state as well.

Throttled mode cannot throttle the blitter slower than one blit per frame.



Bugs that Went Away Without Being Specifically Fixed:
----------------------------------------------------

Pressing Pause works, but when Pause is pressed again the GPU and blitter
refuse to restart and so the game continues with no rendering.

On the 'game select' screen, when the game is selected the sound sometimes
makes a 'sproingle' noise along with the usual effect. There's a few of these
in different places, and it affects the bonus screen music tracks a bit too,
but this is the most obvious one. Seems to have gone now, probably down to
DSP fixes.



Kind of not bugs:
----------------

Windowed mode suffers tearing artifacts due to the lack of sync with vertical
retrace. Fullscreen should not have these, but may not be perfectly smooth if
the fullscreen refresh rate is not 60Hz or in PAL mode.



Version history
---------------

0.04: Fixed no joystick support
      Added sound capture and level meter
      More internal work for porting
0.03: Cleaned up fullscreen code a little
      Cleared all fullscreen backbuffers at init
      Added automatic resizing of window if too big for screen
      Fixed (in theory) mono and 8-bit WAV files
      Added joystick/joypad support
      Internal code cleaning in preparation for Mac/Linux ports
0.02: Fixed bug with some video cards
0.01: First release
