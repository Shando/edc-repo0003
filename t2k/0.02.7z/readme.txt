            Jaguar Tempest 2000 Emulator

(approximate)
Minimum Requirements: 500MHz or greater (should work with sound off and throttle)
Recommended Requirements: 1.2GHz or greater.

DirectX 9 is required. Windows XP may or may not be required.


Keys:
----

F1 - Fullscreen toggle
F11 - Throttle toggle
O - option
P - pause (see below)
Z - A
X - B
C - C
Arrow keys
Numeric keypad (. is #)
Q - three-fingered solute to engage VLM

Joypads are not yet supported. Mouse-as-spinner mode is only loosely tested
and probably not well calibrated. Pause hits both pause keys so can be used
to enable spinner mode in game. Note that if spinner mode is enabled it is
saved in the EEPROM.



The game defaults to unthrottled operation, in which it assumes the blitter
and GPU have infinite speed. This makes Tempest 2000 run at 60fps at all
times. Throttling will take GPU and blitter into account and run more
realistically as in the real hardware. This also reduces the load on the host
CPU and will probably be required for processors under about 1.2GHz.

On very slow systems, disabling sound will also reduce processor usage - the
sound avoids stuttering by taking 'as much time as it needs' so the DSP will
eat up most of the time when throttling is on.

The emulator can yield unneeeded CPU time to the operating system. This may
cause stuttering on CPU's with dynamic clocking if the CPU ends up bouncing
between two power states. SpeedswitchXP is your friend.

Smoothing toggles between point sampling and bilinear interpolation filtering
of the upscale of the Jaguar screen. Select your preference accordingly for
chunky pixels or Telly-O-Vision.

EEPROM saves are placed in the All Users Application Data directory.

Note that save states will definitely not be compatible between versions.

In PAL mode (selected by adding -pal on the command line) you can see slightly
more of the web, but the 50Hz refresh rate will not look as smooth. The game
also feels very slightly different.



Known / Suspected Bugs:
----------------------

This emulator only runs Tempest 2000 and the Jaguar CD-ROM BIOS VLM.

Couple of problems with the shaded part of the web, both of which exist on
other emulators as well: Thin black lines appear on left-of-centre,
exactly-horizontal strips, and the filled and line web do not exactly match
up. Probably related, probably something obscure in the GPU.

The game must be throttled to play the track bonus levels. Unless you like it tricky.

Yield mode is also frequently slightly drunken music mode.

EEPROM saving and loading is rather a bit less reliable than it should be. To be
certain of saving your keys and high scores, save state as well.

Throttled mode cannot throttle the blitter slower than one blit per frame.



Bugs that Went Away Without Being Specifically Fixed:
----------------------------------------------------

Pressing Pause works, but when Pause is pressed again the GPU and blitter
refuse to restart and so the game continues with no rendering.

On the 'game select' screen, when the game is selected the sound sometimes
makes a 'sproingle' noise along with the usual effect. There's a few of these
in different places, and it affects the bonus screen music tracks a bit too,
but this is the most obvious one. Seems to have gone now, probably down to
DSP fixes.



Kind of not bugs:
----------------

Windowed mode suffers tearing artifacts due to the lack of sync with vertical
retrace. Fullscreen should not have these, but may not be perfectly smooth if
the fullscreen refresh rate is not 60Hz or in PAL mode.



Version history
---------------

0.02: Fixed bug with some video cards
0.01: First release