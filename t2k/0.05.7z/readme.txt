            Jaguar Tempest 2000 Emulator

(approximate)
Minimum Requirements: 500MHz or greater (should work with throttle)
Recommended Requirements: 1GHz or greater.

DirectX 9 is required. Windows XP may or may not be required.

Starscream 680x0 emulation library by Neill Corlett
(corlett@elwha.nrrc.ncsu.edu)

This software also makes use of the excellent LibPNG and Zlib, both
available at Sourceforge.

THIS EMULATOR IS PROVIDED WITH NO WARRANTY, INCLUDING IMPLIED WARRANTIES,
ETC. IT IS A BETA PRODUCT THAT IS KNOWN NOT TO BE THOROUGHLY DEBUGGED, AND
IS KNOWN TO CONTAIN AT LEAST ONE BUG THAT CAN UNRECOVERABLY CRASH A SYSTEM.
YOU USE IT ENTIRELY AT YOUR OWN RISK.


URGENT WARNING: switching out of fullscreen mode sometimes crashes some
systems with a Blue Screen Of Death (or the Windows XP equivalent of the
Silent Reboot). This appears to mostly affect users of nvidia video cards,
but all users should be aware that F1 has been known to hang some systems
unrecoverably dead.

It is hoped that 0.05 has fixed this.


Keys:
----

F1 - Fullscreen toggle
F3 - Enable Music device capture
F4 - Show Music Input
F6 - Load State
F7 - Save State
F11 - Throttle toggle
F12 - Screenshot
O - option
P - pause
Z/Ctrl - A
X/ALT - B
C/Space - C
Arrow keys
Numeric keypad (. is #)
Q - three-fingered salute (used on the flashing CD with ?) to engage VLM
Esc - Quit

VLM: press Z (button A) twice to enter program mode, press O to engage
user programmable mode, then the numeric pad or numbers: first press is
bank, second press is effect in bank.

Joypads are supported.

Mouse-as-spinner mode is only loosely tested and probably not well
calibrated. Pause hits both pause keys so can be used to enable spinner
mode in game. Note that if spinner mode is enabled it is saved in the
EEPROM.





The game defaults to unthrottled operation, in which it assumes the blitter
and GPU have infinite speed. This makes Tempest 2000 run at 60fps at all
times. Throttling will take GPU and blitter into account and run more
realistically as in the real hardware. This also reduces the load on the host
CPU and will probably be required for processors under about 1GHz.

The latest version uses native sound rather than emulating the DSP under Tempest
2000. The cost of sound is well down under previous versions. Native sound can
be forced off from the menu. With throttling this should enable T2K to run even on
slow processors or in low CPU power states. It does not need to be manually disabled
on games other than Tempest 2000.

The emulator can yield unneeeded CPU time to the operating system. This may
cause stuttering on CPU's with dynamic clocking if the CPU ends up bouncing
between two power states. SpeedswitchXP is your friend.

Smoothing toggles between point sampling and bilinear interpolation filtering
of the upscale of the Jaguar screen. Select your preference accordingly for
chunky pixels or Telly-O-Vision.

EEPROM saves are placed in directory assigned in the options, which defaults to
the All Users Application Data directory (in theory, although they have been
sighted in the application directory, the rom directory, and frankly just about
anywhere else it feels like it).

Note that save states are definitely not compatible between versions.

In PAL mode (selected by adding -pal on the command line) you can see slightly
more of the web, but the 50Hz refresh rate will not look as smooth. The game
also feels very slightly different.

If you have an older DX7 card then you may find that the emulator's screen size
does not resize with the window; in this case you must use fullscreen mode. You
may find it doesn't work at all, although I hope that is no longer the case.



VLM Music
---------

Old method - attach a WAV file. This has no level control.

Preferred now: select 'Music input is output' from the settings menu, which will
take the currently running sound output. If there is more than one sound capture
device in the system it will offer you a choice. You may also need to double-click
the speaker icon in the taskbar, select properties/recording and map the input to
Wave or Stereo Mix (or similar using the sound card's own control).

The level will need to be adjusted to make VLM's triggers work properly - VLM
is at it's most fascinating when the levels are well balanced, and it's
particularly important for music genres like rock which are rich across the
entire spectrum. 

If you select 'Show music input' (F4) it will give a level graph, and the
input level scaling can be adjusted with the up and down keys while it is
displayed. Setting it so the peak red line tends to be around the blue guide
and rarely dramatically exceeds it should give reasonable results. You can
also use your music program's level control. This option works best on the
"Waiting for CD" screen - once VLM itself is running results will be less
consistent.

Another good option is to use Bank 3 effect 3 (swirling squares) - if this
is always very dark it's too quiet for VLM's internal triggers, while if it's
always extremely bright then it's probably too loud. A nice balance should give
excellent results.

VLM will happily eat up every emulated cycle most PC's can generate, and so you
may find either VLM or the music replay stuttering unless you have a very
high-spec machine. If this happens, turning on Throttle and Yield will usually
improve matters.



Known / Suspected Bugs:
----------------------

This emulator only runs Tempest 2000 and VLM, the visualiser or light synthesiser
that was part of the Jaguar CD-ROM BIOS.

Couple of problems with the shaded part of the web, both of which exist on
other emulators as well: Thin black lines appear on left-of-centre,
exactly-horizontal strips, and the filled and line web do not exactly match
up. Probably related, probably something obscure in the GPU.

The game must be throttled to play the track bonus levels. Unless you like it tricky.

Yield mode is also frequently slightly drunken music mode.

EEPROM saving and loading has previously proved a bit less reliable than it should
be, but this should be fixed with the specific setting of the eeprom save
directory.

Throttled mode cannot throttle the blitter slower than one blit per frame.

VLM bank 4 effects flicker with throttle enabled.

Dialog boxes often do not appear if the game is in fullscreen mode. If you repeatedly
close it with escape and reopen then it will usually appear after a few tries. Yes,
D3D has a flag that fixes this. No, I can't get it to work.


Kind of not bugs:
----------------

Windowed mode suffers tearing artifacts due to the lack of sync with vertical
retrace. Fullscreen should not have these, but may not be perfectly smooth if
the fullscreen refresh rate is not 60Hz or in PAL mode.



Version history
---------------

0.05: (Core)
      Blitter speed optimisations
      RISC core speed optimisations
      OP speed optimisations (contributed by Gary Liddon)
      Screen capture support
      Defender 2000 compatibility fixes (some contributed by David Bateman)
      Native sound for T2K to avoid high DSP load
      (Windows)
      Rewrote keyboard system
	  Rewrote D3D fullscreen switch - should have fixed fullscreen change crash
      Fixed D3D cards that support StretchRect but need no filter specified
      Options dialog box for configuring controls and directories
      Saves options into registry
      Avoid window shrink with repeated restart or fullscreen switch
      Made fullscreen mode select a wide ratio mode if desktop is in a widescreen mode
0.04: Fixed no joystick support
      Added sound capture and level meter
      More internal work for porting
0.03: Cleaned up fullscreen code a little
      Cleared all fullscreen backbuffers at init
      Added automatic resizing of window if too big for screen
      Fixed (in theory) mono and 8-bit WAV files
      Added joystick/joypad support
      Internal code cleaning in preparation for Mac/Linux ports
0.02: Fixed bug with some video cards
0.01: First release

