/*
 *	FM-7 EMULATOR "XM7"
 *
 *	Copyright (C) 1999-2014 �o�h�D(yasushi@tanaka.net)
 *	Copyright (C) 2001-2014 Ryu Takegami
 *	Copyright (C) 2010-2015 Toma
 *
 *	[ ���C��CPU������ ]
 */

#include <stdlib.h>
#include <string.h>
#include "xm7.h"
#include "device.h"
#include "subctrl.h"
#include "ttlpalet.h"
#include "fdc.h"
#include "mainetc.h"
#include "multipag.h"
#include "kanji.h"
#include "tapelp.h"
#include "opn.h"
#include "mmr.h"
#include "apalet.h"
#include "rs232c.h"
#ifdef MIDI
#include "midi.h"
#endif
#if XM7_VER >= 3 || (XM7_VER >= 2 && defined(JCARD) && defined(XM7DASH))
#include "jcard.h"
#endif
#if XM7_VER >= 3 || (XM7_VER == 1 && defined(SFDC) && defined(XM7DASH))
#include "dmac.h"
#endif
#ifdef JSUB
#include "jsubsys.h"
#endif
#if (XM7_VER == 1 && defined(BUBBLE))
#include "bubble.h"
#endif

/*
 *	�O���[�o�� ���[�N
 */
BYTE *mainram_a;						/* RAM (�\RAM)        $8000 */
BYTE *mainram_b;						/* RAM (��RAM+��)     $7C80 */
BYTE *basic_rom;						/* ROM (F-BASIC)      $7C00 */
BYTE *main_io;							/* ���C��CPU I/O       $100 */
BOOL basicrom_en;						/* BASIC ROM�C�l�[�u���t���O */
#if XM7_VER == 1
BYTE *basic_rom8;						/* ROM (F-BASIC V1.0) $7C00 */
BYTE *boot_bas;							/* �u�[�g(BASIC,FM-7)  $200 */
BYTE *boot_dos;							/* �u�[�g(DOS,FM-7)    $200 */
BYTE *boot_bas8;						/* �u�[�g(BASIC,FM-8)  $200 */
BYTE *boot_dos8;						/* �u�[�g(DOS,FM-8)    $200 */
BYTE *boot_bbl8;						/* �u�[�g(BUBBLE,FM-8) $200 */
#ifndef XM7DASH
BYTE *boot_bas_patch;					/* �u�[�g(BASIC,NEW7p) $200 */
#endif
BYTE *boot_mmr;							/* �u�[�g(�B��)        $200 */
#ifdef XM7DASH
BYTE *boot_1mb;							/* �u�[�g(1MBDOS,FM-77)$200 */
BYTE *boot_bbl;							/* �u�[�g(BUBBLE,FM-77)$200 */
BYTE *boot_sfd8;						/* �u�[�g(8"DOS,FM-8)  $200 */
BYTE *boot_dbg8;						/* �u�[�g(DEBUG,FM-8)  $200 */
#else
#if defined(BUBBLE)
BOOL bubble_available;					/* �o�u���g�p�\�t���O */
#endif
#endif
#endif
BYTE *boot_ram;							/* �u�[�gRAM           $200 */
BOOL bootram_rw;						/* �u�[�gRAM �������݃t���O */

BYTE *extram_a;							/* �g��RAM           $10000 */
#if XM7_VER >= 3
BYTE *extram_c;							/* AV40�g��RAM       $C0000 */
BYTE *boot_mmr;							/* �u�[�g(�B��)        $200 */
#elif XM7_VER == 1 && defined(XM7DASH)
BYTE *extram_c;							/* �g��RAM           $C0000 */
#endif

#if XM7_VER >= 2
BYTE *init_rom;							/* �C�j�V�G�[�^ROM    $2000 */
BOOL initrom_en;						/* �C�j�V�G�[�^ROM�C�l�[�u���t���O */
#endif


/*
 *	�X�^�e�B�b�N ���[�N
 */
#if XM7_VER >= 2
static BYTE *patch_branewboottfr;		/* �V�u�[�g�]���p�����ւ�BRA���� */
static BYTE *patch_jmpnewboot;			/* �V�u�[�g�ւ�JMP���� */
#endif
static BYTE ioaccess_count;				/* I/O�̈�A�N�Z�X�J�E���^ */
static BOOL ioaccess_flag;				/* I/O�A�N�Z�X�E�F�C�g�����t���O */
#if XM7_VER == 1 && defined(XM7DASH)
static BYTE *patch_bblboot8[7];
static BYTE *patch_bblboot[7];
#endif	/* XM7_VER == 1 && defined(XM7DASH) */


/*
 *	�v���g�^�C�v�錾
 */
#if XM7_VER == 1 && defined(XM7DASH)
static void FASTCALL mainmem_bubblemode_check(BYTE *patch[], BYTE *rom);
#endif	/* XM7_VER == 1 && defined(XM7DASH) */


/*
 *	���C��CPU������
 *	������
 */
BOOL FASTCALL mainmem_init(void)
{
	int i;
	BYTE *p;

	/* ��x�A�S�ăN���A */
	mainram_a = NULL;
	mainram_b = NULL;
	basic_rom = NULL;
	main_io = NULL;
	extram_a = NULL;
#if XM7_VER == 1
	boot_bas = NULL;
	boot_dos = NULL;
	boot_mmr = NULL;
#ifndef XM7DASH
	boot_bas_patch = NULL;
#endif
	boot_bas8 = NULL;
	boot_dos8 = NULL;
	boot_bbl8 = NULL;
#ifdef XM7DASH
	boot_1mb = NULL;
	boot_bbl = NULL;
	boot_sfd8 = NULL;
	boot_dbg8 = NULL;
#else
#if defined(BUBBLE)
	bubble_available = TRUE;
#endif
#endif
#else
	patch_branewboottfr = NULL;
	patch_jmpnewboot = NULL;
#if XM7_VER >= 3
	boot_mmr = NULL;
	extram_c = NULL;
#elif XM7_VER == 1 && defined(XM7DASH)
	extram_c = NULL;
#endif
	init_rom = NULL;
#endif
	boot_ram = NULL;

	/* RAM */
	mainram_a = (BYTE *)malloc(0x8000);
	if (mainram_a == NULL) {
		return FALSE;
	}
#if XM7_VER == 1
	mainram_b = (BYTE *)malloc(0x7e00);
#else
	mainram_b = (BYTE *)malloc(0x7c80);
#endif
	if (mainram_b == NULL) {
		return FALSE;
	}

	/* BASIC ROM, I/O */
	basic_rom = (BYTE *)malloc(0x7c00);
	if (basic_rom == NULL) {
		return FALSE;
	}
#if XM7_VER == 1
	basic_rom8 = (BYTE *)malloc(0x7c00);
	if (basic_rom8 == NULL) {
		return FALSE;
	}
#endif
	main_io = (BYTE *)malloc(0x0100);
	if (main_io == NULL) {
		return FALSE;
	}

	/* �g��RAM�A�C�j�V�G�[�^ROM */
#if XM7_VER >= 2
	extram_a = (BYTE *)malloc(0x10000);
	if (extram_a == NULL) {
		return FALSE;
	}
#if XM7_VER >= 3
	extram_c = (BYTE *)malloc(0xc0000);
	if (extram_c == NULL) {
		return FALSE;
	}
#endif
	init_rom = (BYTE *)malloc(0x2000);
	if (init_rom == NULL) {
		return FALSE;
	}
#else
	/* V1 (400���C���Z�b�g�C192KB) */
	extram_a = (BYTE *)malloc(0x30000);
	if (extram_a == NULL) {
		return FALSE;
	}
#ifdef XM7DASH
	extram_c = (BYTE *)malloc(0xc0000);
	if (extram_c == NULL) {
		return FALSE;
	}
#endif
#endif

	/* �u�[�gROM/RAM */
#if XM7_VER == 1
	boot_bas = (BYTE *)malloc(0x200);
	if (boot_bas == NULL) {
		return FALSE;
	}
	boot_dos = (BYTE *)malloc(0x200);
	if (boot_dos == NULL) {
		return FALSE;
	}
#ifndef XM7DASH
	boot_bas_patch = (BYTE *)malloc(0x200);
	if (boot_bas_patch == NULL) {
		return FALSE;
	}
#endif
	boot_bas8 = (BYTE *)malloc(0x200);
	if (boot_bas8 == NULL) {
		return FALSE;
	}
	boot_dos8 = (BYTE *)malloc(0x200);
	if (boot_dos8 == NULL) {
		return FALSE;
	}
	boot_bbl8 = (BYTE *)malloc(0x200);
	if (boot_bbl8 == NULL) {
		return FALSE;
	}
#ifdef XM7DASH
	boot_1mb = (BYTE *)malloc(0x200);
	if (boot_1mb == NULL) {
		return FALSE;
	}
	boot_bbl = (BYTE *)malloc(0x200);
	if (boot_bbl == NULL) {
		return FALSE;
	}
	boot_sfd8 = (BYTE *)malloc(0x200);
	if (boot_sfd8 == NULL) {
		return FALSE;
	}
	boot_dbg8 = (BYTE *)malloc(0x200);
	if (boot_dbg8 == NULL) {
		return FALSE;
	}
#endif
#endif
#if (XM7_VER == 1) || (XM7_VER >= 3)
	boot_mmr = (BYTE *)malloc(0x200);
	if (boot_mmr == NULL) {
		return FALSE;
	}
#endif
	boot_ram = (BYTE *)malloc(0x200);
	if (boot_ram == NULL) {
		return FALSE;
	}

	/* ROM�t�@�C���ǂݍ��� */
	if (!file_load(FBASIC_ROM, basic_rom, 0x7c00)) {
#if XM7_VER == 1
		available_fm7roms = FALSE;
#else
		return FALSE;
#endif
	}
#if XM7_VER == 1
	if (!file_load(FBASIC10_ROM, basic_rom8, 0x7c00)) {
		available_fm8roms = FALSE;
	}
#endif

#if XM7_VER >= 2
	if (!file_load(INITIATE_ROM, init_rom, 0x2000)) {
		return FALSE;
	}

	/* ���u�[�g�����N��(AV�V���[�Y����) */
	for (i=0; i<2; i++) {
		p = &init_rom[0x1800 + i * 0x200];
		if (p[0x14f] == 0x26) {
			p[0x14f] = 0x21;
		}
		if (p[0x153] == 0x26) {
			p[0x153] = 0x21;
		}
	}

	/* �V�u�[�g�����N���E�h���C�u�Ή��ύX�}��(AV20EX/AV40EX/AV40SX) */
	p = &init_rom[0x1c00];
	if ((p[0x8f] == 0x10) && (p[0x90] == 0x23)) {
#ifndef XM7DASH	/* �h���C�u�ύX�}���͉������Ă��� */
		p[0x8f] = 0x12;
		p[0x90] = 0x16;
#endif
		if (p[0x166] == 0x27) {
			p[0x166] = 0x21;
		}
		if (p[0x1d6] == 0x26) {
			p[0x1d6] = 0x21;
		}
	}

	/* �V�u�[�g�����N���E�h���C�u�Ή��ύX�}��(AV40/AV20) */
	if ((p[0x74] == 0x10) && (p[0x75] == 0x23)) {
#ifndef XM7DASH	/* �h���C�u�ύX�}���͉������Ă��� */
		p[0x74] = 0x12;
		p[0x75] = 0x16;
#endif
		if (p[0xf3] == 0x27) {
			p[0xf3] = 0x21;
		}
		if (p[0x196] == 0x26) {
			p[0x196] = 0x21;
		}
	}

	/* �V�u�[�g�֘A�����̃A�h���X�������E�L�� */
	for (i=0; i<0xb00; i++) {
		/* �V�u�[�g�]�������ւ�BRA���� */
		if (!patch_branewboottfr) {
			if ((init_rom[i + 0] == 0x20) && (init_rom[i + 1] == 0xd7)) {
				patch_branewboottfr = &init_rom[i];
			}
		}

		/* �V�u�[�g�ւ�JMP����(�C�j�V�G�[�^�̖����ɑ��݂���) */
		if (!patch_jmpnewboot) {
			if ((init_rom[i + 0] == 0x7e) && (init_rom[i + 1] == 0x50) &&
				(init_rom[i + 2] == 0x00)) {
				patch_jmpnewboot = &init_rom[i];
			}
		}

		/* �������������烋�[�v�𔲂��� */
		if (patch_branewboottfr && patch_jmpnewboot) {
			break;
		}
	}
#if XM7_VER >= 3
	if (!file_load(BOOTMMR_ROM, boot_mmr, 0x200)) {
		available_mmrboot = FALSE;
	}
#endif
#else
	if (!file_load(BOOTBAS_ROM, boot_bas, 0x1e0)) {
		available_fm7roms = FALSE;
	}
	if (!file_load(BOOTDOS_ROM, boot_dos, 0x1e0)) {
		available_fm7roms = FALSE;
	}
	if (!file_load(BOOTMMR_ROM, boot_mmr, 0x1e0)) {
		available_mmrboot = FALSE;
	}
	if (!file_load(BOOTBAS8_ROM, boot_bas8, 0x1e0)) {
		available_fm8roms = FALSE;
	}
	if (!file_load(BOOTDOS8_ROM, boot_dos8, 0x1e0)) {
		available_fm8roms = FALSE;
	}
#if defined(BUBBLE)
	if (!file_load(BOOTBBL8_ROM, boot_bbl8, 0x1e0)) {
#ifdef XM7DASH
		available_bblboot8 = FALSE;
#else
		bubble_available = FALSE;
#endif
	}
#endif
#ifdef XM7DASH
	if (available_bblboot8) {
		mainmem_bubblemode_check(patch_bblboot8, boot_bbl8);
	}
	if (!file_load(BOOT1MB_ROM, boot_1mb, 0x1e0)) {
		available_1mbboot = FALSE;
	}
	if (!file_load(BOOTBBL_ROM, boot_bbl, 0x1e0)) {
		available_bblboot = FALSE;
	}
	if (available_bblboot) {
		mainmem_bubblemode_check(patch_bblboot, boot_bbl);
	}
	if (!file_load(BOOTSFD8_ROM, boot_sfd8, 0x1e0)) {
		available_sfdboot8 = FALSE;
	}
	if (!file_load(BOOTDBG8_ROM, boot_dbg8, 0x1e0)) {
		available_dbgboot8 = FALSE;
	}
#endif

	/* ���u�[�g�����N��(FM-7/NEW7(1st lot)/8) */
#ifdef XM7DASH
	for (i=0; i<10; i++) {
#else
	for (i=0; i<6; i++) {
#endif
		switch (i) {
			case 0:		p = boot_bas;
						break;
			case 1:		p = boot_dos;
						break;
			case 2:		p = boot_mmr;
						break;
			case 3:		p = boot_bas8;
						break;
			case 4:		p = boot_dos8;
						break;
			case 5:		p = boot_bbl8;
						break;
#ifdef XM7DASH
			case 6:		p = boot_1mb;
						break;
			case 7:		p = boot_bbl;
						break;
			case 8:		p = boot_sfd8;
						break;
			case 9:		p = boot_dbg8;
						break;
#endif
			default:	ASSERT(FALSE);
						break;
		}

		if (p[0x14f] == 0x26) {
			p[0x14f] = 0x21;
		}
		if (p[0x153] == 0x26) {
			p[0x153] = 0x21;
		}
		if (p[0x161] == 0x26) {
			p[0x161] = 0x21;
		}
		if (p[0x155] == 0x26) {
			p[0x155] = 0x21;
		}
		if (p[0x16b] == 0x26) {
			p[0x16b] = 0x21;
		}
		if (p[0x165] == 0x26) {
			p[0x165] = 0x21;
		}
#ifndef XM7DASH	/* ��Ɣ���Ă�̂Łc */
		if (p[0x155] == 0x26) {
			p[0x155] = 0x21;
		}
#endif
		p[0x1fe] = 0xfe;
		p[0x1ff] = 0x00;
	}

#ifndef XM7DASH
	/* FM-NEW7�������b�g�̃u�[�gROM+F-BASIC V3.5�ł̃z�b�g���Z�b�g�Ώ� */
	memcpy(boot_bas_patch, boot_bas, 0x200);
	if ((boot_bas_patch[0x01d] == 0x96) && (boot_bas_patch[0x01e] == 0x0f)) {
		boot_bas_patch[0x01d] = 0x12;
		boot_bas_patch[0x01e] = 0x12;
	}
#endif
#endif

	/* �u�[�gRAM�N���A */
	/* (���_�]���΍�E���Z�b�g���ɑS�̈�����������Ȃ��Ȃ�������) */
	memset(boot_ram, 0, 0x200);

#if XM7_VER == 1
	/* FM-7/FM-8�ǂ����ROM���s���S�ȏꍇ�A���������s�Ƃ��� */
	if (!available_fm8roms && !available_fm7roms) {
		return FALSE;
	}
#endif

	return TRUE;
}

/*
 *	���C��CPU������
 *	�N���[���A�b�v
 */
void FASTCALL mainmem_cleanup(void)
{
	ASSERT(mainram_a);
	ASSERT(mainram_b);
	ASSERT(basic_rom);
	ASSERT(main_io);
	ASSERT(extram_a);
#if XM7_VER >= 3
	ASSERT(extram_c);
#elif XM7_VER == 1 && defined(XM7DASH)
	ASSERT(extram_c);
#endif
#if XM7_VER >= 2
	ASSERT(init_rom);
#endif

#if XM7_VER == 1
	ASSERT(basic_rom8);
	ASSERT(boot_bas);
	ASSERT(boot_dos);
	ASSERT(boot_bas8);
	ASSERT(boot_dos8);
	ASSERT(boot_bbl8);
#ifdef XM7DASH
	ASSERT(boot_1mb);
	ASSERT(boot_bbl);
	ASSERT(boot_sfd8);
	ASSERT(boot_dbg8);
#endif
#endif
#if (XM7_VER == 1) || (XM7_VER >= 3)
	ASSERT(boot_mmr);
#endif
	ASSERT(boot_ram);

	/* �������r���Ŏ��s�����ꍇ���l�� */
	if (mainram_a) {
		free(mainram_a);
	}
	if (mainram_b) {
		free(mainram_b);
	}
	if (basic_rom) {
		free(basic_rom);
	}
	if (main_io) {
		free(main_io);
	}

	if (extram_a) {
		free(extram_a);
	}
#if XM7_VER >= 3
	if (extram_c) {
		free(extram_c);
	}
#elif XM7_VER == 1 && defined(XM7DASH)
	if (extram_c) {
		free(extram_c);
	}
#endif
#if XM7_VER >= 2
	if (init_rom) {
		free(init_rom);
	}
#endif

#if XM7_VER == 1
	if (basic_rom8) {
		free(basic_rom8);
	}
	if (boot_bas) {
		free(boot_bas);
	}
	if (boot_dos) {
		free(boot_dos);
	}
#ifndef XM7DASH
	if (boot_bas_patch) {
		free(boot_bas_patch);
	}
#endif
	if (boot_bas8) {
		free(boot_bas8);
	}
	if (boot_dos8) {
		free(boot_dos8);
	}
	if (boot_bbl8) {
		free(boot_bbl8);
	}
#ifdef XM7DASH
	if (boot_1mb) {
		free(boot_1mb);
	}
	if (boot_bbl) {
		free(boot_bbl);
	}
	if (boot_sfd8) {
		free(boot_sfd8);
	}
	if (boot_dbg8) {
		free(boot_dbg8);
	}
#endif
#endif
#if (XM7_VER == 1) || (XM7_VER >= 3)
	if (boot_mmr) {
		free(boot_mmr);
	}
#endif
	if (boot_ram) {
		free(boot_ram);
	}
}

/*
 *	���C��CPU������
 *	���Z�b�g
 */
void FASTCALL mainmem_reset(void)
{
	/* I/O��ԁEI/O�A�N�Z�X�J�E���^������ */
	memset(main_io, 0xff, 0x0100);
	ioaccess_count = 0;
	ioaccess_flag = FALSE;

#if XM7_VER == 1 && defined(XM7DASH)
	switch (fm_subtype) {
		case FMSUB_FM8:
			if (!available_dbgboot8 &&
				boot_mode == BOOT_BASIC_RAM) {
				/* BASIC(��RAM)���[�h��BASIC���[�h�� */
				boot_mode = BOOT_BASIC;
			}
			else if (!available_bblboot8 &&
					 (boot_mode == BOOT_BUBBLE ||
					  boot_mode == BOOT_BUBBLE128)) {
				/* �o�u�����[�h��DOS���[�h�� */
				boot_mode = BOOT_DOS;
			}
			else if (!available_sfdboot8 &&
					 boot_mode == BOOT_DOS_SFD) {
				/* SFD���[�h��DOS���[�h�� */
				boot_mode = BOOT_DOS;
			}
			break;
		case FMSUB_FM7:
			if (boot_mode == BOOT_BASIC_RAM) {
				/* BASIC(��RAM)���[�h��BASIC���[�h�� */
				boot_mode = BOOT_BASIC;
			}
			else if (boot_mode != BOOT_BASIC) {
				/* BASIC���[�h�ȊO��DOS���[�h�� */
				boot_mode = BOOT_DOS;
			}
			break;
		case FMSUB_FM77:
		default:
			if (!available_bblboot &&
				(boot_mode == BOOT_BUBBLE ||
				 boot_mode == BOOT_BUBBLE128)) {
				/* �o�u�����[�h��BASIC���[�h�� */
				boot_mode = BOOT_DOS;
			}
			else if (!available_1mbboot &&
					 boot_mode == BOOT_DOS_SFD) {
				/* SFD���[�h��BASIC���[�h�� */
				boot_mode = BOOT_BASIC;
			}
			break;
	}
#endif	/* XM7_VER == 1 && defined(XM7DASH) */

	/* BASIC���[�h�ł���΁AF-BASIC ROM���C�l�[�u�� */
	if (boot_mode == BOOT_BASIC) {
		basicrom_en = TRUE;
	}
	else {
		basicrom_en = FALSE;
	}

#if XM7_VER >= 2
#if XM7_VER >= 3 && defined(XM7DASH)
	if (fm_subtype >= FMSUB_FM77AV) {
#else
	if (fm7_ver >= 2) {
#endif
		/* AV/40EX���[�h : �C�j�V�G�[�^ON�A�u�[�gRAM�������݉� */
		initrom_en = TRUE;
		bootram_rw = TRUE;
	}
	else {
		/* FM-7���[�h : �C�j�V�G�[�^OFF�A�u�[�gRAM�������݋֎~ */
		initrom_en = FALSE;
		bootram_rw = FALSE;
	}

	/* �u�[�gRAM �Z�b�g�A�b�v */
	/* ���荞�݃x�N�^�ȊO����U���ׂăN���A(���_�]���΍�) */
	memset(boot_ram, 0, 0x1f0);

	/* FM-7���[�h���ɂ̓u�[�gRAM�̓��e��]������ */
	mainmem_transfer_boot();

	/* �C�j�V�G�[�^ROM �n�[�h�E�F�A�o�[�W���� */
	switch (fm7_ver) {
		case 1:
			/* FM-7 */
			break;
		case 2:
			/* FM77AV */
			memset(&init_rom[0x0b0e], 0xff, 6);

			/* �C�j�V�G�[�^��FM77AV�����̓���ƂȂ�悤�Ƀp�b�` */
			if (patch_branewboottfr && patch_jmpnewboot) {
				patch_branewboottfr[0x0000] = 0x21;
				patch_jmpnewboot[0x0001] = 0xfe;
				patch_jmpnewboot[0x0002] = 0x00;
			}
			break;
#if XM7_VER >= 3
		case 3:
#ifdef XM7DASH
			switch (fm_subtype) {
			case FMSUB_FM77AV:
				/* FM77AV */
				memset(&init_rom[0x0b0e], 0xff, 6);
				break;

			case FMSUB_77AV20:
				/* FM77AV20 */
				init_rom[0xb0e] = '2';
				init_rom[0xb0f] = '0';
				init_rom[0xb10] = '0';
				init_rom[0xb11] = 'M';
				init_rom[0xb12] = 'a';
				init_rom[0xb13] = '.';
				break;

			case FMSUB_AV20EX:
				/* FM77AV20EX */
				init_rom[0xb0e] = '2';
				init_rom[0xb0f] = '0';
				init_rom[0xb10] = '1';
				init_rom[0xb11] = 'M';
				init_rom[0xb12] = 'a';
				init_rom[0xb13] = '.';
				break;

			case FMSUB_77AV40:
				/* FM77AV40 */
				init_rom[0xb0e] = '4';
				init_rom[0xb0f] = '0';
				init_rom[0xb10] = '0';
				init_rom[0xb11] = 'M';
				init_rom[0xb12] = 'a';
				init_rom[0xb13] = '.';
				break;

			case FMSUB_AV40EX:
				/* FM77AV40EX */
				init_rom[0xb0e] = '4';
				init_rom[0xb0f] = '0';
				init_rom[0xb10] = '1';
				init_rom[0xb11] = 'M';
				init_rom[0xb12] = 'a';
				init_rom[0xb13] = '.';
				break;

			default:
				return;
			}
#else
			/* FM77AV40EX */
			init_rom[0xb0e] = '4';
			init_rom[0xb0f] = '0';
			init_rom[0xb10] = '1';
			init_rom[0xb11] = 'M';
			init_rom[0xb12] = 'a';
			init_rom[0xb13] = '.';
#endif

#ifdef XM7DASH
			/* �C�j�V�G�[�^��FM77AV�����̓���ƂȂ�悤�Ƀp�b�` */
			if (patch_branewboottfr && patch_jmpnewboot) {
				if (fm_subtype == FMSUB_FM77AV) {
					patch_branewboottfr[0x0000] = 0x21;
					patch_jmpnewboot[0x0001] = 0xfe;
					patch_jmpnewboot[0x0002] = 0x00;
				}
				else {
					patch_branewboottfr[0x0000] = 0x20;
					patch_jmpnewboot[0x0001] = 0x50;
					patch_jmpnewboot[0x0002] = 0x00;
				}
			}
#else
			/* �C�j�V�G�[�^��FM77AV40EX�{���̓���ƂȂ�悤���ɖ߂� */
			if (patch_branewboottfr && patch_jmpnewboot) {
				patch_branewboottfr[0x0000] = 0x20;
				patch_jmpnewboot[0x0001] = 0x50;
				patch_jmpnewboot[0x0002] = 0x00;
			}
#endif
			break;
#endif
	}
#else
	/* �u�[�g�̈揑�����݋֎~ */
	bootram_rw = FALSE;
#endif
}

/*
 *	FM-7���[�h�p �u�[�gRAM�]��
 */
#if XM7_VER >= 2
void FASTCALL mainmem_transfer_boot(void)
{
#if XM7_VER >= 3 && defined(XM7DASH)
	if (fm_subtype < FMSUB_FM77AV) {
#else
	if (fm7_ver == 1) {
#endif
		if (boot_mode == BOOT_BASIC) {
			memcpy(boot_ram, &init_rom[0x1800], 0x1e0);
		}
		else {
			memcpy(boot_ram, &init_rom[0x1a00], 0x1e0);
		}
		boot_ram[0x1fe] = 0xfe;
		boot_ram[0x1ff] = 0x00;
	}
}
#endif

#if XM7_VER == 1 && defined(XM7DASH)
/*
 *	�o�u�����[�h�u�[�gROM�`�F�b�N
 */
static void FASTCALL mainmem_bubblemode_check(BYTE *patch[], BYTE *rom)
{
	int i, j, k;

	/* 32KB/128KB�o�u���J�Z�b�g�֘A�����̃A�h���X�������E�L�� */
	for (i = 0, j = 0; i < 0x1e0; i ++) {
		/* BSTAT */
		if (!patch[j]) {
			if ((rom[i + 0] == 0x96) &&
				((rom[i + 1] == 0x12) || (rom[i + 1] == 0xD2))) {
				patch[j] = &rom[i + 1];
				j++;
			}
		}
		/* BPGADH */
		if (!patch[3]) {
			if ((rom[i + 0] == 0x9F) &&
				((rom[i + 1] == 0x14) || (rom[i + 1] == 0xD4))) {
				patch[3] = &rom[i + 1];
			}
		}
		/* BPGCTH */
		if (!patch[4]) {
			if ((rom[i + 0] == 0x9F) &&
				((rom[i + 1] == 0x16) || (rom[i + 1] == 0xD6))) {
				patch[4] = &rom[i + 1];
			}
		}
		/* BCMD */
		if (!patch[5]) {
			if ((rom[i + 0] == 0x97) &&
				((rom[i + 1] == 0x11) || (rom[i + 1] == 0xD1))) {
				patch[5] = &rom[i + 1];
			}
		}
		/* BDATA */
		if (!patch[6]) {
			if ((rom[i + 0] == 0x96) &&
				((rom[i + 1] == 0x10) || (rom[i + 1] == 0xD0))) {
				patch[6] = &rom[i + 1];
			}
		}
		if ((patch[0] && patch[1] && patch[2] && patch[3] && 
			 patch[4] && patch[5] && patch[6]) || (j >= 3)) {
			break;
		}
	}
}

/*
 *	�o�u�����[�h�u�[�gROM�p�b�`
 */
void FASTCALL mainmem_bubblemode_boot(void)
{
	/* �u�[�g���[�h */
	if (boot_mode == BOOT_BUBBLE) {
		/* 32KB�o�u�����[�h */
		if (patch_bblboot8[0] && patch_bblboot8[1] && patch_bblboot8[2] &&
			patch_bblboot8[3] && patch_bblboot8[4] && patch_bblboot8[5] &&
			patch_bblboot8[6]) {
			patch_bblboot8[0][0] = 0x12;
			patch_bblboot8[1][0] = 0x12;
			patch_bblboot8[2][0] = 0x12;
			patch_bblboot8[3][0] = 0x14;
			patch_bblboot8[4][0] = 0x16;
			patch_bblboot8[5][0] = 0x11;
			patch_bblboot8[6][0] = 0x10;
		}
		if (patch_bblboot[0] && patch_bblboot[1] && patch_bblboot[2] &&
			patch_bblboot[3] && patch_bblboot[4] && patch_bblboot[5] &&
			patch_bblboot[6]) {
			patch_bblboot[0][0] = 0x12;
			patch_bblboot[1][0] = 0x12;
			patch_bblboot[2][0] = 0x12;
			patch_bblboot[3][0] = 0x14;
			patch_bblboot[4][0] = 0x16;
			patch_bblboot[5][0] = 0x11;
			patch_bblboot[6][0] = 0x10;
		}
	}
	else if (boot_mode == BOOT_BUBBLE128) {
		/* 128KB�o�u�����[�h */
		if (patch_bblboot8[0] && patch_bblboot8[1] && patch_bblboot8[2] &&
			patch_bblboot8[3] && patch_bblboot8[4] && patch_bblboot8[5] &&
			patch_bblboot8[6]) {
			patch_bblboot8[0][0] = 0xD2;
			patch_bblboot8[1][0] = 0xD2;
			patch_bblboot8[2][0] = 0xD2;
			patch_bblboot8[3][0] = 0xD4;
			patch_bblboot8[4][0] = 0xD6;
			patch_bblboot8[5][0] = 0xD1;
			patch_bblboot8[6][0] = 0xD0;
		}
		if (patch_bblboot[0] && patch_bblboot[1] && patch_bblboot[2] &&
			patch_bblboot[3] && patch_bblboot[4] && patch_bblboot[5] &&
			patch_bblboot[6]) {
			patch_bblboot[0][0] = 0xD2;
			patch_bblboot[1][0] = 0xD2;
			patch_bblboot[2][0] = 0xD2;
			patch_bblboot[3][0] = 0xD4;
			patch_bblboot[4][0] = 0xD6;
			patch_bblboot[5][0] = 0xD1;
			patch_bblboot[6][0] = 0xD0;
		}
	}
}
#endif	/* XM7_VER == 1 && defined(XM7DASH) */

/*
 *	I/O�A�N�Z�X���̃��������f�B����
 */
static void FASTCALL mainmem_iowait(void)
{
	BYTE tmp;

#if XM7_VER == 1
	/* 1.2MHz���[�h�ł�I/O�E�F�C�g��������Ȃ� */
	if (lowspeed_mode) {
		return;
	}
#endif

	/* �N���b�N�������΂��ɕK�v��I/O�A�N�Z�X�񐔂�ݒ� */
#if XM7_VER >= 3
	if ((mmr_flag || twr_flag) && !mmr_fastmode && ioaccess_flag) {
#else
	if ((mmr_flag || twr_flag) && ioaccess_flag) {
#endif
		/* MMR�I��(2���)  3��̃A�N�Z�X��1�T�C�N�� */
		tmp = 3;
	}
	else {
		/* MMR�I�t/�������[�h/MMR�I��(1���)  2��̃A�N�Z�X��1�T�C�N�� */
		tmp = 2;
	}

	/* �K��񐔈ȏ��I/O�A�N�Z�X������΁A�N���b�N���������΂� */
	ioaccess_count ++;
	if (ioaccess_count >= tmp) {
		maincpu.total ++;
		ioaccess_count = 0;

		ioaccess_flag = !ioaccess_flag;
	}
}


/*
 *	���C��CPU������
 *	�P�o�C�g�擾
 */
BYTE FASTCALL mainmem_readb(WORD addr)
{
	BYTE dat;

	/* MMR, TWR�`�F�b�N */
	if (mmr_flag || twr_flag) {
		/* MMR�ATWR��ʂ� */
		if (mmr_extrb(&addr, &dat)) {
			return dat;
		}
	}

	/* ���C��RAM(�\) */
#if XM7_VER >= 2
	if (addr < 0x6000) {
		return mainram_a[addr];
	}
	if (addr < 0x8000) {
		if (initrom_en) {
			return init_rom[addr - 0x6000];
		}
		else {
			return mainram_a[addr];
		}
	}
#else
	if (addr < 0x8000) {
		return mainram_a[addr];
	}
#endif

	/* BASIC ROM or ���C��RAM(��) */
	if (addr < 0xfc00) {
		if (basicrom_en) {
#if XM7_VER == 1
			if (fm_subtype == FMSUB_FM8) {
				return basic_rom8[addr - 0x8000];
			}
#endif
			return basic_rom[addr - 0x8000];
		}
		else {
			return mainram_b[addr - 0x8000];
		}
	}

	/* ���C��ROM�̒��� */
	if (addr < 0xfc80) {
		return mainram_b[addr - 0x8000];
	}

	/* ���LRAM */
	if (addr < 0xfd00) {
		if (subhalt_flag) {
			return shared_ram[(WORD)(addr - 0xfc80)];
		}
		else {
			return 0xff;
		}
	}

	/* �u�[�gROM/RAM */
#if XM7_VER >= 2
	if ((addr >= 0xfffe) && (initrom_en)) {
		/* ���Z�b�g�x�N�^ */
		mainmem_iowait();
		return init_rom[addr - 0xe000];
	}
#endif
	if (addr >= 0xfe00) {
		if (addr <= 0xffdf) {
			mainmem_iowait();
		}
#if XM7_VER >= 2
		return boot_ram[addr - 0xfe00];
#else
		if (((addr >= 0xffe0) && (addr < 0xfffe)) ||
			((fm_subtype == FMSUB_FM77) && bootram_rw)) {
			/* FM-77 RAM */
			return boot_ram[addr - 0xfe00];
		}
		else {
			if (fm_subtype == FMSUB_FM8) {
				/* FM-8 BOOT ROM */
				if (boot_mode == BOOT_BASIC) {
					return boot_bas8[addr - 0xfe00];
				}
				else if (boot_mode == BOOT_DOS) {
					return boot_dos8[addr - 0xfe00];
				}
#ifdef XM7DASH
				else if (boot_mode == BOOT_DOS_SFD) {
					return boot_sfd8[addr - 0xfe00];
				}
				else if (boot_mode == BOOT_BASIC_RAM) {
					return boot_dbg8[addr - 0xfe00];
				}
#endif
				else {
					return boot_bbl8[addr - 0xfe00];
				}
			}
			else {
				/* FM-7 BOOT ROM */
#ifdef XM7DASH
				if ((boot_mode == BOOT_BASIC) ||
					(boot_mode == BOOT_BASIC_RAM)) {
					return boot_bas[addr - 0xfe00];
				}
				else if ((boot_mode == BOOT_DOS)) {
					return boot_dos[addr - 0xfe00];
				}
				else if (boot_mode == BOOT_DOS_SFD) {
					return boot_1mb[addr - 0xfe00];
				}
				else {
					return boot_bbl[addr - 0xfe00];
				}
#else
				if (boot_mode == BOOT_BASIC) {
					if (fm_subtype == FMSUB_FM7) {
						return boot_bas[addr - 0xfe00];
					}
					else {
						/* FM-77���[�h���̓p�b�`�K�p�u�[�g�������� */
						return boot_bas_patch[addr - 0xfe00];
					}
				}
				else {
					return boot_dos[addr - 0xfe00];
				}
#endif
			}
		}
#endif
	}

	/*
	 *	I/O���
	 */
	mainmem_iowait();
	if (mainetc_readb(addr, &dat)) {
		return dat;
	}
	if (ttlpalet_readb(addr, &dat)) {
		return dat;
	}
	if (subctrl_readb(addr, &dat)) {
		return dat;
	}
	if (multipag_readb(addr, &dat)) {
		return dat;
	}
	if (fdc_readb(addr, &dat)) {
		return dat;
	}
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	if (ifdc_readb(addr, &dat)) {
		return dat;
	}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	if (kanji_readb(addr, &dat)) {
		return dat;
	}
	if (tapelp_readb(addr, &dat)) {
		return dat;
	}
	if (opn_readb(addr, &dat)) {
		return dat;
	}
	if (whg_readb(addr, &dat)) {
		return dat;
	}
	if (thg_readb(addr, &dat)) {
		return dat;
	}
	if (mmr_readb(addr, &dat)) {
		return dat;
	}
#if XM7_VER >= 2
	if (apalet_readb(addr, &dat)) {
		return dat;
	}
#endif
#ifdef MIDI
	if (midi_readb(addr, &dat)) {
		return dat;
	}
#endif
#ifdef RSC
	if (rs232c_readb(addr, &dat)) {
		return dat;
	}
#endif
#if XM7_VER >= 3 || (XM7_VER == 1 && defined(SFDC) && defined(XM7DASH))
	if (dmac_readb(addr, &dat)) {
		return dat;
	}
#endif
#ifdef JSUB
	if (jsub_readb(addr, &dat)) {
		return dat;
	}
#endif
#if (XM7_VER == 1 && defined(BUBBLE))
	if (bmc_readb(addr, &dat)) {
		return dat;
	}
#endif

	return 0xff;
}

/*
 *	���C��CPU������
 *	�P�o�C�g�擾(I/O�Ȃ�)
 */
BYTE FASTCALL mainmem_readbnio(WORD addr)
{
	BYTE dat;

	/* MMR, TWR�`�F�b�N */
	if (mmr_flag || twr_flag) {
		/* MMR�ATWR��ʂ� */
		if (mmr_extbnio(&addr, &dat)) {
			return dat;
		}
	}

	/* ���C��RAM(�\) */
#if XM7_VER >= 2
	if (addr < 0x6000) {
		return mainram_a[addr];
	}
	if (addr < 0x8000) {
		if (initrom_en) {
			return init_rom[addr - 0x6000];
		}
		else {
			return mainram_a[addr];
		}
	}
#else
	if (addr < 0x8000) {
		return mainram_a[addr];
	}
#endif

	/* BASIC ROM or ���C��RAM(��) */
	if (addr < 0xfc00) {
		if (basicrom_en) {
#if XM7_VER == 1
			if (fm_subtype == FMSUB_FM8) {
				return basic_rom8[addr - 0x8000];
			}
#endif
			return basic_rom[addr - 0x8000];
		}
		else {
			return mainram_b[addr - 0x8000];
		}
	}

	/* ���C��ROM�̒��� */
	if (addr < 0xfc80) {
		return mainram_b[addr - 0x8000];
	}

	/* ���LRAM */
	if (addr < 0xfd00) {
		if (subhalt_flag) {
			return shared_ram[(WORD)(addr - 0xfc80)];
		}
		else {
			return 0xff;
		}
	}

	/* �u�[�gROM/RAM */
#if XM7_VER >= 2
	if ((addr >= 0xfffe) && (initrom_en)) {
		/* ���Z�b�g�x�N�^ */
		return init_rom[addr - 0xe000];
	}
#endif
	if (addr >= 0xfe00) {
#if XM7_VER >= 2
		return boot_ram[addr - 0xfe00];
#else
		if (((addr >= 0xffe0) && (addr < 0xfffe)) ||
			((fm_subtype == FMSUB_FM77) && bootram_rw)) {
			return boot_ram[addr - 0xfe00];
		}
		else {
			if (fm_subtype == FMSUB_FM8) {
				if (boot_mode == BOOT_BASIC) {
					return boot_bas8[addr - 0xfe00];
				}
				else if (boot_mode == BOOT_DOS) {
					return boot_dos8[addr - 0xfe00];
				}
#ifdef XM7DASH
				else if (boot_mode == BOOT_DOS_SFD) {
					return boot_sfd8[addr - 0xfe00];
				}
				else if (boot_mode == BOOT_BASIC_RAM) {
					return boot_dbg8[addr - 0xfe00];
				}
#endif
				else {
					return boot_bbl8[addr - 0xfe00];
				}
			}
			else {
#ifdef XM7DASH
				if ((boot_mode == BOOT_BASIC) ||
					(boot_mode == BOOT_BASIC_RAM)) {
					return boot_bas[addr - 0xfe00];
				}
				else if ((boot_mode == BOOT_DOS)) {
					return boot_dos[addr - 0xfe00];
				}
				else if (boot_mode == BOOT_DOS_SFD) {
					return boot_1mb[addr - 0xfe00];
				}
				else {
					return boot_bbl[addr - 0xfe00];
				}
#else
				if (boot_mode == BOOT_BASIC) {
					if (fm_subtype == FMSUB_FM7) {
						return boot_bas[addr - 0xfe00];
					}
					else {
						return boot_bas_patch[addr - 0xfe00];
					}
				}
				else {
					return boot_dos[addr - 0xfe00];
				}
#endif
			}
		}
#endif
	}

	/* I/O��� */
	ASSERT((addr >= 0xfd00) && (addr < 0xfe00));
	return main_io[addr - 0xfd00];
}

/*
 *	���C��CPU������
 *	�P�o�C�g��������
 */
void FASTCALL mainmem_writeb(WORD addr, BYTE dat)
{
	/* MMR, TWR�`�F�b�N */
	if (mmr_flag || twr_flag) {
		/* MMR�ATWR��ʂ� */
		if (mmr_extwb(&addr, dat)) {
			return;
		}
	}

	/* ���C��RAM(�\) */
#if XM7_VER >= 2
	if (addr < 0x6000) {
		mainram_a[addr] = dat;
		return;
	}
	if (addr < 0x8000) {
		if (!initrom_en) {
			mainram_a[addr] = dat;
		}
		return;
	}
#else
	if (addr < 0x8000) {
		mainram_a[addr] = dat;
		return;
	}
#endif

	/* BASIC ROM or ���C��RAM(��) */
	if (addr < 0xfc00) {
		if (basicrom_en) {
			/* ROM��RCB��BIOS���Ăяo���P�[�X */
#if XM7_VER == 1 || (XM7_VER >= 3 && defined(XM7DASH))
			if (fm_subtype == FMSUB_FM7) {
#else
			if (fm7_ver == 1) {
#endif
				/* FM-7�ł�BASIC ROM�I�����ɂ���RAM�ɏ������߂�悤�Ȃ̂� */
				mainram_b[addr - 0x8000] = dat;
			}
			return;
		}
		else {
			mainram_b[addr - 0x8000] = dat;
			return;
		}
	}

	/* ���C��ROM�̒��� */
	if (addr < 0xfc80) {
		mainram_b[addr - 0x8000] = dat;
		return;
	}

	/* ���LRAM */
	if (addr < 0xfd00) {
		if (subhalt_flag) {
			shared_ram[(WORD)(addr - 0xfc80)] = dat;
			return;
		}
		else {
			/* BASE09�΍� */
			return;
		}
	}

	/* �u�[�gRAM */
	if (addr >= 0xfe00) {
#if XM7_VER >= 3 && defined(XM7DASH)
		if ((bootram_rw) && (fm_subtype >= FMSUB_FM77AV)) {
#elif XM7_VER >= 2
		if ((bootram_rw) && (fm7_ver >= 2)) {
#else
		if ((fm_subtype == FMSUB_FM77) && bootram_rw) {
#endif
			boot_ram[addr - 0xfe00] = dat;
			if ((addr <= 0xffdf) || (addr >= 0xfffe)) {
				mainmem_iowait();
			}
			return;
		}

		/* �u�[�g���[�NRAM�A�x�N�^ */
		if ((addr >= 0xffe0) && (addr < 0xfffe)) {
			boot_ram[addr - 0xfe00] = dat;
		}
		return;
	}

	/*
	 *	I/O���
	 */
	ASSERT((addr >= 0xfd00) && (addr < 0xfe00));
	main_io[(WORD)(addr - 0xfd00)] = dat;
	mainmem_iowait();

	if (mainetc_writeb(addr, dat)) {
		return;
	}
	if (ttlpalet_writeb(addr, dat)) {
		return;
	}
	if (subctrl_writeb(addr, dat)) {
		return;
	}
	if (multipag_writeb(addr, dat)) {
		return;
	}
	if (fdc_writeb(addr, dat)) {
		return;
	}
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	if (ifdc_writeb(addr, dat)) {
		return;
	}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	if (kanji_writeb(addr, dat)) {
		return;
	}
	if (tapelp_writeb(addr, dat)) {
		return;
	}
	if (opn_writeb(addr, dat)) {
		return;
	}
	if (whg_writeb(addr, dat)) {
		return;
	}
	if (thg_writeb(addr, dat)) {
		return;
	}
	if (mmr_writeb(addr, dat)) {
		return;
	}
#if XM7_VER >= 2
	if (apalet_writeb(addr, dat)) {
		return;
	}
#endif
#ifdef MIDI
	if (midi_writeb(addr, dat)) {
		return;
	}
#endif
#ifdef RSC
	if (rs232c_writeb(addr, dat)) {
		return;
	}
#endif
#if XM7_VER >= 3 || (XM7_VER == 1 && defined(SFDC) && defined(XM7DASH))
	if (dmac_writeb(addr, dat)) {
		return;
	}
#endif
#ifdef JSUB
	if (jsub_writeb(addr, dat)) {
		return;
	}
#endif
#if (XM7_VER == 1 && defined(BUBBLE))
	if (bmc_writeb(addr, dat)) {
		return;
	}
#endif

	return;
}

#ifdef XM7DASH
/*
 *	���C��CPU������
 *	�P�o�C�g�擾(I/O�Ȃ�)
 */
BYTE FASTCALL mainmem_readbsegnio(WORD addr, BYTE seg, int mode)
{
	BYTE dat;

	/* MMR�ATWR��ʂ� */
	if (mmr_extrbsegnio(&addr, &dat, seg, mode)) {
		return dat;
	}

	/* ���C��RAM(�\) */
#if XM7_VER >= 2
	if (addr < 0x6000) {
		return mainram_a[addr];
	}
	if (addr < 0x8000) {
		if (initrom_en) {
			return init_rom[addr - 0x6000];
		}
		else {
			return mainram_a[addr];
		}
	}
#else
	if (addr < 0x8000) {
		return mainram_a[addr];
	}
#endif

	/* BASIC ROM or ���C��RAM(��) */
	if (addr < 0xfc00) {
		if (basicrom_en) {
#if XM7_VER == 1
			if (fm_subtype == FMSUB_FM8) {
				return basic_rom8[addr - 0x8000];
			}
#endif
			return basic_rom[addr - 0x8000];
		}
		else {
			return mainram_b[addr - 0x8000];
		}
	}

	/* ���C��ROM�̒��� */
	if (addr < 0xfc80) {
		return mainram_b[addr - 0x8000];
	}

	/* ���LRAM */
	if (addr < 0xfd00) {
		if (subhalt_flag) {
			return shared_ram[(WORD)(addr - 0xfc80)];
		}
		else {
			return 0xff;
		}
	}

	/* �u�[�gROM/RAM */
#if XM7_VER >= 2
	if ((addr >= 0xfffe) && (initrom_en)) {
		/* ���Z�b�g�x�N�^ */
		return init_rom[addr - 0xe000];
	}
#endif
	if (addr >= 0xfe00) {
#if XM7_VER >= 2
		return boot_ram[addr - 0xfe00];
#else
		if (((addr >= 0xffe0) && (addr < 0xfffe)) ||
			((fm_subtype == FMSUB_FM77) && bootram_rw)) {
			return boot_ram[addr - 0xfe00];
		}
		else {
			if (fm_subtype == FMSUB_FM8) {
				if (boot_mode == BOOT_BASIC) {
					return boot_bas8[addr - 0xfe00];
				}
				else if (boot_mode == BOOT_DOS) {
					return boot_dos8[addr - 0xfe00];
				}
#ifdef XM7DASH
				else if (boot_mode == BOOT_DOS_SFD) {
					return boot_sfd8[addr - 0xfe00];
				}
				else if (boot_mode == BOOT_BASIC_RAM) {
					return boot_dbg8[addr - 0xfe00];
				}
#endif
				else {
					return boot_bbl8[addr - 0xfe00];
				}
			}
			else {
#ifdef XM7DASH
				if ((boot_mode == BOOT_BASIC) ||
					(boot_mode == BOOT_BASIC_RAM)) {
					return boot_bas[addr - 0xfe00];
				}
				else if ((boot_mode == BOOT_DOS)) {
					return boot_dos[addr - 0xfe00];
				}
				else if (boot_mode == BOOT_DOS_SFD) {
					return boot_1mb[addr - 0xfe00];
				}
				else {
					return boot_bbl[addr - 0xfe00];
				}
#else
				if (boot_mode == BOOT_BASIC) {
					if (fm_subtype == FMSUB_FM7) {
						return boot_bas[addr - 0xfe00];
					}
					else {
						return boot_bas_patch[addr - 0xfe00];
					}
				}
				else {
					return boot_dos[addr - 0xfe00];
				}
#endif
			}
		}
#endif
	}

	/* I/O��� */
	ASSERT((addr >= 0xfd00) && (addr < 0xfe00));
	return main_io[addr - 0xfd00];
}

/*
 *	���C��CPU������
 *	�P�o�C�g��������
 */
void FASTCALL mainmem_writebseg(WORD addr, BYTE dat, BYTE seg, int mode)
{
	/* MMR�ATWR��ʂ� */
	if (mmr_extwbseg(&addr, dat, seg, mode)) {
		return;
	}

	/* ���C��RAM(�\) */
#if XM7_VER >= 2
	if (addr < 0x6000) {
		mainram_a[addr] = dat;
		return;
	}
	if (addr < 0x8000) {
		if (!initrom_en) {
			mainram_a[addr] = dat;
		}
		return;
	}
#else
	if (addr < 0x8000) {
		mainram_a[addr] = dat;
		return;
	}
#endif

	/* BASIC ROM or ���C��RAM(��) */
	if (addr < 0xfc00) {
		if (basicrom_en) {
			/* ROM��RCB��BIOS���Ăяo���P�[�X */
			return;
		}
		else {
			mainram_b[addr - 0x8000] = dat;
			return;
		}
	}

	/* ���C��ROM�̒��� */
	if (addr < 0xfc80) {
		mainram_b[addr - 0x8000] = dat;
		return;
	}

	/* ���LRAM */
	if (addr < 0xfd00) {
		if (subhalt_flag) {
			shared_ram[(WORD)(addr - 0xfc80)] = dat;
			return;
		}
		else {
			/* BASE09�΍� */
			return;
		}
	}

	/* �u�[�gRAM */
	if (addr >= 0xfe00) {
#if XM7_VER >= 3 && defined(XM7DASH)
		if ((bootram_rw) && (fm_subtype >= FMSUB_FM77AV)) {
#elif XM7_VER >= 2
		if ((bootram_rw) && (fm7_ver >= 2)) {
#else
		if ((fm_subtype == FMSUB_FM77) && bootram_rw) {
#endif
			boot_ram[addr - 0xfe00] = dat;
			if ((addr <= 0xffdf) || (addr >= 0xfffe)) {
				mainmem_iowait();
			}
			return;
		}

		/* �u�[�g���[�NRAM�A�x�N�^ */
		if ((addr >= 0xffe0) && (addr < 0xfffe)) {
			boot_ram[addr - 0xfe00] = dat;
		}
		return;
	}

	/*
	 *	I/O���
	 */
	ASSERT((addr >= 0xfd00) && (addr < 0xfe00));
	main_io[(WORD)(addr - 0xfd00)] = dat;
	mainmem_iowait();

	if (mainetc_writeb(addr, dat)) {
		return;
	}
	if (ttlpalet_writeb(addr, dat)) {
		return;
	}
	if (subctrl_writeb(addr, dat)) {
		return;
	}
	if (multipag_writeb(addr, dat)) {
		return;
	}
	if (fdc_writeb(addr, dat)) {
		return;
	}
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	if (ifdc_writeb(addr, dat)) {
		return;
	}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	if (kanji_writeb(addr, dat)) {
		return;
	}
	if (tapelp_writeb(addr, dat)) {
		return;
	}
	if (opn_writeb(addr, dat)) {
		return;
	}
	if (whg_writeb(addr, dat)) {
		return;
	}
	if (thg_writeb(addr, dat)) {
		return;
	}
	if (mmr_writeb(addr, dat)) {
		return;
	}
#if XM7_VER >= 2
	if (apalet_writeb(addr, dat)) {
		return;
	}
#endif
#ifdef MIDI
	if (midi_writeb(addr, dat)) {
		return;
	}
#endif
#ifdef RSC
	if (rs232c_writeb(addr, dat)) {
		return;
	}
#endif
#if XM7_VER >= 3 || (XM7_VER == 1 && defined(SFDC) && defined(XM7DASH))
	if (dmac_writeb(addr, dat)) {
		return;
	}
#endif
#ifdef JSUB
	if (jsub_writeb(addr, dat)) {
		return;
	}
#endif
#if (XM7_VER == 1 && defined(BUBBLE))
	if (bmc_writeb(addr, dat)) {
		return;
	}
#endif

	return;
}
#endif

/*
 *	���C��CPU������
 *	�Z�[�u
 */
BOOL FASTCALL mainmem_save(int fileh)
{
	if (!file_write(fileh, mainram_a, 0x8000)) {
		return FALSE;
	}
#if XM7_VER == 1
	if (!file_write(fileh, mainram_b, 0x7e00)) {
#else
	if (!file_write(fileh, mainram_b, 0x7c80)) {
#endif
		return FALSE;
	}

	if (!file_write(fileh, main_io, 0x100)) {
		return FALSE;
	}

	if (!file_write(fileh, extram_a, 0x8000)) {
		return FALSE;
	}
	if (!file_write(fileh, &extram_a[0x8000], 0x8000)) {
		return FALSE;
	}
#if XM7_VER == 1
	if (!file_write(fileh, &extram_a[0x10000], 0x8000)) {
		return FALSE;
	}
	if (!file_write(fileh, &extram_a[0x18000], 0x8000)) {
		return FALSE;
	}
	if (!file_write(fileh, &extram_a[0x20000], 0x8000)) {
		return FALSE;
	}
	if (!file_write(fileh, &extram_a[0x28000], 0x8000)) {
		return FALSE;
	}
#endif
	if (!file_write(fileh, boot_ram, 0x200)) {
		return FALSE;
	}

	if (!file_bool_write(fileh, basicrom_en)) {
		return FALSE;
	}
#if XM7_VER >= 2
	if (!file_bool_write(fileh, initrom_en)) {
		return FALSE;
	}
#endif
	if (!file_bool_write(fileh, bootram_rw)) {
		return FALSE;
	}

#if XM7_VER >= 3
	/* Ver8�g�� */
	if (!file_write(fileh, &init_rom[0x0b0e], 3)) {
		return FALSE;
	}
#endif

	return TRUE;
}

/*
 *	���C��CPU������
 *	���[�h
 */
BOOL FASTCALL mainmem_load(int fileh, int ver)
{
	/* �o�[�W�����`�F�b�N */
	if (ver < 200) {
		return FALSE;
	}

	if (!file_read(fileh, mainram_a, 0x8000)) {
		return FALSE;
	}
#if XM7_VER == 1
	/* Ver302�g�� */
	if (ver <= 301) {
		if (!file_read(fileh, mainram_b, 0x7c80)) {
			return FALSE;
		}
		memset(&mainram_b[0x7c80], 0, 0x180);
	}
	else {
		if (!file_read(fileh, mainram_b, 0x7e00)) {
			return FALSE;
		}
	}
#else
	if (!file_read(fileh, mainram_b, 0x7c80)) {
		return FALSE;
	}
#endif

	if (!file_read(fileh, main_io, 0x100)) {
		return FALSE;
	}

	if (!file_read(fileh, extram_a, 0x8000)) {
		return FALSE;
	}
	if (!file_read(fileh, &extram_a[0x8000], 0x8000)) {
		return FALSE;
	}
#if XM7_VER == 1
	if (!file_read(fileh, &extram_a[0x10000], 0x8000)) {
		return FALSE;
	}
	if (!file_read(fileh, &extram_a[0x18000], 0x8000)) {
		return FALSE;
	}
	if (!file_read(fileh, &extram_a[0x20000], 0x8000)) {
		return FALSE;
	}
	if (!file_read(fileh, &extram_a[0x28000], 0x8000)) {
		return FALSE;
	}
#endif
	if (!file_read(fileh, boot_ram, 0x200)) {
		return FALSE;
	}

	if (!file_bool_read(fileh, &basicrom_en)) {
		return FALSE;
	}
#if XM7_VER >= 2
	if (!file_bool_read(fileh, &initrom_en)) {
		return FALSE;
	}
#endif
	if (!file_bool_read(fileh, &bootram_rw)) {
		return FALSE;
	}

#if XM7_VER >= 3
	/* Ver8�g�� */
	if (ver >= 800) {
		if (!file_read(fileh, &init_rom[0x0b0e], 3)) {
			return FALSE;
		}
#ifdef XM7DASH
		if (init_rom[0x0b0e] != 0xff) {
			init_rom[0x0b11] = 'M';
			init_rom[0x0b12] = 'a';
			init_rom[0x0b13] = '.';
		}
		else {
			memset(&init_rom[0x0b11], 0xff, 3);
		}
#endif
	}
#endif

#if XM7_VER == 1 && defined(XM7DASH)
	if (ver == 403) {
		if (!file_bool_read(fileh, &banksel_en)) {
			return FALSE;
		}
	}
	else {
		banksel_en = FALSE;
	}
#endif

	return TRUE;
}
