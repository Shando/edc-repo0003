/*
 *	FM-7 EMULATOR "XM7"
 *
 *	Copyright (C) 1999-2014 �o�h�D(yasushi@tanaka.net)
 *	Copyright (C) 2001-2014 Ryu Takegami
 *	Copyright (C) 2010-2015 Toma
 *
 *	[ MMR,TWR / I/O�^RAM�f�B�X�N�J�[�h ]
 */

#include <stdlib.h>
#include <string.h>
#include "xm7.h"
#include "device.h"
#include "mmr.h"
#include "subctrl.h"
#include "jcard.h"
#include "rs232c.h"

/*
 *	�O���[�o�� ���[�N
 */
BOOL mmr_flag;							/* MMR�L���t���O */
BYTE mmr_seg;							/* MMR�Z�O�����g */
BOOL mmr_modify;						/* MMR��ԕύX�t���O */
#if XM7_VER >= 3
BYTE mmr_reg[0x80];						/* MMR���W�X�^ */
BOOL twr_flag;							/* TWR�L���t���O */
BYTE twr_reg;							/* TWR���W�X�^ */
BOOL mmr_ext;							/* �g��MMR�L���t���O */
BOOL mmr_fastmode;						/* MMR�����t���O */
BOOL mmr_extram;						/* �g��RAM�L���t���O */
BOOL mmr_fast_refresh;					/* �������t���b�V���t���O */
BOOL twr_fastmode;						/* TWR�������[�h */
#else
#if XM7_VER == 1 && defined(XM7DASH)
BYTE mmr_reg[0x400];					/* MMR���W�X�^ */
BYTE mmr_extrmw;						/* �g��RAM/MMR/WBR���[�h */
#else
BYTE mmr_reg[0x40];						/* MMR���W�X�^ */
#endif
BOOL twr_flag;							/* TWR�L���t���O */
BYTE twr_reg;							/* TWR���W�X�^ */
#endif
#ifdef XM7DASH
BYTE wbr_reg;							/* WBR���W�X�^ */
BYTE bsr_reg;							/* �g��RAM�o���N�Z���N�g���W�X�^ */
#endif

/* I/O�^RAM�f�B�X�N�J�[�h */
#if XM7_VER >= 3
#ifdef MR2
BYTE mr2_nowcnt;						/* MR2 �Z�N�^�J�E���g */
WORD mr2_secreg;						/* MR2 �Z�N�^���W�X�^ */
#endif
#endif


/*
 *	MMR
 *	������
 */
BOOL FASTCALL mmr_init(void)
{
	/* ����N�����̂�MMR���N���A����悤�ɕύX */
	memset(mmr_reg, 0, sizeof(mmr_reg));

#if XM7_VER >= 3
	/* 768KB �g��RAM�J�[�h���f�B�Z�[�u�� */
	mmr_extram = FALSE;
#endif

#if XM7_VER == 1 && defined(XM7DASH)
	/* 192KB �g��RAM�J�[�h���C�l�[�u�� */
	mmr_extrmw = EXRAM_192KB;
#endif

	return TRUE;
}

/*
 *	MMR
 *	�N���[���A�b�v
 */
void FASTCALL mmr_cleanup(void)
{
}

/*
 *	MMR
 *	���Z�b�g
 */
void FASTCALL mmr_reset(void)
{
	/* MMR/TWR */
	mmr_flag = FALSE;
	twr_flag = FALSE;
	mmr_seg = 0;
	twr_reg = 0;
	mmr_modify = FALSE;

#if XM7_VER >= 3
	/* MMR/TWR(AV40�g��) */
	mmr_ext = FALSE;
	mmr_fastmode = FALSE;
	mmr_fast_refresh = FALSE;
	twr_fastmode = FALSE;

	/* I/O�^RAM�f�B�X�N */
#ifdef MR2
	mr2_nowcnt = 0;
	mr2_secreg = 0;
#endif
#endif
#ifdef XM7DASH
#if XM7_VER >= 2
	wbr_reg = 0;
#else
	wbr_reg = 2;
	bsr_reg = 2;
	if ((mmr_extrmw == EXRAM_960KB) && (init_flag)) {
		int i;
		for (i = 0; i < 16; i ++) {
			mmr_reg[i] = 0x30 | i;
		}
	}
#endif
#endif
}

/*-[ �������}�l�[�W�� ]-----------------------------------------------------*/

/*
 *	TWR�A�h���X�ϊ�
 */
static BOOL FASTCALL mmr_trans_twr(WORD addr, DWORD *taddr)
{
#if XM7_VER >= 2
	ASSERT(fm7_ver >= 2);
#else
	ASSERT(fm_subtype == FMSUB_FM77);
#endif

	/* TWR�L���� */
	if (!twr_flag) {
		return FALSE;
	}

	/* �A�h���X�v���`�F�b�N */
	if ((addr < 0x7c00) || (addr > 0x7fff)) {
		return FALSE;
	}

	/* TWR���W�X�^���ϊ� */
	*taddr = (DWORD)twr_reg;
	*taddr *= 256;
	*taddr += addr;
	*taddr &= 0xffff;
#ifdef XM7DASH
	*taddr |= (wbr_reg << 16);
#else
#if XM7_VER == 1
	/* FM-77(not AV)�̃e�L�X�g��Ԃɍ��킹�ăA�h���X��␳ */
	*taddr |= 0x20000;
#endif
#endif

	return TRUE;
}

/*
 *	MMR�A�h���X�ϊ�
 */
static DWORD FASTCALL mmr_trans_mmr(WORD addr)
{
	DWORD maddr;
	int offset;

#if XM7_VER >= 2
	ASSERT(fm7_ver >= 2);
#else
	ASSERT(fm_subtype == FMSUB_FM77);
#endif

	/* MMR�L���� */
	if (!mmr_flag) {
		return (DWORD)(0x30000 | addr);
	}

	/* MMR���W�X�^���擾 */
	offset = (int)addr;
	offset >>= 12;

#if XM7_VER >= 3
	/* �g��MMR��off�Ȃ�A�Z�O�����g��0�`3�܂� */
	if (mmr_ext) {
		offset |= (mmr_seg * 0x10);
	}
	else {
		offset |= ((mmr_seg & 0x03) * 0x10);
	}
#elif XM7_VER == 1 && defined(XM7DASH)
	/* �g��RAM/MMR/WBR��off�Ȃ�A�Z�O�����g��0�`3�܂� */
	if (mmr_extrmw == EXRAM_960KB) {
		offset |= (mmr_seg * 0x10);
	}
	else {
		offset |= ((mmr_seg & 0x03) * 0x10);
	}
#else
	offset |= ((mmr_seg & 0x03) * 0x10);
#endif

	/* �g��MMR��off�Ȃ�A6bit�̂ݗL�� */
	maddr = (DWORD)mmr_reg[offset];
#if XM7_VER >= 3
#ifdef XM7DASH
	if (!mmr_ext || (fm_subtype == FMSUB_AV20EX)) {
#else
	if (!mmr_ext) {
#endif
		maddr &= 0x3f;
	}
#elif XM7_VER == 1 && defined(XM7DASH)
	if (mmr_extrmw != EXRAM_960KB) {
		maddr &= 0x3f;
	}
#else
	maddr &= 0x3f;
#endif
	maddr <<= 12;

	/* ����12�r�b�g�ƍ��� */
	addr &= 0xfff;
	maddr |= addr;

	return maddr;
}

/*
 *	���C��CPU�o�X
 *	�P�o�C�g�ǂݏo��
 */
BOOL FASTCALL mmr_extrb(WORD *addr, BYTE *dat)
{
	DWORD raddr, rsegment;

#if XM7_VER >= 2
	ASSERT(fm7_ver >= 2);
#else
	ASSERT(fm_subtype == FMSUB_FM77);
#endif

	/* $FC00�`$FFFF�͏풓��� */
	if (*addr >= 0xfc00) {
		return FALSE;
	}

	/* TWR,MMR��ʂ� */
#ifdef FMT
	raddr = mmr_trans_twr_and_mmr(*addr);
#else
	if (!mmr_trans_twr(*addr, &raddr)) {
		raddr = mmr_trans_mmr(*addr);
	}
#endif

	rsegment = (raddr & 0xf0000);

	/* �W����� */
	if (rsegment == 0x30000) {
#if XM7_VER >= 2
		/* MMR�͍Ĕz�u�֎~ */
		if ((raddr >= 0x3fd80) && (raddr <= 0x3fd97)) {
			*dat = 0xff;
			return TRUE;
		}
#endif

#if XM7_VER == 1
		/* 0x3fc00-0x3ffff�̍Ĕz�u�ɂ�BASIC ROM or ��RAM���g�p���� */
		if (raddr >= 0x3fc00) {
			if (basicrom_en) {
				/* BASIC ROM��0x7C00�����Ȃ����� */
				if (raddr < 0x3fe00) {
					/* 00�ŕԂ� */
					*dat = 0x00;
					return TRUE;
				}
				else {
					if (available_mmrboot) {
						*dat = boot_mmr[raddr - 0x3fe00];
						return TRUE;
					}
					/* BOOTROM�ő�p */
					*dat = boot_bas[raddr - 0x3fe00];
					return TRUE;
				}
			}
			else {
				if (raddr < 0x3fe00) {
					/* ��RAM */
					*dat = mainram_b[raddr - 0x38000];
					return TRUE;
				}
				else {
					/* �u�[�gRAM */
					*dat = boot_ram[raddr - 0x3fe00];
					return TRUE;
				}
			}
		}
#endif	/* XM7_VER == 1 */

		/* $30�Z�O�����g */
		*addr = (WORD)(raddr & 0xffff);
		return FALSE;
	}

#if XM7_VER >= 2
	/* FM77AV �g��RAM */
	if (rsegment == 0x00000) {
		*dat = extram_a[raddr & 0xffff];
		return TRUE;
	}

	/* �T�u�V�X�e�� */
	if (rsegment == 0x10000) {
		if (subhalt_flag) {
			*dat = submem_readb((WORD)(raddr & 0xffff));
		}
		else {
			*dat = 0xff;
		}
		return TRUE;
	}

	/* ���{��J�[�h */
	if (rsegment == 0x20000) {
#if XM7_VER >= 3 || (XM7_VER >= 2 && defined(JCARD) && defined(XM7DASH))
		*dat = jcard_readb((WORD)(raddr & 0xffff));
#else
		*dat = 0xff;
#endif
		return TRUE;
	}

#if XM7_VER >= 3
	/* 768KB �g��RAM */
	if (rsegment >= 0x40000) {
		if (mmr_extram) {
			*dat = extram_c[raddr - 0x40000];
		}
		else {
			*dat = 0xff;
		}
		return TRUE;
	}
#endif

	return FALSE;
#else
#ifdef XM7DASH
	/* 768KB �g��RAM */
	if (rsegment >= 0x40000) {
		if (mmr_extrmw == EXRAM_960KB) {
			*dat = extram_c[raddr - 0x40000];
		}
		else {
			*dat = 0xff;
		}
		return TRUE;
	}

	/* �g��RAM������ */
	if (mmr_extrmw == EXRAM_OFF) {
		*dat = 0xff;
		return TRUE;
	}
	if (mmr_extrmw == EXRAM_64KB) {
		if (rsegment != (DWORD)(bsr_reg << 16)) {
			*dat = 0xff;
			return TRUE;
		}
		else {
			raddr &= (DWORD)0x0ffff;
			raddr |= (DWORD)0x20000;
		}
	}
#endif

	/* FM-77 �g��RAM */
	*dat = extram_a[raddr];
	return TRUE;
#endif
}

/*
 *	���C��CPU�o�X
 *	�P�o�C�g�ǂݏo��(I/O�Ȃ�)
 */
BOOL FASTCALL mmr_extbnio(WORD *addr, BYTE *dat)
{
	DWORD raddr, rsegment;

#if XM7_VER >= 2
	ASSERT(fm7_ver >= 2);
#else
	ASSERT(fm_subtype == FMSUB_FM77);
#endif

	/* $FC00�`$FFFF�͏풓��� */
	if (*addr >= 0xfc00) {
		return FALSE;
	}

	/* TWR,MMR��ʂ� */
#ifdef FMT
	raddr = mmr_trans_twr_and_mmr(*addr);
#else
	if (!mmr_trans_twr(*addr, &raddr)) {
		raddr = mmr_trans_mmr(*addr);
	}
#endif

	rsegment = (raddr & 0xf0000);

	/* �W����� */
	if (rsegment == 0x30000) {
#if XM7_VER >= 2
		/* MMR�͍Ĕz�u�֎~ */
		if ((raddr >= 0x3fd80) && (raddr <= 0x3fd97)) {
			*dat = 0xff;
			return TRUE;
		}
#endif

#if XM7_VER == 1
		/* 0x3fc00-0x3ffff�̍Ĕz�u�ɂ�BASIC ROM or ��RAM���g�p���� */
		if (raddr >= 0x3fc00) {
			if (basicrom_en) {
				/* BASIC ROM��0x7C00�����Ȃ����� */
				if (raddr < 0x3fe00) {
					/* 00�ŕԂ� */
					*dat = 0x00;
					return TRUE;
				}
				else {
					if (available_mmrboot) {
						*dat = boot_mmr[raddr - 0x3fe00];
						return TRUE;
					}
					/* BOOTROM�ő�p */
					*dat = boot_bas[raddr - 0x3fe00];
					return TRUE;
				}
			}
			else {
				if (raddr < 0x3fe00) {
					/* ��RAM */
					*dat = mainram_b[raddr - 0x38000];
					return TRUE;
				}
				else {
					/* �u�[�gRAM */
					*dat = boot_ram[raddr - 0x3fe00];
					return TRUE;
				}
			}
		}
#endif	/* XM7_VER == 1 */

		/* $30�Z�O�����g */
		*addr = (WORD)(raddr & 0xffff);
		return FALSE;
	}

#if XM7_VER >= 2
	/* FM77AV �g��RAM */
	if (rsegment == 0x00000) {
		*dat = extram_a[raddr & 0xffff];
		return TRUE;
	}

	/* �T�u�V�X�e�� */
	if (rsegment == 0x10000) {
		if (subhalt_flag) {
			*dat = submem_readbnio((WORD)(raddr & 0xffff));
		}
		else {
			*dat = 0xff;
		}
		return TRUE;
	}

	/* ���{��J�[�h */
	if (rsegment == 0x20000) {
#if XM7_VER >= 3 || (XM7_VER >= 2 && defined(JCARD) && defined(XM7DASH))
		*dat = jcard_readb((WORD)(raddr & 0xffff));
#else
		*dat = 0xff;
#endif
		return TRUE;
	}

#if XM7_VER >= 3
	/* 768KB �g��RAM */
	if (rsegment >= 0x40000) {
		if (mmr_extram) {
			*dat = extram_c[raddr - 0x40000];
		}
		else {
			*dat = 0xff;
		}
		return TRUE;
	}
#endif

	return FALSE;
#else
#ifdef XM7DASH
	/* 768KB �g��RAM */
	if (rsegment >= 0x40000) {
		if (mmr_extrmw == EXRAM_960KB) {
			*dat = extram_c[raddr - 0x40000];
		}
		else {
			*dat = 0xff;
		}
		return TRUE;
	}

	/* �g��RAM������ */
	if (mmr_extrmw == EXRAM_OFF) {
		*dat = 0xff;
		return TRUE;
	}
	if (mmr_extrmw == EXRAM_64KB) {
		if (rsegment != (DWORD)(bsr_reg << 16)) {
			*dat = 0xff;
			return TRUE;
		}
		else {
			raddr &= (DWORD)0x0ffff;
			raddr |= (DWORD)0x20000;
		}
	}
#endif

	/* FM-77 �g��RAM */
	*dat = extram_a[raddr];
	return TRUE;
#endif
}

/*
 *	���C��CPU�o�X
 *	�P�o�C�g��������
 */
BOOL FASTCALL mmr_extwb(WORD *addr, BYTE dat)
{
	DWORD raddr, rsegment;

#if XM7_VER >= 2
	ASSERT(fm7_ver >= 2);
#else
	ASSERT(fm_subtype == FMSUB_FM77);
#endif

	/* $FC00�`$FFFF�͏풓��� */
	if (*addr >= 0xfc00) {
		return FALSE;
	}

	/* TWR,MMR��ʂ� */
#ifdef FMT
	raddr = mmr_trans_twr_and_mmr(*addr);
#else
	if (!mmr_trans_twr(*addr, &raddr)) {
		raddr = mmr_trans_mmr(*addr);
	}
#endif

	rsegment = (raddr & 0xf0000);

	/* �W����� */
	if (rsegment == 0x30000) {
#if XM7_VER >= 2
		/* MMR�͍Ĕz�u�֎~ */
		if ((raddr >= 0x3fd80) && (raddr <= 0x3fd97)) {
			return TRUE;
		}
#endif

#if XM7_VER == 1
		/* 0x3fc00-0x3ffff�̍Ĕz�u�ɂ�BASIC ROM or ��RAM���g�p���� */
		if (raddr >= 0x3fc00) {
			if (basicrom_en) {
				return TRUE;
			}
			else {
				if (raddr < 0x3fe00) {
					/* ��RAM */
					mainram_b[raddr - 0x38000] = dat;
					return TRUE;
				}
				else {
					/* �u�[�gRAM */
					boot_ram[raddr - 0x3fe00] = dat;
					return TRUE;
				}
			}
		}
#endif	/* XM7_VER == 1 */

		/* $30�Z�O�����g */
		*addr = (WORD)(raddr & 0xffff);
		return FALSE;
	}

#if XM7_VER >= 2
	/* FM77AV �g��RAM */
	if (rsegment == 0x00000) {
		extram_a[raddr & 0xffff] = dat;
		return TRUE;
	}

	/* �T�u�V�X�e�� */
	if (rsegment == 0x10000) {
		if (subhalt_flag) {
			submem_writeb((WORD)(raddr & 0xffff), dat);
		}
		return TRUE;
	}

	/* ���{��J�[�h */
	if (rsegment == 0x20000) {
#if XM7_VER >= 3 || (XM7_VER >= 2 && defined(JCARD) && defined(XM7DASH))
		jcard_writeb((WORD)(raddr & 0xffff), dat);
#endif
		return TRUE;
	}

#if XM7_VER >= 3
	/* AV40�g��RAM */
	if (rsegment >= 0x40000) {
		if (mmr_extram) {
			extram_c[raddr - 0x40000] = dat;
		}
		return TRUE;
	}
#endif

	return FALSE;
#else
#ifdef XM7DASH
	/* 768KB �g��RAM */
	if (rsegment >= 0x40000) {
		if (mmr_extrmw == EXRAM_960KB) {
			extram_c[raddr - 0x40000] = dat;
		}
		return TRUE;
	}

	/* �g��RAM������ */
	if (mmr_extrmw == EXRAM_OFF) {
		return TRUE;
	}
	if (mmr_extrmw == EXRAM_64KB) {
		if (rsegment != (DWORD)(bsr_reg << 16)) {
			return TRUE;
		}
		else {
			raddr &= 0x0ffff;
			raddr |= 0x20000;
		}
	}
#endif

	/* FM-77 �g��RAM */
	extram_a[raddr] = dat;
	return TRUE;
#endif

}

#ifdef XM7DASH
/*
 *	���C�����������(���4�r�b�g�w��)
 *	�P�o�C�g�ǂݏo��(I/O�Ȃ�)
 */
BOOL FASTCALL mmr_extrbsegnio(WORD *addr, BYTE *dat, BYTE seg, int mode)
{
	DWORD raddr, rsegment;

#if XM7_VER >= 2
	ASSERT(fm7_ver >= 2);
#else
	ASSERT(fm_subtype == FMSUB_FM77);
#endif

	if (mode == 1) {
		/* ���4�r�b�g�w�蕨���A�h���X��� */
		raddr = ((seg << 16) | *addr);
	}
	else if (mode == 2) {
		int offset;

		/* $FC00�`$FFFF�͏풓��� */
		if (*addr >= 0xfc00) {
			return FALSE;
		}

		/* MMR���W�X�^���擾 */
		offset = (int)*addr;
		offset >>= 12;

#if XM7_VER >= 3
		offset |= (seg * 0x10);
#elif XM7_VER == 1 && defined(XM7DASH)
		offset |= (seg * 0x10);
#else
		offset |= ((seg & 0x03) * 0x10);
#endif

		/* �g��MMR��off�Ȃ�A6bit�̂ݗL�� */
		raddr = (DWORD)mmr_reg[offset];
#if XM7_VER >= 3
#ifdef XM7DASH
		if (!mmr_ext || (fm_subtype == FMSUB_AV20EX)) {
#else
		if (!mmr_ext) {
#endif
			raddr &= 0x3f;
		}
#elif XM7_VER == 1 && defined(XM7DASH)
		if (mmr_extrmw != EXRAM_960KB) {
			raddr &= 0x3f;
		}
#else
		raddr &= 0x3f;
#endif
		raddr <<= 12;

		/* ����12�r�b�g�ƍ��� */
		*addr &= 0xfff;
		raddr |= *addr;
	}

	rsegment = (raddr & 0xf0000);

	/* �W����� */
	if (rsegment == 0x30000) {
#if XM7_VER >= 2
		/* MMR�͍Ĕz�u�֎~ */
		if ((raddr >= 0x3fd80) && (raddr <= 0x3fd97)) {
			*dat = 0xff;
			return TRUE;
		}
#endif

#if XM7_VER == 1
		/* 0x3fc00-0x3ffff�̍Ĕz�u�ɂ�BASIC ROM or ��RAM���g�p���� */
		if (raddr >= 0x3fc00) {
			if (basicrom_en) {
				/* BASIC ROM��0x7C00�����Ȃ����� */
				if (raddr < 0x3fe00) {
					/* 00�ŕԂ� */
					*dat = 0x00;
					return TRUE;
				}
				else {
					if (available_mmrboot) {
						*dat = boot_mmr[raddr - 0x3fe00];
						return TRUE;
					}
					/* BOOTROM�ő�p */
					*dat = boot_bas[raddr - 0x3fe00];
					return TRUE;
				}
			}
			else {
				if (raddr < 0x3fe00) {
					/* ��RAM */
					*dat = mainram_b[raddr - 0x38000];
					return TRUE;
				}
				else {
					/* �u�[�gRAM */
					*dat = boot_ram[raddr - 0x3fe00];
					return TRUE;
				}
			}
		}
#endif	/* XM7_VER == 1 */

		/* $30�Z�O�����g */
		*addr = (WORD)(raddr & 0xffff);
		return FALSE;
	}

#if XM7_VER >= 2
	/* FM77AV �g��RAM */
	if (rsegment == 0x00000) {
		*dat = extram_a[raddr & 0xffff];
		return TRUE;
	}

	/* �T�u�V�X�e�� */
	if (rsegment == 0x10000) {
		if (subhalt_flag) {
			*dat = submem_readbnio((WORD)(raddr & 0xffff));
		}
		else {
			*dat = 0xff;
		}
		return TRUE;
	}

	/* ���{��J�[�h */
	if (rsegment == 0x20000) {
#if XM7_VER >= 3 || (XM7_VER >= 2 && defined(JCARD) && defined(XM7DASH))
		*dat = jcard_readb((WORD)(raddr & 0xffff));
#else
		*dat = 0xff;
#endif
		return TRUE;
	}

#if XM7_VER >= 3
	/* 768KB �g��RAM */
	if (rsegment >= 0x40000) {
		if (mmr_extram) {
			*dat = extram_c[raddr - 0x40000];
		}
		else {
			*dat = 0xff;
		}
		return TRUE;
	}
#endif

	return FALSE;
#else
#ifdef XM7DASH
	/* 768KB �g��RAM */
	if (rsegment >= 0x40000) {
		if (mmr_extrmw == EXRAM_960KB) {
			*dat = extram_c[raddr - 0x40000];
		}
		else {
			*dat = 0xff;
		}
		return TRUE;
	}

	/* �g��RAM������ */
	if (mmr_extrmw == EXRAM_OFF) {
		*dat = 0xff;
		return TRUE;
	}
	if (mmr_extrmw == EXRAM_64KB) {
		if (rsegment != (DWORD)(bsr_reg << 16)) {
			*dat = 0xff;
			return TRUE;
		}
		else {
			raddr &= (DWORD)0x0ffff;
			raddr |= (DWORD)0x20000;
		}
	}
#endif

	/* FM-77 �g��RAM */
	*dat = extram_a[raddr];
	return TRUE;
#endif
}

/*
 *	���C�����������(���4�r�b�g�w��)
 *	�P�o�C�g��������
 */
BOOL FASTCALL mmr_extwbseg(WORD *addr, BYTE dat, BYTE seg, int mode)
{
	DWORD raddr, rsegment;

#if XM7_VER >= 2
	ASSERT(fm7_ver >= 2);
#else
	ASSERT(fm_subtype == FMSUB_FM77);
#endif

	if (mode == 1) {
		/* ���4�r�b�g�w�蕨���A�h���X��� */
		raddr = ((seg << 16) | *addr);
	}
	else if (mode == 2) {
		int offset;

		/* $FC00�`$FFFF�͏풓��� */
		if (*addr >= 0xfc00) {
			return FALSE;
		}

		/* MMR���W�X�^���擾 */
		offset = (int)*addr;
		offset >>= 12;

#if XM7_VER >= 3
		offset |= (seg * 0x10);
#elif XM7_VER == 1 && defined(XM7DASH)
		offset |= (seg * 0x10);
#else
		offset |= ((seg & 0x03) * 0x10);
#endif

		/* �g��MMR��off�Ȃ�A6bit�̂ݗL�� */
		raddr = (DWORD)mmr_reg[offset];
#if XM7_VER >= 3
#ifdef XM7DASH
		if (!mmr_ext || (fm_subtype == FMSUB_AV20EX)) {
#else
		if (!mmr_ext) {
#endif
			raddr &= 0x3f;
		}
#elif XM7_VER == 1 && defined(XM7DASH)
		if (mmr_extrmw != EXRAM_960KB) {
			raddr &= 0x3f;
		}
#else
		raddr &= 0x3f;
#endif
		raddr <<= 12;

		/* ����12�r�b�g�ƍ��� */
		*addr &= 0xfff;
		raddr |= *addr;
	}

	rsegment = (raddr & 0xf0000);

	/* �W����� */
	if (rsegment == 0x30000) {
#if XM7_VER >= 2
		/* MMR�͍Ĕz�u�֎~ */
		if ((raddr >= 0x3fd80) && (raddr <= 0x3fd97)) {
			return TRUE;
		}
#endif

#if XM7_VER == 1
		/* 0x3fc00-0x3ffff�̍Ĕz�u�ɂ�BASIC ROM or ��RAM���g�p���� */
		if (raddr >= 0x3fc00) {
			if (basicrom_en) {
				return TRUE;
			}
			else {
				if (raddr < 0x3fe00) {
					/* ��RAM */
					mainram_b[raddr - 0x38000] = dat;
					return TRUE;
				}
				else {
					/* �u�[�gRAM */
					boot_ram[raddr - 0x3fe00] = dat;
					return TRUE;
				}
			}
		}
#endif	/* XM7_VER == 1 */

		/* $30�Z�O�����g */
		*addr = (WORD)(raddr & 0xffff);
		return FALSE;
	}

#if XM7_VER >= 2
	/* FM77AV �g��RAM */
	if (rsegment == 0x00000) {
		extram_a[raddr & 0xffff] = dat;
		return TRUE;
	}

	/* �T�u�V�X�e�� */
	if (rsegment == 0x10000) {
		if (subhalt_flag) {
			submem_writeb((WORD)(raddr & 0xffff), dat);
		}
		return TRUE;
	}

	/* ���{��J�[�h */
	if (rsegment == 0x20000) {
#if XM7_VER >= 3 || (XM7_VER >= 2 && defined(JCARD) && defined(XM7DASH))
		jcard_writeb((WORD)(raddr & 0xffff), dat);
#endif
		return TRUE;
	}

#if XM7_VER >= 3
	/* AV40�g��RAM */
	if (rsegment >= 0x40000) {
		if (mmr_extram) {
			extram_c[raddr - 0x40000] = dat;
		}
		return TRUE;
	}
#endif

	return FALSE;
#else
#ifdef XM7DASH
	/* 768KB �g��RAM */
	if (rsegment >= 0x40000) {
		if (mmr_extrmw == EXRAM_960KB) {
			extram_c[raddr - 0x40000] = dat;
		}
		return TRUE;
	}

	/* �g��RAM������ */
	if (mmr_extrmw == EXRAM_OFF) {
		return TRUE;
	}
	if (mmr_extrmw == EXRAM_64KB) {
		if (rsegment != (DWORD)(bsr_reg << 16)) {
			return TRUE;
		}
		else {
			raddr &= 0x0ffff;
			raddr |= 0x20000;
		}
	}
#endif

	/* FM-77 �g��RAM */
	extram_a[raddr] = dat;
	return TRUE;
#endif

}
#endif

/*-[ MR2 I/O�^RAM�f�B�X�N ]-------------------------------------------------*/

#if (XM7_VER >= 3) && defined(MR2)
/*
 *	MR2
 *	�A�h���X�v�Z
 */
static DWORD FASTCALL mr2_address(void)
{
	DWORD tmp;

	ASSERT (XM7_VER >= 3);

	if (mr2_secreg <= 0x0bff) {
		/* �v�Z���@�͓K���Ȃ̂ň���Ă���\���A��(^^; 2002/07/29 */
		tmp = (0xbff - mr2_secreg) << 8;
		tmp |= mr2_nowcnt;
	}
	else {
		tmp = 0;
	}

	return tmp;
}

/*
 *	MR2
 *	�f�[�^���[�h
 */
static BYTE FASTCALL mr2_read_data(void)
{
	BYTE dat;

	ASSERT (XM7_VER >= 3);

	/* �Z�N�^���W�X�^���ُ�̏ꍇ�͓ǂݏo���Ȃ� */
	if (mr2_secreg <= 0x0bff) {
		dat = extram_c[mr2_address()];
		mr2_nowcnt ++;
	}
	else {
		dat = 0xff;
	}

	return dat;
}

/*
 *	MR2
 *	�f�[�^���C�g
 */
static void FASTCALL mr2_write_data(BYTE dat)
{
	ASSERT (XM7_VER >= 3);

	/* �Z�N�^���W�X�^���ُ�̏ꍇ�͏������߂Ȃ� */
	if (mr2_secreg <= 0x0bff) {
		extram_c[mr2_address()] = dat;
		mr2_nowcnt ++;
	}
}

/*
 *	MR2
 *	�Z�N�^���W�X�^�X�V
 */
static void FASTCALL mr2_update_sector(WORD addr, BYTE dat)
{
	ASSERT (XM7_VER >= 3);

	/* �Z�N�^���W�X�^���X�V */
	if (addr == 0xfd9e) {
		mr2_secreg &= (WORD)0x00ff;
		mr2_secreg |= (WORD)((dat & 0x0f) << 8);
	}
	else {
		mr2_secreg &= (WORD)0x0f00;
		mr2_secreg |= (WORD)dat;
	}

	/* �͈̓`�F�b�N */
	if (mr2_secreg >= 0x0c00) {
		ASSERT(FALSE);
		mr2_secreg = 0x0c00;
	}

	/* �Z�N�^�J�E���^�����Z�b�g */
	mr2_nowcnt = 0;
}
#endif

/*-[ �������}�b�v�hI/O ]----------------------------------------------------*/

/*
 *	MMR
 *	�P�o�C�g�ǂݏo��
 */
BOOL FASTCALL mmr_readb(WORD addr, BYTE *dat)
{
	BYTE tmp;

	/* �o�[�W�����`�F�b�N */
#if XM7_VER >= 3 && defined(XM7DASH)
	if (fm_subtype < FMSUB_FM77AV) {
		return FALSE;
	}
#elif XM7_VER >= 2
	if (fm7_ver < 2) {
		return FALSE;
	}
#else
	if (fm_subtype != FMSUB_FM77) {
		return FALSE;
	}
#endif

	switch (addr) {
#if XM7_VER >= 2
		/* �u�[�g�X�e�[�^�X */
		case 0xfd0b:
			if (boot_mode == BOOT_BASIC) {
				*dat = 0xfe;
			}
			else {
				*dat = 0xff;
			}

#ifdef RSC
			/* RS-232C CD�M�� */
			if (rs_cd) {
				*dat &= (BYTE)~RSCB_CD;
			}
#endif
			return TRUE;

		/* �C�j�V�G�[�^ROM */
		case 0xfd10:
			*dat = 0xff;
			return TRUE;
#endif

#if XM7_VER == 1 && defined(XM7DASH)
		/* �g��RAM�o���N�Z���N�g */
		case 0xfd2f:
			if (mmr_extrmw == EXRAM_64KB) {
				*dat = (BYTE)(bsr_reg | 0xfc);
				return TRUE;
			}
			break;
#endif

		/* MMR�Z�O�����g */
		case 0xfd90:
			*dat = 0xff;
			return TRUE;

#if XM7_VER == 1 && defined(XM7DASH)
		/* WBR�o���N */
		case 0xfd91:
			if (mmr_extrmw == EXRAM_960KB) {
				*dat = 0xff;
				return TRUE;
			}
			break;
#endif

		/* TWR�I�t�Z�b�g */
		case 0xfd92:
			*dat = 0xff;
			return TRUE;

		/* ���[�h�Z���N�g */
		case 0xfd93:
			tmp = 0xff;
			if (!mmr_flag) {
				tmp &= (BYTE)(~0x80);
			}
			if (!twr_flag) {
				tmp &= ~0x40;
			}
			if (!bootram_rw) {
				tmp &= ~1;
			}
			*dat = tmp;
			return TRUE;

#if XM7_VER >= 3
		/* �g��MMR/CPU�X�s�[�h */
		case 0xfd94:
			*dat = 0xff;
			return TRUE;

		/* ���[�h�Z���N�g�Q */
		case 0xfd95:
			tmp = 0xff;
#ifdef XM7DASH
			if (fm_subtype >= FMSUB_AV20EX) {
#else	/* XM7_VER >= 3 && defined(XM7DASH) */
			if (fm7_ver >= 3) {
#endif	/* XM7_VER >= 3 && defined(XM7DASH) */
				/* bit7:�g��ROM�Z���N�g */
				if (extrom_sel) {
					tmp &= (BYTE)~0x80;
				}
#ifdef XM7DASH
				/* AV20EX/AV40EX�̂� */
				if ((fm_subtype == FMSUB_AV20EX) ||
					(fm_subtype == FMSUB_AV40EX)) {
					/* bit4:MMR�g�p���̑��x�ቺ��}�~ */
					if (!mmr_fastmode) {
						tmp &= (BYTE)~0x08;
					}
				}
#else
				/* bit4:MMR�g�p���̑��x�ቺ��}�~ */
				if (!mmr_fastmode) {
					tmp &= (BYTE)~0x08;
				}
#endif
				/* bit0:400���C���^�C�~���O�o�̓X�e�[�^�X */
				/*      XM7�ł�1(200���C���o��)�Œ� */
			}

			*dat = tmp;
			return TRUE;

#ifdef MR2
		/* MR2 �f�[�^���W�X�^ */
		case 0xfd9c:
			if (mmr_extram) {
				*dat = mr2_read_data();
			}
			else {
				*dat = 0xff;
			}
			return TRUE;

		/* MR2 �Z�N�^���W�X�^(Write Only) */
		case 0xfd9e:
		case 0xfd9f:
			*dat = 0xff;
			return TRUE;
#endif
#endif
	}

	/* MMR���W�X�^ */
	if ((addr >= 0xfd80) && (addr <= 0xfd8f)) {
#if XM7_VER >= 3
		if (mmr_ext) {
			tmp = mmr_reg[mmr_seg * 0x10 + (addr - 0xfd80)];
		}
		else {
			tmp = mmr_reg[(mmr_seg & 3) * 0x10 + (addr - 0xfd80)];
			/* tmp &= 0x3f; */
		}
#elif XM7_VER == 1 && defined(XM7DASH)
		if (mmr_extrmw == EXRAM_960KB) {
			tmp = mmr_reg[mmr_seg * 0x10 + (addr - 0xfd80)];
		}
		else {
			tmp = mmr_reg[(mmr_seg & 3) * 0x10 + (addr - 0xfd80)];
			/* tmp &= 0x3f; */
		}
#else
		tmp = mmr_reg[(mmr_seg & 3) * 0x10 + (addr - 0xfd80)];
		/* tmp &= 0x3f; */
#endif
		*dat = tmp;
		return TRUE;
	}

	return FALSE;
}

/*
 *	MMR
 *	�P�o�C�g��������
 */
BOOL FASTCALL mmr_writeb(WORD addr, BYTE dat)
{
	/* �o�[�W�����`�F�b�N */
#if XM7_VER >= 3 && defined(XM7DASH)
	if (fm_subtype < FMSUB_FM77AV) {
		return FALSE;
	}
#elif XM7_VER >= 2
	if (fm7_ver < 2) {
		return FALSE;
	}
#else
	if (fm_subtype != FMSUB_FM77) {
		return FALSE;
	}
#endif

	switch (addr) {
		/* �C�j�V�G�[�^ROM */
#if XM7_VER >= 2
		case 0xfd10:
			if (dat & 0x02) {
				initrom_en = FALSE;
			}
			else {
				initrom_en = TRUE;
			}
			return TRUE;
#endif

#if XM7_VER == 1 && defined(XM7DASH)
		/* �g��RAM�o���N�Z���N�g */
		case 0xfd2f:
			if (mmr_extrmw == EXRAM_64KB) {
				bsr_reg = (BYTE)(dat & 0x03);
				return TRUE;
			}
			break;
#endif

		/* MMR�Z�O�����g */
		case 0xfd90:
#if XM7_VER == 1 && defined(XM7DASH)
			mmr_seg = (BYTE)(dat & 0x3f);
#else
			mmr_seg = (BYTE)(dat & 0x07);
#endif
			return TRUE;

#if XM7_VER == 1 && defined(XM7DASH)
		/* WBR�o���N */
		case 0xfd91:
			if (mmr_extrmw == EXRAM_960KB) {
				wbr_reg = (BYTE)(dat & 0x0f);
				return TRUE;
			}
			break;
#endif

		/* TWR�I�t�Z�b�g */
		case 0xfd92:
			twr_reg = dat;
			return TRUE;

		/* ���[�h�Z���N�g */
		case 0xfd93:
			if (dat & 0x80) {
				if (!mmr_flag) {
					mmr_flag = TRUE;
#if XM7_VER >= 3
					if (!mmr_fastmode) {
						mmr_modify = TRUE;
					}
#else
					mmr_modify = TRUE;
#endif
				}
			}
			else {
				if (mmr_flag) {
					mmr_flag = FALSE;
#if XM7_VER >= 3
					if (!mmr_fastmode) {
						mmr_modify = TRUE;
					}
#else
					mmr_modify = TRUE;
#endif
				}
			}
			if (dat & 0x40) {
				if (!twr_flag) {
					twr_flag = TRUE;
#if XM7_VER >= 3
					if (!mmr_fastmode) {
						mmr_modify = TRUE;
					}
#else
					mmr_modify = TRUE;
#endif
				}
			}
			else {
				if (twr_flag) {
					twr_flag = FALSE;
#if XM7_VER >= 3
					if (!mmr_fastmode) {
						mmr_modify = TRUE;
					}
#else
					mmr_modify = TRUE;
#endif
				}
			}
			if (dat & 0x01) {
				bootram_rw = TRUE;
			}
			else {
				bootram_rw = FALSE;
			}
			return TRUE;

#if XM7_VER >= 3
		/* �g��MMR/CPU�X�s�[�h */
		case 0xfd94:
			if (fm7_ver >= 3) {
				/* bit7:�g��MMR */
#ifdef XM7DASH
				/* AV40/AV20EX/AV40EX�ȊO */
				if (fm_subtype < FMSUB_AV20EX) {
					mmr_ext = FALSE;
				}
				else {
					if (dat & 0x80) {
						mmr_ext = TRUE;
					}
					else {
						mmr_ext = FALSE;
					}
				}
#else
				if (dat & 0x80) {
					mmr_ext = TRUE;
				}
				else {
					mmr_ext = FALSE;
				}
#endif
				/* bit2:���t���b�V���X�s�[�h */
				if (dat & 0x04) {
					if (!mmr_fast_refresh) {
						mmr_fast_refresh = TRUE;
						if (!mmr_fastmode) {
							mmr_modify = TRUE;
						}
					}
				}
				else {
					if (mmr_fast_refresh) {
						mmr_fast_refresh = FALSE;
						if (!mmr_fastmode) {
							mmr_modify = TRUE;
						}
					}
				}
				/* bit0:�E�B���h�E�X�s�[�h */
				if (dat & 0x01) {
					if (!twr_fastmode) {
						twr_fastmode = TRUE;
						if (!mmr_fastmode) {
							mmr_modify = TRUE;
						}
					}
				}
				else {
					if (twr_fastmode) {
						twr_fastmode = FALSE;
						if (!mmr_fastmode) {
							mmr_modify = TRUE;
						}
					}
				}
			}
			return TRUE;

		/* ���[�h�Z���N�g�Q */
		case 0xfd95:
			if (fm7_ver >= 3) {
				/* bit7:�g��ROM�Z���N�g */
#ifdef XM7DASH
				/* AV40EX�ȊO */
				if (fm_subtype < FMSUB_AV40EX) {
					extrom_sel = FALSE;
				}
				else {
					if (dat & 0x80) {
						extrom_sel = TRUE;
					}
					else {
						extrom_sel = FALSE;
					}
				}
#else
				if (dat & 0x80) {
					extrom_sel = TRUE;
				}
				else {
					extrom_sel = FALSE;
				}
#endif
				/* bit4:MMR�g�p���̑��x�ቺ��}�~ */
#ifdef XM7DASH
				/* AV20EX/AV40EX�̂� */
				if ((fm_subtype == FMSUB_AV20EX) ||
					(fm_subtype == FMSUB_AV40EX)) {
					if (dat & 0x08) {
						if (!mmr_fastmode) {
							mmr_fastmode = TRUE;
							mmr_modify = TRUE;
						}
					}
					else {
						if (mmr_fastmode) {
							mmr_fastmode = FALSE;
							mmr_modify = TRUE;
						}
					}
				}
#else
				if (dat & 0x08) {
					if (!mmr_fastmode) {
						mmr_fastmode = TRUE;
						mmr_modify = TRUE;
					}
				}
				else {
					if (mmr_fastmode) {
						mmr_fastmode = FALSE;
						mmr_modify = TRUE;
					}
				}
#endif
			}
			return TRUE;

#ifdef MR2
		/* MR2 �f�[�^���W�X�^ */
		case 0xfd9c:
			if (mmr_extram) {
				mr2_write_data(dat);
			}
			return TRUE;

		/* MR2 �Z�N�^���W�X�^ */
		case 0xfd9e:
		case 0xfd9f:
			mr2_update_sector(addr, dat);
			return TRUE;
#endif
#endif
	}

	/* MMR���W�X�^ */
	if ((addr >= 0xfd80) && (addr <= 0xfd8f)) {
#if XM7_VER >= 3
		/* �����ł̃f�[�^��8bit���ׂċL�� */
		if (mmr_ext) {
			mmr_reg[mmr_seg * 0x10 + (addr - 0xfd80)] = (BYTE)dat;
		}
		else {
			mmr_reg[(mmr_seg & 3) * 0x10 + (addr - 0xfd80)] = (BYTE)dat;
		}
#elif XM7_VER == 1 && defined(XM7DASH)
		/* �����ł̃f�[�^��8bit���ׂċL�� */
		if (mmr_extrmw == EXRAM_960KB) {
			mmr_reg[mmr_seg * 0x10 + (addr - 0xfd80)] = (BYTE)dat;
		}
		else {
			mmr_reg[(mmr_seg & 3) * 0x10 + (addr - 0xfd80)] = (BYTE)dat;
		}
#else
		mmr_reg[(mmr_seg & 3) * 0x10 + (addr - 0xfd80)] = (BYTE)dat;
#endif
		return TRUE;
	}

	return FALSE;
}

/*-[ �t�@�C��I/O ]----------------------------------------------------------*/

/*
 *	MMR
 *	�Z�[�u
 */
BOOL FASTCALL mmr_save(int fileh)
{
	if (!file_bool_write(fileh, mmr_flag)) {
		return FALSE;
	}
	if (!file_byte_write(fileh, mmr_seg)) {
		return FALSE;
	}

#if XM7_VER >= 3
	/* Ver8�g���� */
	if (!file_write(fileh, mmr_reg, 0x80)) {
		return FALSE;
	}
	if (!file_bool_write(fileh, mmr_ext)) {
		return FALSE;
	}
	if (!file_bool_write(fileh, mmr_fastmode)) {
		return FALSE;
	}
	if (!file_bool_write(fileh, mmr_extram)) {
		return FALSE;
	}
	if (mmr_extram) {
		if (!file_write(fileh, extram_c, 0xc0000)) {
			return FALSE;
		}
	}
#ifdef MR2
	if (!file_byte_write(fileh, mr2_nowcnt)) {
		return FALSE;
	}
	if (!file_word_write(fileh, mr2_secreg)) {
		return FALSE;
	}
#else
	if (!file_byte_write(fileh, 0)) {
		return FALSE;
	}
	if (!file_word_write(fileh, 0)) {
		return FALSE;
	}
#endif
#elif XM7_VER == 1 && defined(XM7DASH)
	if (!file_byte_write(fileh, mmr_extrmw)) {
		return FALSE;
	}
	if (mmr_extrmw == EXRAM_960KB) {
		if (!file_write(fileh, mmr_reg, 0x100)) {
			return FALSE;
		}
		if (!file_write(fileh, extram_c, 0xc0000)) {
			return FALSE;
		}
		if (!file_byte_write(fileh, wbr_reg)) {
			return FALSE;
		}
	}
	else {
		if (!file_write(fileh, mmr_reg, 0x40)) {
			return FALSE;
		}
	}
	if (mmr_extrmw == EXRAM_64KB) {
		if (!file_byte_write(fileh, bsr_reg)) {
			return FALSE;
		}
	}
#else
	if (!file_write(fileh, mmr_reg, 0x40)) {
		return FALSE;
	}
#endif

	if (!file_bool_write(fileh, twr_flag)) {
		return FALSE;
	}
	if (!file_byte_write(fileh, twr_reg)) {
		return FALSE;
	}
#if XM7_VER >= 3
	if (!file_bool_write(fileh, twr_fastmode)) {
		return FALSE;
	}
#endif

	return TRUE;
}

/*
 *	MMR
 *	���[�h
 */
BOOL FASTCALL mmr_load(int fileh, int ver)
{
#if (XM7_VER >= 3) && !defined(MR2)
	WORD tmp;
#elif XM7_VER == 1 && defined(XM7DASH)
	BOOL tmp;
#endif

	/* �o�[�W�����`�F�b�N */
	if (ver < 200) {
		return FALSE;
	}

	if (!file_bool_read(fileh, &mmr_flag)) {
		return FALSE;
	}
	if (!file_byte_read(fileh, &mmr_seg)) {
		return FALSE;
	}

#if XM7_VER >= 3
	/* �t�@�C���o�[�W����8�Ŋg�� */
	if (ver >= 800) {
		if (!file_read(fileh, mmr_reg, 0x80)) {
			return FALSE;
		}
		if (!file_bool_read(fileh, &mmr_ext)) {
			return FALSE;
		}
		if (!file_bool_read(fileh, &mmr_fastmode)) {
			return FALSE;
		}
		if (!file_bool_read(fileh, &mmr_extram)) {
			return FALSE;
		}
		if (mmr_extram) {
			if (!file_read(fileh, extram_c, 0xc0000)) {
				return FALSE;
			}
		}
		if (ver >= 902) {
#ifdef MR2
			if (!file_byte_read(fileh, &mr2_nowcnt)) {
				return FALSE;
			}
			if (!file_word_read(fileh, &mr2_secreg)) {
				return FALSE;
			}
#else
			if (!file_byte_read(fileh, (BYTE *)&tmp)) {
				return FALSE;
			}
			if (!file_word_read(fileh, &tmp)) {
				return FALSE;
			}
#endif
		}
#ifdef MR2
		else {
			mr2_nowcnt = 0;
			mr2_secreg = 0;
		}
#endif
#ifdef XM7DASH
		/* AV40/AV20EX/AV40EX�ȊO */
		if ((fm_subtype != FMSUB_77AV40) &&
			(fm_subtype != FMSUB_AV20EX) &&
			(fm_subtype != FMSUB_AV40EX)) {
			if (mmr_ext) {
				return FALSE;
			}
		}
#endif
	}
	else {
		/* Ver5�݊� */
		if (!file_read(fileh, mmr_reg, 0x40)) {
			return FALSE;
		}
		mmr_ext = FALSE;
		mmr_fastmode = FALSE;
		mmr_extram = FALSE;
#ifdef MR2
		mr2_nowcnt = 0;
		mr2_secreg = 0;
#endif
	}
#elif XM7_VER == 1 && defined(XM7DASH)
	if (ver >= 409) {
		if (!file_byte_read(fileh, &mmr_extrmw)) {
			return FALSE;
		}
		if (mmr_extrmw > EXRAM_960KB) {
			mmr_extrmw = EXRAM_192KB;
		}
	}
	else if (ver >= 406) {
		if (!file_bool_read(fileh, &tmp)) {
			return FALSE;
		}
		if (tmp) {
			mmr_extrmw = EXRAM_960KB;
		}
		else {
			mmr_extrmw = EXRAM_192KB;
		}
	}
	else {
		mmr_extrmw = EXRAM_192KB;
	}
	if (mmr_extrmw == EXRAM_960KB) {
		if (!file_read(fileh, mmr_reg, 0x100)) {
			return FALSE;
		}
		if (!file_read(fileh, extram_c, 0xc0000)) {
			return FALSE;
		}
		if (!file_byte_read(fileh, &wbr_reg)) {
			return FALSE;
		}
	}
	else {
		if (!file_read(fileh, mmr_reg, 0x40)) {
			return FALSE;
		}
		wbr_reg = 2;
	}
	if ((ver >= 410) && (mmr_extrmw == EXRAM_64KB)) {
		if (!file_byte_read(fileh, &bsr_reg)) {
			return FALSE;
		}
	}
	else {
		bsr_reg = 2;
	}
#else
	if (!file_read(fileh, mmr_reg, 0x40)) {
		return FALSE;
	}
#endif

	if (!file_bool_read(fileh, &twr_flag)) {
		return FALSE;
	}
	if (!file_byte_read(fileh, &twr_reg)) {
		return FALSE;
	}

	/* Ver9.16�g�� */
#if XM7_VER >= 3
	if (ver >= 916) {
		if (!file_bool_read(fileh, &twr_fastmode)) {
			return FALSE;
		}
	}
#endif

	return TRUE;
}
