------------------------------------------------------------------------------

  FM-7 EMULATOR XM7dash (V1.2L63R21 / V2.9L63R21 / V3.4L63R21)

  source code (difference from original XM7)
  for Win32
  Copyright (C) 1999-2014 �o�h�D
  Copyright (C) 2001-2014 Ryu Takegami
  Copyright (C) 2010-2015 Toma
  ROMEO support code by usalin
  All rights reserved.

------------------------------------------------------------------------------

0. DISCLAIMER

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.

1. LICENCE

  Follow a license of XM7 original source code. (look at "XM7SRC.txt")

  When you use this source files, you have to be based on the next rule.
  This rule is also applied to version in the past.

  * You have to write original copyright clearly in document and source code
    when you use a file in the VM directory.
  * The partial reuse besides that is free.
  * Commercial use is prohibited.

  Redistribution on this archive is forbidden.

  Look at "XM7SRC.txt" about others.

  This is only translation.
  Refer to Japanese for an effective license.

2. CONTACT

  Website
  http://tomatoma.s54.xrea.com/

  BBS
  http://tomatoma.s54.xrea.com/cgi-bin/bbs.cgi

  ...but, I'm accepting only in Japanese.
