/*
 *	FM-7 EMULATOR "XM7"
 *
 *	Copyright (C) 1999-2014 �o�h�D(yasushi@tanaka.net)
 *	Copyright (C) 2001-2014 Ryu Takegami
 *	Copyright (C) 2010-2015 Toma
 *	line printer support 2010-2013 by Ben.JP
 *
 *	[ Win32API ���ʎq��` ]
 */

#ifdef _WIN32

/* ���j���[�A�A�N�Z�����[�^�A�^�C�}�[ */
#define IDR_MAINMENU					101
#define IDR_ACCELERATOR 				102
#define IDR_TIMER						103

/* �A�C�R���A�_�C�A���O */
#if XM7_VER != 2
#define IDI_APPICON						104
#else
#define IDI_AVICON						104
#endif
#define IDD_ABOUTDLG					105
#define IDI_WNDICON						106
#define IDR_DISASMMENU					107
#define IDD_ADDRDLG						108
#define IDR_BREAKPOINTMENU				109
#define IDD_TITLEDLG					110
#define IDD_GENERALPAGE					111
#define IDD_SOUNDPAGE					112
#define IDD_KBDPAGE						113
#define IDD_KEYINDLG					114
#define IDD_JOYPAGE						115
#define IDI_FUJICON						116
#define IDD_SCRPAGE						117
#define IDD_OPTPAGE						118
#define IDI_2DDICON						119
#if XM7_VER != 2
#define IDI_AVICON						120
#endif
#define IDI_TAMORIICON					121
#define IDI_FUJICON2					122
#define IDD_TITLEDLG_2D					123
#define IDI_SXICON						124
#define IDI_D77ICON						125
#define IDI_2DICON						126
#define IDI_VFDICON						127
#define IDI_VERICON						128
#ifdef XM7DASH
#define IDI_2HDICON						129
#endif
#define IDD_BREAKPDLG					130
#define IDR_MEMDMPMENU					131
#define IDD_MEMDLG						132
#define IDD_REGDLG						133
#define IDR_CPUREGMENU					134
#define IDD_SEARCHDLG					135
#define IDD_SOUNDPAGE2					136
#define IDD_PORTPAGE					137
#define IDD_VOLUMEPAGE					138
#define IDD_MEDIATYPEDLG				139
#define IDD_LPRPAGE						140

/* �_�C�A���O�A�R���e�L�X�g���j���[ */
#ifdef XM7DASH
#define IDD_MEDIASLCTDLG				201
#define IDD_ASPECTRATIODLG				202
#define IDD_RESUMEPAGE					300
#define IDD_OPT2PAGE					301
#define IDD_STRPAGE						302
#define IDR_MEDIAMENU					500
#define IDR_HISTORYMENU					501
#define IDR_ASPECTMENU					502
#endif

/* �A�C�R�� (by tenmaru) */
#define	IDI_FM8ICON						150
#define	IDI_FM7ICON						151
#define	IDI_FM77ICON					152
#define	IDI_77AVICON					153
#define	IDI_40EXICON					154
#define	IDI_40SXICON					155
#define	IDI_40EXICON2					156
#define	IDI_FM11ICON					157	/* reserved... */
#define	IDI_FDICON_1					160
#define	IDI_FDICON_1_2D					161
#define	IDI_FDICON_1_D77				162
#define	IDI_FDICON_1_VFD				163
#define	IDI_FDICON_2					164
#define	IDI_FDICON_2_2D					165
#define	IDI_FDICON_2_2DD				166
#define	IDI_FDICON_2_D77				167
#define	IDI_FDICON_2_VFD				168
#define	IDI_FDICON_3					169
#define	IDI_FDICON_3_2D					170
#define	IDI_FDICON_3_2DD				171
#define	IDI_FDICON_3_D77				172
#define	IDI_FDICON_3_VFD				173
#define	IDI_TAPEICON					174
#define	IDI_TAPEICON_T77				175
#ifdef XM7DASH
#define	IDI_FDICON_1_2HD				400
#define	IDI_FDICON_4					401
#define	IDI_FDICON_4_2HD				402
#define	IDI_FDICON_4_D77				403
#define	IDI_AV20ICON					404
#define	IDI_AV40ICON					405
#define	IDI_20EXICON					406
#endif

/* �`���C���h�E�C���h�E */
#define ID_TOOL_BAR						1000
#define ID_STATUS_BAR					1001
#define ID_CAPTURE_WINDOW				1002

/* �o�[�W�������_�C�A���O */
#define IDC_TITLE						1010
#define IDC_COPYRIGHT					1011
#define IDC_ABOUTICON					1012
#define IDC_FMCOPY						1013
#define IDC_VERSION						1014
#define IDC_URL_OLD						1015
#define IDC_COPYRIGHT_RHG				1015
#define IDC_COPYRIGHT_USA				1016
#define IDC_COPYRIGHT_TENMARU			1017
#ifdef XM7DASH
#define IDC_COPYRIGHT_TOM				1018
#define IDC_URL							2000
#define IDC_URL2						2001
#define IDC_URL3						2002
#define IDC_URL4						2003
#define IDC_URL5						2004
#else
#define IDC_URL							1018
#define IDC_URL2						1019
#define IDC_URL3						1020
#define IDC_URL4						1021
#endif
#define IDC_LPCOPYRIGHT					1039

/* �A�h���X���̓_�C�A���O */
#define IDC_ADDRLABEL					1022
#define IDC_ADDRCOMBO					1023

/* �������l���̓_�C�A���O */
#define IDC_MEMLABEL					1024
#define IDC_MEMEDIT						1025

/* ���W�X�^�l���̓_�C�A���O */
#define IDC_REGLABEL					1026
#define IDC_REGEDIT						1027

/* �����������_�C�A���O */
#define IDC_SEARCHDATA					1028
#define IDC_SEARCHADDR					1029

/* �^�C�g�����̓_�C�A���O */
#define IDC_TITLELABEL					1030
#define IDC_TITLEEDIT					1031
#define IDC_TITLEGROUP					1032
#define IDC_TITLE2D						1034
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
#define IDC_TITLE2HD					1035
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
#define IDC_TITLE2DD					1035
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
#define IDC_TITLEUSRDISK				1036
#define IDC_TITLELABEL2D				1037
#define IDC_TITLEEDIT2D					1038

#if XM7_VER == 1 && defined(BUBBLE)
/* �o�u�����f�B�A�^�C�v�I���_�C�A���O */
#ifdef XM7DASH
#define IDC_MEDIATYPEGROUP				2100
#define IDC_MEDIATYPE32KB				2101
#define IDC_MEDIATYPE128KB				2102
#endif
#define IDC_MEDIAFORMATGROUP			1310
#define IDC_MEDIAFORMATB77				1311
#define IDC_MEDIAFORMATBBL				1312
#endif	/* XM7_VER == 1 && defined(BUBBLE) */

#ifdef XM7DASH
/* �A�X�y�N�g��ݒ�_�C�A���O */
#define IDC_ASPECTLABEL					2010
#define IDC_ASPECTEDIT					2011
#define IDC_ASPECTSPIN					2012

/* ���O�E�B���h�E */
#define IDC_LOGLIST						2300
#endif

/* �v���p�e�B�y�[�W */
#define IDC_GP_FM7						1040
#define IDC_GP_FM77AV					1041
#define IDC_GP_FM8						1041
#define IDC_GP_SPEEDMODEG				1042
#define IDC_GP_HIGHSPEED				1043
#define IDC_GP_LOWSPEED					1044
#define IDC_GP_SPEEDG					1045
#define IDC_GP_HELP						1046
#define IDC_GP_TAPESPEED				1047
#define IDC_GP_CPUCOMBO					1048
#define IDC_GP_CPUTEXT					1049
#define IDC_GP_CPUSPIN					1050
#define IDC_GP_CPULABEL					1051
#define IDC_GP_MACHINEG					1052
#define IDC_GP_AV40EX					1053
#define IDC_GP_FM77						1053
#define IDC_GP_FULLSPEED				1054
#define IDC_GP_AUTOSPEEDADJUST			1055
#define IDC_GP_FDDWAIT					1056
#define IDC_GP_TAPESPEEDMODE			1057
#define IDC_GP_CPUDEFAULT				1058
#define IDC_GP_CPUSPEEDG				1059
#define IDC_GP_MAIN2MHZ					1060
#define IDC_GP_MAIN1MHZ					1061
#ifdef XM7DASH
#define IDC_GP_77AV20					2130
#define IDC_GP_77AV40					2131
#define IDC_GP_AV20EX					2132
#endif

/* �T�E���h�y�[�W */
#define IDC_SP_BEEPG					1070
#define IDC_SP_RATEG					1071
#define IDC_SP_96K						1072
#define IDC_SP_88K						1073
#define IDC_SP_51K						1095
#define IDC_SP_48K						1074
#define IDC_SP_44K						1075
#define IDC_SP_25K						1096
#define IDC_SP_22K						1076
#define IDC_SP_NONE						1077
#define IDC_SP_BUFFERG					1078
#define IDC_SP_BUFMS					1079
#define IDC_SP_BUFEDIT					1080
#define IDC_SP_BUFSPIN					1081
#define IDC_SP_BUFTEXT					1082
#define IDC_SP_BEEPEDIT					1083
#define IDC_SP_BEEPTEXT					1084
#define IDC_SP_BEEPHZ					1085
#define IDC_SP_BEEPSPIN					1086
#define IDC_SP_HQMODE					1087
#define IDC_SP_STEREOTEXT				1088
#define IDC_SP_STEREO					1089
#define IDC_SP_TAPEMON					1090
#define IDC_SP_ROMEO					1091
#define IDC_SP_OPTIONG					1092
#define IDC_SP_FDDSOUND					1093
#define IDC_SP_HELP						1094
#ifdef XM7DASH
#define IDC_SP_FMDLL					2110
#endif

/* ���ʒ����_�C�A���O */
#define IDC_VP_SEPARATIONG				1100
#define IDC_VP_SEPARATIONCAPTION		1101
#define IDC_VP_SEPARATION				1102
#define IDC_VP_SEPARATIONTEXT			1103
#define IDC_VP_VOLUMEG					1104
#define IDC_VP_FMCAPTION				1105
#define IDC_VP_FMVOLUME					1106
#define IDC_VP_FMVOLUMETEXT				1107
#define IDC_VP_PSGCAPTION				1108
#define IDC_VP_PSGVOLUME				1109
#define IDC_VP_PSGVOLUMETEXT			1110
#define IDC_VP_BEEPCAPTION				1111
#define IDC_VP_BEEPVOLUME				1112
#define IDC_VP_BEEPVOLUMETEXT			1113
#define IDC_VP_CMTCAPTION				1114
#define IDC_VP_CMTVOLUME				1115
#define IDC_VP_CMTVOLUMETEXT			1116
#define IDC_VP_WAVECAPTION				1117
#define IDC_VP_WAVEVOLUME				1118
#define IDC_VP_WAVEVOLUMETEXT			1119
#define IDC_VP_DEFAULT					1120
#define IDC_VP_HELP						1121

/* �L�[�{�[�h�y�[�W */
#define IDC_KP_MAPG						1130
#define IDC_KP_LIST						1131
#define IDC_KP_101B						1132
#define IDC_KP_106B						1133
#define IDC_KP_98B						1134
#define IDC_KP_USEARROWFOR10			1135
#define IDC_KP_KBDREAL					1136
#define IDC_KP_ARROW8DIR				1137
#define IDC_KP_HELP						1138

/* �L�[���̓_�C�A���O */
#define IDC_KEYIN_LABEL					1140
#define IDC_KEYIN_STATIC				1141
#define IDC_KEYIN_KEY					1142
#define IDC_KEYIN_OK					1143
#define IDC_KEYIN_CANCEL				1144

/* �W���C�X�e�B�b�N�y�[�W */
#define IDC_JP_PORTG					1150
#define IDC_JP_PORT1					1151
#define IDC_JP_PORT2					1152
#define IDC_JP_PORTC					IDC_JP_PORT1
#define IDC_JP_TYPEG					1153
#define IDC_JP_TYPEC					1154
#define IDC_JP_RAPIDG					1155
#define IDC_JP_RAPIDA					1156
#define IDC_JP_RAPIDB					1157
#define IDC_JP_RAPIDAC					1158
#define IDC_JP_RAPIDBC					1159
#define IDC_JP_CODEG					1160
#define IDC_JP_UP						1161
#define IDC_JP_UPC						1162
#define IDC_JP_DOWN						1163
#define IDC_JP_DOWNC					1164
#define IDC_JP_LEFT						1165
#define IDC_JP_LEFTC					1166
#define IDC_JP_RIGHT					1167
#define IDC_JP_RIGHTC					1168
#define IDC_JP_CENTER					1169
#define IDC_JP_CENTERC					1170
#define IDC_JP_A						1171
#define IDC_JP_AC						1172
#define IDC_JP_B						1173
#define IDC_JP_BC						1174
#define IDC_JP_HELP						1175

/* �X�N���[���y�[�W */
#define IDC_SCP_MODEG					1180
#define IDC_SCP_MODE					1181
#define IDC_SCP_MODEC					1182
#define IDC_SCP_ETCG					1185
#define IDC_SCP_24K						1186
#define IDC_SCP_24KFS					1187
#define IDC_SCP_CAPTIONB				1188
#define IDC_SCP_TRUECOLOR				1189
#define IDC_SCP_DOUBLESIZE				1190
#define IDC_SCP_RASTERRENDER			1191
#define IDC_SCP_GREENMONITOR			1192
#ifndef XM7DASH
#define IDC_SCP_TTLMONITOR				IDC_SCP_GREENMONITOR
#else
#define IDC_SCP_TTLMONITOR				2120
#define	IDC_SCP_FILTERDLL				2121
#define IDC_SCP_WING					2122
#endif
#define IDC_SCP_HELP					1193

/* �I�v�V�����y�[�W */
#define IDC_OP_WHGG						1200
#define IDC_OP_WHGB						1201
#define IDC_OP_THGB						1212
#define IDC_OP_DIGITIZEG				1223
#define IDC_OP_DIGITIZEB				1234
#define IDC_OP_RAMG						1245
#define IDC_OP_RAMB						1256
#define	IDC_OP_MOUSEG					1257
#define	IDC_OP_MOUSEEM					1258
#define	IDC_OP_MOUSE_PORT1				1259
#define	IDC_OP_MOUSE_PORT2				1260
#define IDC_OP_OPNB						1261
#define IDC_OP_400LINEG					1262
#define IDC_OP_400LINEB					1263
#define IDC_OP_MOUSESW					1264
#define IDC_OP_MOUSESWC					1265
#define IDC_OP_JSUBG					1266
#define IDC_OP_JSUBB					1267
#define IDC_OP_BANKSELG					1268
#define IDC_OP_BANKSELB					1269
#ifndef XM7DASH
#define IDC_OP_BMCG						1270
#define IDC_OP_BMCB						1271
#endif
#define IDC_OP_HELP						1272

/* �u���[�N�|�C���g�_�C�A���O */
#define IDC_BREAKP_ADDRLABEL			1280
#define IDC_BREAKP_ADDRCOMBO			1281
#define IDC_BREAKP_CPUGROUP				1282
#define IDC_BREAKP_CPU_MAIN				1283
#define IDC_BREAKP_CPU_SUB				1284
#define IDC_BREAKP_CPU_JSUB				1285

/* �|�[�g�y�[�W */
#define IDC_POP_MIDIG					1290
#define IDC_POP_MIDIDEV					1291
#define IDC_POP_MIDIDEVC				1292
#define IDC_POP_MIDIDLY					1293
#define IDC_POP_MIDIDLYEDIT				1294
#define IDC_POP_MIDIDLYSPIN				1295
#define IDC_POP_MIDIDLYMS				1296
#define IDC_POP_MIDIDLYSB				1297
#define IDC_POP_COMG					1298
#define IDC_POP_COMPORT					1299
#define IDC_POP_COMPORTC				1300
#define IDC_POP_COMENABLE				1301
#define IDC_POP_COMBPS					1302
#define IDC_POP_COMBPSC					1303
#define IDC_POP_RESETMSG				1304
#define IDC_POP_HELP					1305

/* �v�����^�y�[�W */
#ifdef LPRINT
#define IDC_LPP_LPRG					1310
#define IDC_LPP_LPRENABLE				1311
#define IDC_LPP_LPROSFNT				1312
#define IDC_LPP_LPRKANJI				1313
#define IDC_LPP_HELP					1314
#ifdef XM7DASH
#define IDC_LPP_VMLOCK					2140
#endif
#endif

#ifdef XM7DASH
/* �I�v�V����2�y�[�W */
#define IDC_O2P_KROMG					2200
#define IDC_O2P_KROMB					2201
#define IDC_O2P_JSUBG					2202
#define IDC_O2P_JSUBB					2203
#define IDC_O2P_JSUBKNJB				2204
#define IDC_O2P_EXRAMG					2205
#define IDC_O2P_EXRAM0					2206
#define IDC_O2P_EXRAM64					2207
#define IDC_O2P_EXRAM192				2208
#define IDC_O2P_EXRAM960				2209
#define IDC_O2P_JCARDG					2260
#define IDC_O2P_JCARDB					2261

/* �X�g���[�W�y�[�W */
#define IDC_STP_SFDG					2210
#define IDC_STP_SFDB					2211
#define IDC_STP_SFDI					2212
#define IDC_STP_MFDG					2213
#define IDC_STP_MFDI					2214
#define IDC_STP_BBLG					2215
#define IDC_STP_BBLB					2216
#define IDC_STP_BBL128B					2217
#define IDC_STP_BBLLIST					2218
#define IDC_STP_HELP					2219

/* ���f�B�A�I���_�C�A���O */
#define IDC_MEDIASLCT_L					2250
#define IDC_MEDIASLCT_C					2251

/* ���W���[���y�[�W */
#define IDC_RESUME_MOUNTG				2220
#define IDC_RESUME_FDB					2221
#define IDC_RESUME_TAPEB				2222
#define IDC_RESUME_BUBBLEB				2223
#define IDC_RESUME_ETCG					2224
#define IDC_RESUME_BOOTB				2225
#define IDC_RESUME_WINDOWB				2226
#define IDC_RESUME_SCREENB				2227
#define IDC_RESUME_DIRB					2228
#define IDC_RESUME_STATEG				2229
#define IDC_RESUME_STATEB				2230
#define IDC_RESUME_BKSTATEB				2231
#define IDC_RESUME_HELP					2232

/* ���̑��y�[�W */
#define IDC_MISC_GROUP					2240
#define IDC_MISC_POPUP					2241
#define IDC_MISC_SAVE					2242
#define IDC_MISC_RESUME					2243
#define IDC_MISC_GUIG					2244
#define IDC_MISC_FNAMEB					2245
#endif

/* �t�@�C�����j���[ */
#define IDM_OPEN						40001
#define IDM_SAVE						40002
#define IDM_SAVEAS						40003
#define IDM_PRINT						40138
#define IDM_RESET						40004
#define IDM_HOTRESET					40005
#define IDM_BASIC						40006
#define IDM_DOS 						40007
#define IDM_BUBBLE						40008
#define IDM_EXIT						40009
#ifdef XM7DASH
#define IDM_DOS_SFD						50000
#define IDM_BASIC_RAM					50001
#define IDM_BUBBLE128					50002
#define IDM_BASIC_DBG					50003
#define IDM_STATE_FILE0					50210
#define IDM_STATE_FILE1					50211
#define IDM_STATE_FILE2					50212
#define IDM_STATE_FILE3					50213
#define IDM_STATE_FILE4					50214
#define IDM_STATE_FILE5					50215
#define IDM_STATE_FILE6					50216
#define IDM_STATE_FILE7					50217
#define IDM_STATE_FILE8					50218
#define IDM_STATE_FILE9					50219
#define IDM_QLOAD						50350
#define IDM_QSAVE						50351
#endif

#ifdef XM7DASH
/* �h���C�u3���j���[ */
#define IDM_D3OPEN						50004
#define IDM_DB23OPEN					50005
#define IDM_D3EJECT						50006
//		IDM_D3TEMP						50007
#define IDM_D3WRITE						50008
//		IDM_D3FORCE						50009
#define IDM_D3MEDIA00					50010
#define IDM_D3MEDIA01					50011
#define IDM_D3MEDIA02					50012
#define IDM_D3MEDIA03					50013
#define IDM_D3MEDIA04					50014
#define IDM_D3MEDIA05					50015
#define IDM_D3MEDIA06					50016
#define IDM_D3MEDIA07					50017
#define IDM_D3MEDIA08					50018
#define IDM_D3MEDIA09					50019
#define IDM_D3MEDIA10					50020
#define IDM_D3MEDIA11					50021
#define IDM_D3MEDIA12					50022
#define IDM_D3MEDIA13					50023
#define IDM_D3MEDIA14					50024
#define IDM_D3MEDIA15					50025

/* �h���C�u2���j���[ */
#define IDM_D2OPEN						50026
//		IDM_DB23OPEN					50027
#define IDM_D2EJECT						50028
//		IDM_D2TEMP						50029
#define IDM_D2WRITE						50030
//		IDM_D2FORCE						50031
#define IDM_D2MEDIA00					50032
#define IDM_D2MEDIA01					50033
#define IDM_D2MEDIA02					50034
#define IDM_D2MEDIA03					50035
#define IDM_D2MEDIA04					50036
#define IDM_D2MEDIA05					50037
#define IDM_D2MEDIA06					50038
#define IDM_D2MEDIA07					50039
#define IDM_D2MEDIA08					50040
#define IDM_D2MEDIA09					50041
#define IDM_D2MEDIA10					50042
#define IDM_D2MEDIA11					50043
#define IDM_D2MEDIA12					50044
#define IDM_D2MEDIA13					50045
#define IDM_D2MEDIA14					50046
#define IDM_D2MEDIA15					50047

/* �h���C�u1���j���[ */
#define IDM_D1OPEN						50048
#define IDM_DBOPEN						50049
#define IDM_D1EJECT						50050
//		IDM_D1TEMP						50051
#define IDM_D1WRITE						50052
//		IDM_D1FORCE						50053
#define IDM_D1MEDIA00					50054
#define IDM_D1MEDIA01					50055
#define IDM_D1MEDIA02					50056
#define IDM_D1MEDIA03					50057
#define IDM_D1MEDIA04					50058
#define IDM_D1MEDIA05					50059
#define IDM_D1MEDIA06					50060
#define IDM_D1MEDIA07					50061
#define IDM_D1MEDIA08					50062
#define IDM_D1MEDIA09					50063
#define IDM_D1MEDIA10					50064
#define IDM_D1MEDIA11					50065
#define IDM_D1MEDIA12					50066
#define IDM_D1MEDIA13					50067
#define IDM_D1MEDIA14					50068
#define IDM_D1MEDIA15					50069

/* �h���C�u0���j���[ */
#define IDM_D0OPEN						50070
//		IDM_DBOPEN						50071
#define IDM_D0EJECT						50072
//		IDM_D0TEMP						50073
#define IDM_D0WRITE						50074
#define IDM_D0FORCE						50075
#define IDM_D0MEDIA00					50076
#define IDM_D0MEDIA01					50077
#define IDM_D0MEDIA02					50078
#define IDM_D0MEDIA03					50079
#define IDM_D0MEDIA04					50080
#define IDM_D0MEDIA05					50081
#define IDM_D0MEDIA06					50082
#define IDM_D0MEDIA07					50083
#define IDM_D0MEDIA08					50084
#define IDM_D0MEDIA09					50085
#define IDM_D0MEDIA10					50086
#define IDM_D0MEDIA11					50087
#define IDM_D0MEDIA12					50088
#define IDM_D0MEDIA13					50089
#define IDM_D0MEDIA14					50090
#define IDM_D0MEDIA15					50091

#define IDM_D3_FILE0					50230
#define IDM_D3_FILE1					50231
#define IDM_D3_FILE2					50232
#define IDM_D3_FILE3					50233
#define IDM_D3_FILE4					50234
#define IDM_D3_FILE5					50235
#define IDM_D3_FILE6					50236
#define IDM_D3_FILE7					50237
#define IDM_D3_FILE8					50238
#define IDM_D3_FILE9					50239

#define IDM_D2_FILE0					50240
#define IDM_D2_FILE1					50241
#define IDM_D2_FILE2					50242
#define IDM_D2_FILE3					50243
#define IDM_D2_FILE4					50244
#define IDM_D2_FILE5					50245
#define IDM_D2_FILE6					50246
#define IDM_D2_FILE7					50247
#define IDM_D2_FILE8					50248
#define IDM_D2_FILE9					50249

#define IDM_D1_FILE0					50250
#define IDM_D1_FILE1					50251
#define IDM_D1_FILE2					50252
#define IDM_D1_FILE3					50253
#define IDM_D1_FILE4					50254
#define IDM_D1_FILE5					50255
#define IDM_D1_FILE6					50256
#define IDM_D1_FILE7					50257
#define IDM_D1_FILE8					50258
#define IDM_D1_FILE9					50259

#define IDM_D0_FILE0					50260
#define IDM_D0_FILE1					50261
#define IDM_D0_FILE2					50262
#define IDM_D0_FILE3					50263
#define IDM_D0_FILE4					50264
#define IDM_D0_FILE5					50265
#define IDM_D0_FILE6					50266
#define IDM_D0_FILE7					50267
#define IDM_D0_FILE8					50268
#define IDM_D0_FILE9					50269

#define IDM_DBREPLACE					50360
#define IDM_DB23REPLACE					50361
#define IDM_MFD_EJECT					50202
#else
/* �h���C�u1���j���[ */
#define IDM_D1OPEN						40010
#define IDM_DBOPEN						40011
#define IDM_D1EJECT 					40012
#define IDM_D1TEMP						40013
#define IDM_D1WRITE 					40014
#define IDM_D1MEDIA00					40015
#define IDM_D1MEDIA01					40016
#define IDM_D1MEDIA02					40017
#define IDM_D1MEDIA03					40018
#define IDM_D1MEDIA04					40019
#define IDM_D1MEDIA05					40020
#define IDM_D1MEDIA06					40021
#define IDM_D1MEDIA07					40022
#define IDM_D1MEDIA08					40023
#define IDM_D1MEDIA09					40024
#define IDM_D1MEDIA10					40025
#define IDM_D1MEDIA11					40026
#define IDM_D1MEDIA12					40027
#define IDM_D1MEDIA13					40028
#define IDM_D1MEDIA14					40029
#define IDM_D1MEDIA15					40030

/* �h���C�u0���j���[ */
#define IDM_D0OPEN						40031
//		IDM_DBOPEN						40032
#define IDM_D0EJECT						40033
#define IDM_D0TEMP						40034
#define IDM_D0WRITE 					40035
#define IDM_D0MEDIA00					40036
#define IDM_D0MEDIA01					40037
#define IDM_D0MEDIA02					40038
#define IDM_D0MEDIA03					40039
#define IDM_D0MEDIA04					40040
#define IDM_D0MEDIA05					40041
#define IDM_D0MEDIA06					40042
#define IDM_D0MEDIA07					40043
#define IDM_D0MEDIA08					40044
#define IDM_D0MEDIA09					40045
#define IDM_D0MEDIA10					40046
#define IDM_D0MEDIA11					40047
#define IDM_D0MEDIA12					40048
#define IDM_D0MEDIA13					40049
#define IDM_D0MEDIA14					40050
#define IDM_D0MEDIA15					40051
#endif

#ifdef XM7DASH
/* 1MB�t���b�s�[�f�B�X�N�h���C�u3���j���[ */
#define IDM_D7OPEN						50092
#define IDM_DB67OPEN					50093
#define IDM_D7EJECT						50094
//		IDM_D7TEMP						50095
#define IDM_D7WRITE						50096
#define IDM_D7FORCE						50097
#define IDM_D7MEDIA00					50098
#define IDM_D7MEDIA01					50099
#define IDM_D7MEDIA02					50100
#define IDM_D7MEDIA03					50101
#define IDM_D7MEDIA04					50102
#define IDM_D7MEDIA05					50103
#define IDM_D7MEDIA06					50104
#define IDM_D7MEDIA07					50105
#define IDM_D7MEDIA08					50106
#define IDM_D7MEDIA09					50107
#define IDM_D7MEDIA10					50108
#define IDM_D7MEDIA11					50109
#define IDM_D7MEDIA12					50110
#define IDM_D7MEDIA13					50111
#define IDM_D7MEDIA14					50112
#define IDM_D7MEDIA15					50113

/* 1MB�t���b�s�[�f�B�X�N�h���C�u2���j���[ */
#define IDM_D6OPEN						50114
//		IDM_DB67OPEN					50115
#define IDM_D6EJECT						50116
//		IDM_D6TEMP						50117
#define IDM_D6WRITE						50118
#define IDM_D6FORCE						50119
#define IDM_D6MEDIA00					50120
#define IDM_D6MEDIA01					50121
#define IDM_D6MEDIA02					50122
#define IDM_D6MEDIA03					50123
#define IDM_D6MEDIA04					50124
#define IDM_D6MEDIA05					50125
#define IDM_D6MEDIA06					50126
#define IDM_D6MEDIA07					50127
#define IDM_D6MEDIA08					50128
#define IDM_D6MEDIA09					50129
#define IDM_D6MEDIA10					50130
#define IDM_D6MEDIA11					50131
#define IDM_D6MEDIA12					50132
#define IDM_D6MEDIA13					50133
#define IDM_D6MEDIA14					50134
#define IDM_D6MEDIA15					50135

/* 1MB�t���b�s�[�f�B�X�N�h���C�u1���j���[ */
#define IDM_D5OPEN						50136
#define IDM_DB45OPEN					50137
#define IDM_D5EJECT						50138
//		IDM_D5TEMP						50139
#define IDM_D5WRITE						50140
#define IDM_D5FORCE						50141
#define IDM_D5MEDIA00					50142
#define IDM_D5MEDIA01					50143
#define IDM_D5MEDIA02					50144
#define IDM_D5MEDIA03					50145
#define IDM_D5MEDIA04					50146
#define IDM_D5MEDIA05					50147
#define IDM_D5MEDIA06					50148
#define IDM_D5MEDIA07					50149
#define IDM_D5MEDIA08					50150
#define IDM_D5MEDIA09					50151
#define IDM_D5MEDIA10					50152
#define IDM_D5MEDIA11					50153
#define IDM_D5MEDIA12					50154
#define IDM_D5MEDIA13					50155
#define IDM_D5MEDIA14					50156
#define IDM_D5MEDIA15					50157

/* 1MB�t���b�s�[�f�B�X�N�h���C�u0���j���[ */
#define IDM_D4OPEN						50158
//		IDM_DB45OPEN					50159
#define IDM_D4EJECT						50160
//		IDM_D4TEMP						50161
#define IDM_D4WRITE						50162
#define IDM_D4FORCE						50163
#define IDM_D4MEDIA00					50164
#define IDM_D4MEDIA01					50165
#define IDM_D4MEDIA02					50166
#define IDM_D4MEDIA03					50167
#define IDM_D4MEDIA04					50168
#define IDM_D4MEDIA05					50169
#define IDM_D4MEDIA06					50170
#define IDM_D4MEDIA07					50171
#define IDM_D4MEDIA08					50172
#define IDM_D4MEDIA09					50173
#define IDM_D4MEDIA10					50174
#define IDM_D4MEDIA11					50175
#define IDM_D4MEDIA12					50176
#define IDM_D4MEDIA13					50177
#define IDM_D4MEDIA14					50178
#define IDM_D4MEDIA15					50179

#define IDM_D7_FILE0					50270
#define IDM_D7_FILE1					50271
#define IDM_D7_FILE2					50272
#define IDM_D7_FILE3					50273
#define IDM_D7_FILE4					50274
#define IDM_D7_FILE5					50275
#define IDM_D7_FILE6					50276
#define IDM_D7_FILE7					50277
#define IDM_D7_FILE8					50278
#define IDM_D7_FILE9					50279

#define IDM_D6_FILE0					50280
#define IDM_D6_FILE1					50281
#define IDM_D6_FILE2					50282
#define IDM_D6_FILE3					50283
#define IDM_D6_FILE4					50284
#define IDM_D6_FILE5					50285
#define IDM_D6_FILE6					50286
#define IDM_D6_FILE7					50287
#define IDM_D6_FILE8					50288
#define IDM_D6_FILE9					50289

#define IDM_D5_FILE0					50290
#define IDM_D5_FILE1					50291
#define IDM_D5_FILE2					50292
#define IDM_D5_FILE3					50293
#define IDM_D5_FILE4					50294
#define IDM_D5_FILE5					50295
#define IDM_D5_FILE6					50296
#define IDM_D5_FILE7					50297
#define IDM_D5_FILE8					50298
#define IDM_D5_FILE9					50299

#define IDM_D4_FILE0					50300
#define IDM_D4_FILE1					50301
#define IDM_D4_FILE2					50302
#define IDM_D4_FILE3					50303
#define IDM_D4_FILE4					50304
#define IDM_D4_FILE5					50305
#define IDM_D4_FILE6					50306
#define IDM_D4_FILE7					50307
#define IDM_D4_FILE8					50308
#define IDM_D4_FILE9					50309

#define IDM_DB45REPLACE					50362
#define IDM_DB67REPLACE					50363
#define IDM_SFD_EJECT					50203
#endif

/* �e�[�v���j���[ */
#define IDM_TOPEN						40052
#define IDM_TEJECT						40053
#define IDM_REW							40054
#define IDM_FF							40055
#define IDM_REC							40056
#ifdef XM7DASH
#define IDM_TMEDIA						50205

#define IDM_T_FILE0						50220
#define IDM_T_FILE1						50221
#define IDM_T_FILE2						50222
#define IDM_T_FILE3						50223
#define IDM_T_FILE4						50224
#define IDM_T_FILE5						50225
#define IDM_T_FILE6						50226
#define IDM_T_FILE7						50227
#define IDM_T_FILE8						50228
#define IDM_T_FILE9						50229
#endif

#ifdef XM7DASH
/* 128KB�o�u���z���_���j�b�g1���j���[ */
#define IDM_B3OPEN						50400
#define IDM_BB23OPEN					50401
#define IDM_B3EJECT						50402
#define IDM_B3TEMP						50403
#define IDM_B3WRITE						50404
#define IDM_B3MEDIA00					50405
#define IDM_B3MEDIA01					50406
#define IDM_B3MEDIA02					50407
#define IDM_B3MEDIA03					50408
#define IDM_B3MEDIA04					50409
#define IDM_B3MEDIA05					50410
#define IDM_B3MEDIA06					50411
#define IDM_B3MEDIA07					50412
#define IDM_B3MEDIA08					50413
#define IDM_B3MEDIA09					50414
#define IDM_B3MEDIA10					50415
#define IDM_B3MEDIA11					50416
#define IDM_B3MEDIA12					50417
#define IDM_B3MEDIA13					50418
#define IDM_B3MEDIA14					50419
#define IDM_B3MEDIA15					50420

/* 128KB�o�u���z���_���j�b�g0���j���[ */
#define IDM_B2OPEN						50421
//		IDM_BBOPEN						50422
#define IDM_B2EJECT						50423
#define IDM_B2TEMP						50424
#define IDM_B2WRITE						50425
#define IDM_B2MEDIA00					50426
#define IDM_B2MEDIA01					50427
#define IDM_B2MEDIA02					50428
#define IDM_B2MEDIA03					50429
#define IDM_B2MEDIA04					50430
#define IDM_B2MEDIA05					50431
#define IDM_B2MEDIA06					50432
#define IDM_B2MEDIA07					50433
#define IDM_B2MEDIA08					50434
#define IDM_B2MEDIA09					50435
#define IDM_B2MEDIA10					50436
#define IDM_B2MEDIA11					50437
#define IDM_B2MEDIA12					50438
#define IDM_B2MEDIA13					50439
#define IDM_B2MEDIA14					50440
#define IDM_B2MEDIA15					50441

/* 32KB�o�u���z���_���j�b�g1���j���[ */
#define IDM_B1OPEN						50442
#define IDM_BBOPEN						50443
#define IDM_B1EJECT						50444
#define IDM_B1TEMP						50445
#define IDM_B1WRITE						50446
#define IDM_B1MEDIA00					50447
#define IDM_B1MEDIA01					50448
#define IDM_B1MEDIA02					50449
#define IDM_B1MEDIA03					50450
#define IDM_B1MEDIA04					50451
#define IDM_B1MEDIA05					50452
#define IDM_B1MEDIA06					50453
#define IDM_B1MEDIA07					50454
#define IDM_B1MEDIA08					50455
#define IDM_B1MEDIA09					50456
#define IDM_B1MEDIA10					50457
#define IDM_B1MEDIA11					50458
#define IDM_B1MEDIA12					50459
#define IDM_B1MEDIA13					50460
#define IDM_B1MEDIA14					50461
#define IDM_B1MEDIA15					50462

/* 32KB�o�u���z���_���j�b�g0���j���[ */
#define IDM_B0OPEN						50463
//		IDM_BBOPEN						50464
#define IDM_B0EJECT						50465
#define IDM_B0TEMP						50466
#define IDM_B0WRITE						50467
#define IDM_B0MEDIA00					50468
#define IDM_B0MEDIA01					50469
#define IDM_B0MEDIA02					50470
#define IDM_B0MEDIA03					50471
#define IDM_B0MEDIA04					50472
#define IDM_B0MEDIA05					50473
#define IDM_B0MEDIA06					50474
#define IDM_B0MEDIA07					50475
#define IDM_B0MEDIA08					50476
#define IDM_B0MEDIA09					50477
#define IDM_B0MEDIA10					50478
#define IDM_B0MEDIA11					50479
#define IDM_B0MEDIA12					50480
#define IDM_B0MEDIA13					50481
#define IDM_B0MEDIA14					50482
#define IDM_B0MEDIA15					50483

#define IDM_B3_FILE0					50310
#define IDM_B3_FILE1					50311
#define IDM_B3_FILE2					50312
#define IDM_B3_FILE3					50313
#define IDM_B3_FILE4					50314
#define IDM_B3_FILE5					50315
#define IDM_B3_FILE6					50316
#define IDM_B3_FILE7					50317
#define IDM_B3_FILE8					50318
#define IDM_B3_FILE9					50319

#define IDM_B2_FILE0					50320
#define IDM_B2_FILE1					50321
#define IDM_B2_FILE2					50322
#define IDM_B2_FILE3					50323
#define IDM_B2_FILE4					50324
#define IDM_B2_FILE5					50325
#define IDM_B2_FILE6					50326
#define IDM_B2_FILE7					50327
#define IDM_B2_FILE8					50328
#define IDM_B2_FILE9					50329

#define IDM_B1_FILE0					50330
#define IDM_B1_FILE1					50331
#define IDM_B1_FILE2					50332
#define IDM_B1_FILE3					50333
#define IDM_B1_FILE4					50334
#define IDM_B1_FILE5					50335
#define IDM_B1_FILE6					50336
#define IDM_B1_FILE7					50337
#define IDM_B1_FILE8					50338
#define IDM_B1_FILE9					50339

#define IDM_B0_FILE0					50340
#define IDM_B0_FILE1					50341
#define IDM_B0_FILE2					50342
#define IDM_B0_FILE3					50343
#define IDM_B0_FILE4					50344
#define IDM_B0_FILE5					50345
#define IDM_B0_FILE6					50346
#define IDM_B0_FILE7					50347
#define IDM_B0_FILE8					50348
#define IDM_B0_FILE9					50349

#define IDM_BBREPLACE					50364
#define IDM_BB23REPLACE					50365
#define IDM_CAS_EJECT					50204
#else
/* �o�u���z���_0���j���[ */
#define IDM_B0OPEN						40057
#define IDM_BBOPEN						40516
#define IDM_B0EJECT						40058
#define IDM_B0TEMP						40059
#define IDM_B0WRITE						40060
#define IDM_B0MEDIA00					40500
#define IDM_B0MEDIA01					40501
#define IDM_B0MEDIA02					40502
#define IDM_B0MEDIA03					40503
#define IDM_B0MEDIA04					40504
#define IDM_B0MEDIA05					40505
#define IDM_B0MEDIA06					40506
#define IDM_B0MEDIA07					40507
#define IDM_B0MEDIA08					40508
#define IDM_B0MEDIA09					40509
#define IDM_B0MEDIA10					40510
#define IDM_B0MEDIA11					40511
#define IDM_B0MEDIA12					40512
#define IDM_B0MEDIA13					40513
#define IDM_B0MEDIA14					40514
#define IDM_B0MEDIA15					40515

/* �o�u���z���_1���j���[ */
#define IDM_B1OPEN						40061
//efine IDM_BBOPEN						40516
#define IDM_B1EJECT						40062
#define IDM_B1TEMP						40063
#define IDM_B1WRITE						40064
#define IDM_B1MEDIA00					40520
#define IDM_B1MEDIA01					40521
#define IDM_B1MEDIA02					40522
#define IDM_B1MEDIA03					40523
#define IDM_B1MEDIA04					40524
#define IDM_B1MEDIA05					40525
#define IDM_B1MEDIA06					40526
#define IDM_B1MEDIA07					40527
#define IDM_B1MEDIA08					40528
#define IDM_B1MEDIA09					40529
#define IDM_B1MEDIA10					40530
#define IDM_B1MEDIA11					40531
#define IDM_B1MEDIA12					40532
#define IDM_B1MEDIA13					40533
#define IDM_B1MEDIA14					40534
#define IDM_B1MEDIA15					40535
#endif

/* �\�����j���[ */
#define IDM_FDC							40065
#define IDM_BMC							40066
#define IDM_OPNREG						40067
#define IDM_OPNDISP						40068
#define IDM_SUBCTRL						40069
#define IDM_KEYBOARD					40070
#define IDM_MMR							40071
#define IDM_DMAC						40072
#define IDM_ALULINE						40073
#define IDM_CYCLESTEAL					40074
#define IDM_STATUS						40075
#define IDM_REFRESH						40076
#define IDM_SYNC						40077
#define IDM_FULLSCREEN					40078
#ifdef XM7DASH
#define IDM_KANJI						50359
#define IDM_TAPE						50367
#define IDM_LP							50368
#define IDM_DISPLAYSIZEx100				50352
#define IDM_DISPLAYSIZEx150				50353
#define IDM_DISPLAYSIZEx200				50354
#define IDM_DISPLAYSIZEx050				50355
#define IDM_DISPLAYSIZEx180				50356
#define IDM_DISPLAYSIZEx120				50358
#define IDM_ASPECTRATIO					50366
#endif

/* �f�o�b�O���j���[ */
#define IDM_EXEC 						40080
#define IDM_BREAK						40081
#define IDM_TRACE						40082
#define IDM_BREAKPOINT					40083
#define IDM_SCHEDULER					40084
#define IDM_CPU_MAIN					40085
#define IDM_CPU_SUB						40086
#define IDM_DISASM_MAIN					40087
#define IDM_DISASM_SUB					40088
#define IDM_MEMORY_MAIN					40089
#define IDM_MEMORY_SUB					40090
#define IDM_CPU_JSUB					40091
#define IDM_DISASM_JSUB					40092
#define IDM_MEMORY_JSUB					40093
#ifdef XM7DASH
#define IDM_IRQ_MAIN					50200
#define IDM_IRQ_SUB						50206
#define IDM_LOG							50357
#endif

/* �c�[�����j���[ */
#define IDM_CONFIG						40094
#define IDM_GRPCAP						40095
#define IDM_WAVCAP						40096
#define IDM_NEWDISK						40097
#define IDM_NEWTAPE						40098
#define IDM_NEWBUBBLE					40099
#define IDM_VFD2D77						40100
#define IDM_2D2D77						40101
#define IDM_VTP2T77						40102
#define IDM_GRPCAP2						40103
#define IDM_TIMEADJUST					40104
#define IDM_MOUSEMODE					40105
#define IDM_BBL2B77						40106
#define IDM_MOUSEMODE2					40107
#define IDM_MOUSEON						40108
#define IDM_MOUSEOFF					40109
#define IDM_S98CAP						40138
#ifdef XM7DASH
#define IDM_EXTSND0						50370
#define IDM_EXTSND1						50371
#define IDM_EXTSND2						50372
#define IDM_EXTSND3						50373
#define IDM_EXTSND4						50374
#define IDM_EXTSND5						50375
#define IDM_EXTSND6						50376
#define IDM_EXTSND7						50377
#define IDM_EXTSND8						50378
#define IDM_EXTSND9						50379
#define IDM_EXTFLT0						50380
#define IDM_EXTFLT1						50381
#define IDM_EXTFLT2						50382
#define IDM_EXTFLT3						50383
#define IDM_EXTFLT4						50384
#define IDM_EXTFLT5						50385
#define IDM_EXTFLT6						50386
#define IDM_EXTFLT7						50387
#define IDM_EXTFLT8						50388
#define IDM_EXTFLT9						50389
#define IDM_PASTE						50390
#define	IDM_EXT_SOUND_DLL				50391
#define	IDM_EXT_FILTER_DLL				50392
#endif

/* �E�B���h�E���j���[ */
#define IDM_CASCADE						40110
#define IDM_TILE						40111
#define IDM_ICONIC						40112
#define IDM_ARRANGEICON					40113
#define IDM_ALLHIDE						40114
#define IDM_ALLRESTORE					40115
#define IDM_ALLCLOSE					40137
#define IDM_SWND00						40116
#define IDM_SWND01						40117
#define IDM_SWND02						40118
#define IDM_SWND03						40119
#define IDM_SWND04						40120
#define IDM_SWND05						40121
#define IDM_SWND06						40122
#define IDM_SWND07						40123
#define IDM_SWND08						40124
#define IDM_SWND09						40125
#define IDM_SWND10						40126
#define IDM_SWND11						40127
#define IDM_SWND12						40128
#define IDM_SWND13						40129
#define IDM_SWND14						40130
#define IDM_SWND15						40131
#define IDM_SWND16						40132
#define IDM_SWND17						40133
#define IDM_SWND18						40134
#define IDM_SWND19						40135

/* �w���v���j���[ */
#define IDM_ABOUT						40136
#ifdef XM7DASH
#define IDM_LANGUAGE					50201
#endif

/* �R���e�L�X�g���j���[(�t�A�Z���u��) */
#define IDM_DIS_ADDR					40200
#define IDM_DIS_PC						40201
#define IDM_DIS_X						40202
#define IDM_DIS_Y						40203
#define IDM_DIS_U						40204
#define IDM_DIS_S						40205
#define IDM_DIS_RESET					40206
#define IDM_DIS_NMI						40207
#define IDM_DIS_SWI						40208
#define IDM_DIS_IRQ						40209
#define IDM_DIS_FIRQ					40210
#define IDM_DIS_SWI2					40211
#define IDM_DIS_SWI3					40212
#define IDM_DIS_JUMP					40213
#define IDM_DIS_SYNCPC					40214
#define	IDM_DIS_STACK					40216
#define	IDM_DIS_BREAK					40232
#ifdef XM7DASH
#define	IDM_DIS_LOGIC					50600
#define	IDM_DIS_PADR0					50601
//		�\���					50620 -	50616
#define	IDM_DIS_SEG00					50617
//		�\���					50618 -	50680
#define	IDM_DIS_LADR0					50762
//		�\���					50763 -	50777
#define	IDM_DIS_VECTOR					50794
//		�\���					50795 -	50809
#endif

/* �R���e�L�X�g���j���[(�_���v) */
#define IDM_DMP_ADDR					40250
#define IDM_DMP_PC						40251
#define IDM_DMP_X						40252
#define IDM_DMP_Y						40253
#define IDM_DMP_U						40254
#define IDM_DMP_S						40255
#define IDM_DMP_RESET					40256
#define IDM_DMP_NMI						40257
#define IDM_DMP_SWI						40258
#define IDM_DMP_IRQ						40259
#define IDM_DMP_FIRQ					40260
#define IDM_DMP_SWI2					40261
#define IDM_DMP_SWI3					40262
#define IDM_DMP_DP						40263
#define IDM_DMP_IO						40264
#define IDM_DMP_BLK128					40265
#define IDM_DMP_BLK256					40266
#define IDM_DMP_ASCII					40267
#define IDM_DMP_KANJI					40268
#define IDM_DMP_SEARCH					40269
#define	IDM_DMP_STACK					40270
#ifdef XM7DASH
#define	IDM_DMP_LOGIC					50681
#define	IDM_DMP_PADR0					50682
//		�\���					50683 -	50697
#define	IDM_DMP_SEG00					50698
//		�\���					50699 -	50761
#define	IDM_DMP_LADR0					50778
//		�\���					50779 -	50793
#define	IDM_DMP_VECTOR					50810
//		�\���					50811 -	50825
#endif

/* �R���e�L�X�g���j���[(�u���[�N�|�C���g) */
#define IDM_BREAKP_JUMP					40300
#define IDM_BREAKP_ENABLE 				40301
#define IDM_BREAKP_DISABLE				40302
#define IDM_BREAKP_CLEAR				40303
#define IDM_BREAKP_ALL					40304
#define IDM_BREAKP_SET					40305

/* �R���e�L�X�g���j���[(CPU���W�X�^) */
#define IDM_REG_CC						40350
#define IDM_REG_A						40351
#define IDM_REG_B						40352
#define IDM_REG_DP						40353
#define IDM_REG_D						40354
#define IDM_REG_X						40355
#define IDM_REG_Y						40356
#define IDM_REG_U						40357
#define IDM_REG_S						40358
#define IDM_REG_PC						40359

/* �L�[�{�[�h�V���[�g�J�b�g */
#define	IDM_CHG_SOUNDMODE				40400

#ifdef XM7DASH
/* �R���e�L�X�g���j���[(�f�B�X�N) */
#define IDM_MEDIATITLE					50500

/* �R���e�L�X�g���j���[(�q�X�g��) */
#define IDM_HISTORY_DELETE				50510

/* �R���e�L�X�g���j���[(�A�X�y�N�g��ݒ�) */
#define IDM_ASPECTSETTING				50520
#endif

/* ���b�Z�[�W������Q */
#define IDS_IDLEMESSAGE 				41000
#define IDS_VMERROR 					41001
#define IDS_DXERROR						41002
#define IDS_RUNCAPTION					41003
#define IDS_STOPCAPTION					41004
#ifdef XM7DASH
#define IDS_BASIC_DBG					51038
#define IDS_BASIC_RAM					51039
#define IDS_EXIT						51037
#endif
#define IDS_DISKFILTER					41005
#ifdef XM7DASH
#define IDS_DISKFILTER_SFD				51000
#endif
#define IDS_DISKOPEN					41006
#define IDS_DISKBOTH					41007
#ifdef XM7DASH
#define IDS_DISKBOTH23					51001
#endif
#define IDS_DISKEJECT					41008
#define IDS_DISKPROTECT					41009
#ifndef XM7DASH
#define IDS_DISK2D						41010
#endif
#ifdef XM7DASH
//		IDS_DISK0OPEN					51002
//		IDS_DISK1OPEN					51003
//		IDS_DISK2OPEN					51004
//		IDS_DISK3OPEN					51005
#define IDS_DISK0						51006
#define IDS_DISK1						51007
#define IDS_DISK2						51008
#define IDS_DISK3						51009
#define IDS_DISKFORCE					51010
#define IDS_MFD_EJECT					51011
#define IDS_SFD_EJECT					51012
#endif
#define IDS_TAPEFILTER					41011
#define IDS_TAPEOPEN					41012
#define IDS_TAPEEJECT					41013
#define IDS_TAPEREW						41014
#define IDS_TAPEFF						41015
#define IDS_TAPEREC						41016
#define IDS_NEWTAPEOK					41017
#define IDS_NEWDISKFILTER				41018
#define IDS_NEWDISKOK					41019
#ifdef XM7DASH
#define IDS_TAPE						51020
//		IDS_TAPE0OPEN					51021
#endif
#define IDS_BUBBLEFILTER				41020
#ifdef XM7DASH
//		IDS_BUBBLE						51022
//		IDS_BUBBLEX						51023
//		IDS_BUBBLE0OPEN					51024
//		IDS_BUBBLE1OPEN					51025
//		IDS_BUBBLE2OPEN					51026
//		IDS_BUBBLE3OPEN					51027
#define IDS_BUBBLE0						51028
#define IDS_BUBBLE1						51029
#define IDS_BUBBLEX0					51030
#define IDS_BUBBLEX1					51031
//		IDS_BUBBLEBOTH					51032
//		IDS_BUBBLEBOTHX					51033
#else
#define IDS_BUBBLE0						41021
#define IDS_BUBBLE1						41022
#endif
#define IDS_BUBBLEOPEN					41023
#define IDS_BUBBLEEJECT					41024
#define IDS_BUBBLETEMP					41025
#define IDS_BUBBLEPROTECT				41026
#define IDS_NEWBUBBLEOK					41027
#ifdef XM7DASH
//		IDS_CAS_EJECT					51035
#endif
#define IDS_GRPCAPFILTER				41028
#define IDS_SWND_CPUREG_MAIN			41029
#define IDS_SWND_CPUREG_SUB				41030
#define IDS_SWND_SCHEDULER				41031
#define IDS_SWND_DISASM_MAIN			41032
#define IDS_SWND_DISASM_SUB				41033
#define IDS_SWND_MEMORY_MAIN			41034
#define IDS_SWND_MEMORY_SUB				41035
#define IDS_SWND_BMC					41036
#define IDS_STATEFILTER					41037
#define IDS_STATEERROR					41038
#define IDS_SWND_BREAKPOINT				41039
#define IDS_SWND_FDC					41040
#define IDS_VFDFILTER					41041
#define IDS_2DFILTER					41042
#define IDS_VTPFILTER					41043
#define IDS_CONVERTOK					41044
#define IDS_SWND_OPNREG					41045
#define IDS_SWND_SUBCTRL				41046
#define IDS_CONFIGCAPTION				41047
#define IDS_GP_MAINCPU					41048
#define IDS_GP_MAINMMR					41049
#define IDS_SWND_OPNDISP				41050
#define IDS_SWND_KEYBOARD				41051
#define IDS_KP_KEYNO					41052
#define IDS_KP_KEYFM					41053
#define IDS_KP_KEYKANA					41054
#define IDS_KP_KEYDI					41055
#ifndef XM7DASH
#define IDS_DISKTEMP					41056
#endif
#define IDS_JP_RAPID0					41057
#define IDS_JP_RAPID1					41058
#define IDS_JP_RAPID2					41059
#define IDS_JP_RAPID3					41060
#define IDS_JP_RAPID4					41061
#define IDS_JP_RAPID5					41062
#define IDS_JP_RAPID6					41063
#define IDS_JP_RAPID7					41064
#define IDS_JP_RAPID8					41065
#define IDS_JP_RAPID9					41066
#define IDS_JP_TYPE0					41067
#define IDS_JP_TYPE1					41068
#define IDS_JP_TYPE2					41069
#define IDS_JP_TYPE3					41070
#define IDS_JP_TYPE4					41071
#define IDS_ABOUTURL_OLD				41072
#define IDS_SWND_MMR					41073
#define IDS_WAVCAPFILTER				41074
#define IDS_WAVCAPERROR					41075
#define IDS_GP_SUBCPU					41076
#define IDS_SP_MONO						41077
#define IDS_SP_STEREO					41078
#define IDS_SP_STEREO_REV				41079
#define IDS_SP_STEREO_THG				41080
#ifndef XM7DASH
#define IDS_DISKVFD						41081
#endif
#define IDS_SWND_DMAC					41082
#define IDS_GP_FASTMMR					41083
#ifdef XM7DASH
#define IDS_GP_JSUBCPU					51100
#else
#define IDS_GP_JSUBCPU					41083
#endif
#define IDS_SWND_ALULINE				41084
#define IDS_MEDIA_CHANGE				41085
#ifdef XM7DASH
//		IDS_DISK2HD						41086
#else
#define IDS_DISK2DD						41086
#endif
#define IDS_SND_MONAURAL				41087
#define IDS_SND_WHG_NORMAL				41088
#define IDS_SND_WHG_REVERSE				41089
#define IDS_SND_THG_NORMAL				41090
#define IDS_MOUSE_DISABLE				41091
#define IDS_MOUSE_ENABLE				41092
#define IDS_MOUSEMODE_ENBF11			41093
#define IDS_MOUSEMODE_DISF11			41094
#define IDS_COMM_OPENERROR				41095
#define IDS_COMM_THREADERROR			41096
#define IDS_MEDIA_NAME					41097
#define IDS_COINITERROR					41098
#define IDS_SWND_CPU_MAIN				41099
#define IDS_SWND_CPU_SUB				41100
#define IDS_SWND_SRCH_FOUND				41101
#define IDS_SWND_SRCH_NOTFOUND			41102
#define IDS_SWND_CPU_JSUB				41103
#define IDS_SWND_CPUREG_JSUB			41104
#define IDS_SWND_DISASM_JSUB			41105
#define IDS_SWND_MEMORY_JSUB			41106
#define IDS_SWND_BREAKPOINT_NONE		41122
#define IDS_JP_NOASSIGN					41107
#define IDS_GP_MAINCPU_LOW				41108
#define IDS_GP_SUBCPU_LOW				41109
#define IDS_GP_MAINCPU_Z80				41110
#define IDS_OP_MOUSESW_1				41112
#define IDS_OP_MOUSESW_2				41113
#define IDS_OP_MOUSESW_3				41114
#define IDS_SWND_PSGREG					41115
#define IDS_SWND_PSGDISP				41116
#define IDS_BAR_CAP						41117
#define IDS_BAR_KANA					41118
#define IDS_BAR_INS						41119
#define IDS_ENABLE_CYCLESTEAL			41120
#define IDS_DISABLE_CYCLESTEAL			41121
#define IDS_POP_NONE					IDS_SWND_BREAKPOINT_NONE
#define	IDS_POP_COM300					41123
#define	IDS_POP_COM600					41124
#define	IDS_POP_COM1200					41125
#define	IDS_POP_COM2400					41126
#define	IDS_POP_COM4800					41127
#define	IDS_SCP_400LINE					41128
#define	IDS_SCP_480LINE					41129
#define	IDS_SCP_WUXGA					41130
#define	IDS_SCP_SXGA					41131
#define	IDS_SCP_WXGA					41132
#define IDS_SWND_REG_MESSAGE			41133
#ifndef XM7DASH
#define	IDS_BBOPEN						41134
#endif
#define	IDS_B77FILTER					41135
#define	IDS_BBLFILTER					41136
#ifndef XM7DASH
#define	IDS_BBLFILE						41137
#endif
#define IDS_ABOUTURL					41200
#define IDS_ABOUTURL2					41201
#ifdef XM7DASH
#define IDS_ABOUTURLT					41202
#define IDS_ABOUTURL3					41203
#define IDS_ABOUTURL4					41204
#else
#define IDS_ABOUTURL3					41202
#define IDS_ABOUTURL4					41203
#endif
#define IDS_S98CAPFILTER				42000
#define IDS_S98CAPERROR					42001
#ifdef XM7DASH
#define IDS_SWND_OPNAREG				51119
#define IDS_SWND_IRQ_MAIN				51101
#define IDS_SWND_IRQ_SUB				51111
#define IDS_SWND_KANJI					51118
#define IDS_SWND_TAPE					51121
#define IDS_SWND_LP						51122
#define IDS_SWND_LOG					51114
#define IDS_SWND_LOG_NUMBER				IDS_KP_KEYNO
#define IDS_SWND_LOG_TIME				51116
#define IDS_SWND_LOG_MSG				51120
#define IDS_STP_BBLDRV					51102
#define IDS_STP_BBLFILE					51103
#define IDS_STP_DLGSIZE					51104
#define IDS_SAVECLOSE					51105
#define IDS_SETTITLEOK					51106
#define IDS_LANGUAGE					51107
#define IDS_HISTORY_DELETE				51108
#define IDS_FILE_NOT_FOUND				51109
#define	IDS_SCP_RASTER_FILTER			51110
#define IDS_STP_BBLMEDIA				51112
#define	IDS_SCP_USER					51113
#define	IDS_FMGEN_BUILDIN				51115
#define	IDS_NO_FILTER					51117
#endif

#endif	/* _WIN32 */
