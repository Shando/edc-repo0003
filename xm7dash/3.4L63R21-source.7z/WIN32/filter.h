// ---------------------------------------------------------------------------
//	�O���摜�t�B���^DLL ���p�w�b�_ filter.h
//	Copyright (C) 2013-2014 895���y�̂�PC�zPC�G�~�����[�^�[�����X���b�h Part5
//	Copyright (C) 2013-2015 Toma
// ---------------------------------------------------------------------------

#ifndef FILTER_H
#define FILTER_H

#include <windows.h>

//	�t�B���^�[�g�p�L��(i/o)
#define	FILTER_FLAG_FILTER		0x00000001
//	Create���v���^�C�v(i) 0:HWND or 1:HDC
#define	FILTER_FLAG_CREATE_HDC	0x00000002
//	Render���v���^�C�v(i) 0:addr or 1:HDC
#define	FILTER_FLAG_RENDER_HDC	0x00000004
//	Draw���v���^�C�v(i) 0:HWND or 1:HDC
#define	FILTER_FLAG_DRAW_HDC	0x00000008
//	dll�������������ݎ�Lock/Unlock���K�v(i)(dll����DirectX�n�̏ꍇ)
#define	FILTER_FLAG_LOCK		0x00000010
//	dll�����ň����s�N�Z���t�H�[�}�b�g(i)(8/15/16/24/32)Byte
#define	FILTER_FLAG_PIXEL_MASK	0x0000ff00
#define	FILTER_FLAG_PIXEL_SHIFT	8
//	��ʃ��[�h��dll�ˑ�

typedef	DWORD (__cdecl *DLLFUNC0)(void);
typedef	DWORD (__cdecl *DLLFUNC1)(LPVOID);
typedef	DWORD (__cdecl *DLLFUNC2)(LPVOID, DWORD);
typedef	DWORD (__cdecl *DLLFUNC4)(LPVOID, DWORD, DWORD, DWORD);
typedef	DWORD (__cdecl *DLLFUNC5)(LPVOID, DWORD, DWORD, DWORD, DWORD);
typedef	DWORD (__cdecl *DLLFUNC6)(LPVOID, DWORD, DWORD, DWORD, DWORD, DWORD);
typedef	DWORD (__cdecl *DLLFUNC7)(LPVOID, DWORD, DWORD, DWORD, DWORD, DWORD, DWORD);
typedef	DWORD (__cdecl *DLLFUNC8)(LPVOID, DWORD, DWORD, DWORD, DWORD, DWORD, DWORD, DWORD);
typedef	DWORD (__cdecl *DLLFUNC10)(LPVOID, DWORD, DWORD, DWORD, DWORD, DWORD, DWORD, DWORD, DWORD, DWORD);

#define	FILTER_VERSION	100

typedef struct {
	DWORD	dwSize;
	DWORD	dwFlags;	// FILTER_FLAG_*�Q��
	DWORD	dwWidth;
	DWORD	dwHeight;
	DWORD	dwPitch;
	LPVOID	lpSurface;
} FILTERDESC, *LPFILTERDESC;

class CFILTER
{
private:
	HMODULE	hDll;

	DLLFUNC5	filter_create;
	DLLFUNC1	filter_release;
	DLLFUNC2	filter_lock;
	DLLFUNC1	filter_unlock;
	DLLFUNC4	filter_render;
	DLLFUNC8	filter_render2;
	DLLFUNC6	filter_draw;
	DLLFUNC10	filter_draw2;
	DLLFUNC2	filter_setfilter;
	DLLFUNC1	filter_getdc;
	DLLFUNC2	filter_getdesc;
	DLLFUNC1	filter_getcaps;
	DLLFUNC1	filter_getver;

public:
	CFILTER(LPCTSTR lpFilename) {
		hDll = LoadLibrary(lpFilename);
		if (hDll) {
			filter_create = (DLLFUNC5) GetProcAddress(hDll, "filter_create");
			filter_release = (DLLFUNC1) GetProcAddress(hDll, "filter_release");
			filter_lock = (DLLFUNC2) GetProcAddress(hDll, "filter_lock");
			filter_unlock = (DLLFUNC1) GetProcAddress(hDll, "filter_unlock");
			filter_render = (DLLFUNC4) GetProcAddress(hDll, "filter_render");
			filter_render2 = (DLLFUNC8) GetProcAddress(hDll, "filter_render2");
			filter_draw = (DLLFUNC6) GetProcAddress(hDll, "filter_draw");
			filter_draw2 = (DLLFUNC10) GetProcAddress(hDll, "filter_draw2");
			filter_setfilter = (DLLFUNC2) GetProcAddress(hDll, "filter_setfilter");
			filter_getdc = (DLLFUNC1) GetProcAddress(hDll, "filter_getdc");
			filter_getdesc = (DLLFUNC2) GetProcAddress(hDll, "filter_getdesc");
			filter_getcaps = (DLLFUNC1) GetProcAddress(hDll, "filter_getcaps");
			filter_getver = (DLLFUNC1) GetProcAddress(hDll, "filter_getver");
		}
	}

	~CFILTER() {
		if (hDll) {
			FreeLibrary(hDll);
			hDll = NULL;
		}
	}

	//	DLL�̑��݃t���O
	BOOL IsDll() {
		return (hDll ? TRUE : FALSE);
	}

	//	�쐬(&pFilter�Ȃ̂ɒ���)
	//	���OpFilter��NULL���������Ă�����
	//	dwWidth,dwHeight�\�[�X�T�C�Y
	//	bFilter�̓t�B���^�̗L��
	BOOL Create(LPVOID *pFilter, DWORD hWnd, DWORD dwWidth, DWORD dwHeight, DWORD dwFilter) {
		if (hDll && filter_create) {
			return filter_create(pFilter, (DWORD) hWnd, dwWidth, dwHeight, dwFilter);
		}
		return FALSE;
	}

	//	�J��
	BOOL Release(LPVOID pFilter) {
		if (hDll && filter_release) {
			return filter_release(pFilter);
		}
		return FALSE;
	}

	BOOL Lock(LPVOID pFilter, LPFILTERDESC lpsdesc) {
		if (hDll && filter_lock) {
			return filter_lock(pFilter, (DWORD) lpsdesc);
		}
		return FALSE;
	}

	BOOL Unlock(LPVOID pFilter) {
		if (hDll && filter_unlock) {
			return filter_unlock(pFilter);
		}
		return FALSE;
	}

	//	dwDst/dwSrc��HDC��HWND
	//	dwPitch�̓\�[�X(HDC�̏ꍇ�͖��������)
	BOOL Render(LPVOID pFilter, DWORD dwDst, DWORD dwSrc, DWORD dwPitch) {
		if (hDll && filter_render) {
			return filter_render(pFilter, dwDst, dwSrc, dwPitch);
		}
		return FALSE;
	}

	BOOL Render2(LPVOID pFilter, DWORD dwDst, DWORD dwSrc, DWORD dwX, DWORD dwY, DWORD dwWidth, DWORD dwHeight, DWORD dwPitch) {
		if (hDll && filter_render2) {
			return filter_render2(pFilter, dwDst, dwSrc, dwX, dwY, dwWidth, dwHeight, dwPitch);
		}
		return FALSE;
	}

	//	�t�B���^������̃T�C�Y
	//	��2������HWND��HDC��DLL���̗v������
	BOOL Draw(LPVOID pFilter, DWORD hWnd, DWORD dwX, DWORD dwY, DWORD dwWidth, DWORD dwHeight) {
		if (hDll && filter_draw) {
			return filter_draw(pFilter, (DWORD) hWnd, dwX, dwY, dwWidth, dwHeight);
		}
		return FALSE;
	}

	//	�Ȃ�ׂ�Draw
	BOOL Draw2(LPVOID pFilter, DWORD hWnd, DWORD dwDstX, DWORD dwDstY, DWORD dwDstWidth, DWORD dwDstHeight, DWORD dwSrcX, DWORD dwSrcY, DWORD dwSrcWidth, DWORD dwSrcHeight) {
		if (hDll && filter_draw2) {
			return filter_draw2(pFilter, (DWORD) hWnd,
				dwDstX, dwDstY, dwDstWidth, dwDstHeight,
				dwSrcX, dwSrcY, dwSrcWidth, dwSrcHeight
			);
		}
		return FALSE;
	}

	BOOL SetFilter(LPVOID pFilter, DWORD dwFlags) {
		if (hDll && filter_setfilter) {
			return filter_setfilter(pFilter, dwFlags);
		}
		return FALSE;
	}

	DWORD GetDC(LPVOID pFilter) {
		if (hDll && filter_getdc) {
			return filter_getdc(pFilter);
		}
		return 0;	// �T�|�[�g���Ă��Ȃ�
	}

	DWORD GetVer(LPVOID pFilter) {
		if (hDll && filter_getver) {
			return filter_getver(pFilter);
		}
		return 0;
	}

	DWORD GetCaps(LPVOID pFilter) {
		if (hDll && filter_getcaps) {
			return filter_getcaps(pFilter);
		}
		return 0;
	}

	BOOL GetDesc(LPVOID pFilter, LPFILTERDESC lpsdesc) {
		if (hDll && filter_getdesc) {
			return filter_getdesc(pFilter, (DWORD) lpsdesc);
		}
		return FALSE;
	}
};
#endif // FILTER_H
