/*
 *	FM-7 EMULATOR "XM7"
 *
 *	Copyright (C) 1999-2014 �o�h�D(yasushi@tanaka.net)
 *	Copyright (C) 2001-2014 Ryu Takegami
 *	Copyright (C) 2010-2015 Toma
 *
 *	[ Win32API �T�u�E�B���h�E�Q ]
 */

#ifdef _WIN32

#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <assert.h>
#include <stdlib.h>
#include "xm7.h"
#include "fdc.h"
#include "opn.h"
#include "subctrl.h"
#if XM7_VER >= 3 || (XM7_VER == 1 && defined(SFDC) && defined(XM7DASH))
#include "dmac.h"
#endif
#include "display.h"
#include "aluline.h"
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
#include "mainetc.h"
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
#if XM7_VER == 1 && defined(BUBBLE)
#include "bubble.h"
#endif
#include "w32.h"
#include "w32_res.h"
#include "w32_snd.h"
#include "w32_sub.h"
#include "w32_kbd.h"
#include "w32_draw.h"

/*
 *	�X�^�e�B�b�N ���[�N
 */
static BYTE *pFDC;						/* FDC Draw�o�b�t�@ */
static BYTE *pOPNReg;					/* OPN���W�X�^ Draw�o�b�t�@ */
static UINT nOPNReg;					/* OPN���W�X�^ ���x�� */
static BYTE *pOPNDisp;					/* OPN�f�B�X�v���C �r�b�g�}�b�v�o�b�t�@ */
static HBITMAP hOPNDisp;				/* OPN�f�B�X�v���C �r�b�g�}�b�v�n���h�� */
static RECT rOPNDisp;					/* OPN�f�B�X�v���C ��` */
static UINT nOPNDisp;					/* OPN�f�B�X�v���C ���x�� */
#if defined(XM7DASH) && defined(OPNAMODE)
static int knOPNDisp[27];				/* OPN�f�B�X�v���C ���Ճ��[�N */
static int ktOPNDisp[27];				/* OPN�f�B�X�v���C ���Ճ��[�N */
static BYTE cnOPNDisp[27][49 * 2];		/* OPN�f�B�X�v���C �������[�N */
static BYTE ctOPNDisp[27][49 * 2];		/* OPN�f�B�X�v���C �������[�N */
static int lnOPNDisp[27];				/* OPN�f�B�X�v���C ���x�����[�N */
static int ltOPNDisp[27];				/* OPN�f�B�X�v���C ���x�����[�N */
#else
static int knOPNDisp[18];				/* OPN�f�B�X�v���C ���Ճ��[�N */
static int ktOPNDisp[18];				/* OPN�f�B�X�v���C ���Ճ��[�N */
static BYTE cnOPNDisp[18][49 * 2];		/* OPN�f�B�X�v���C �������[�N */
static BYTE ctOPNDisp[18][49 * 2];		/* OPN�f�B�X�v���C �������[�N */
static int lnOPNDisp[18];				/* OPN�f�B�X�v���C ���x�����[�N */
static int ltOPNDisp[18];				/* OPN�f�B�X�v���C ���x�����[�N */
#endif
static BYTE *pSubCtrl;					/* �T�u�R���g���[�� Draw�o�b�t�@ */
#if XM7_VER >= 2
static BYTE *pALULine;					/* �_�����Z/������� Draw�o�b�t�@ */
#endif
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
static UINT nFDC;						/* FDC ���x�� */
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
#if XM7_VER == 1 && defined(BUBBLE)
static BYTE *pBMC;						/* BMC Draw�o�b�t�@ */
#ifdef XM7DASH
static UINT nBMC;						/* BMC ���x�� */
#endif
#endif

/*
 *	�p���b�g�e�[�u��
 */
static const RGBQUAD rgbOPNDisp[] = {
	/*  B     G     R   Reserve */
	{ 0x00, 0x00, 0x00, 0x00 },
	{ 0xff, 0x00, 0x00, 0x00 },
	{ 0x00, 0x00, 0xff, 0x00 },
	{ 0xff, 0x00, 0xff, 0x00 },
	{ 0x00, 0xff, 0x00, 0x00 },
	{ 0xff, 0xff, 0x00, 0x00 },
	{ 0x00, 0xff, 0xff, 0x00 },
	{ 0xff, 0xff, 0xff, 0x00 },

	{ 0x3f, 0x3f, 0x3f, 0x00 },	/* �ÊD */
	{ 0xff, 0xbf, 0x00, 0x00 },	/* ���F */
	{ 0x00, 0xdf, 0xff, 0x00 },	/* ���F */
	{ 0x00, 0xaf, 0x7f, 0x00 },	/* ���� */
	{ 0xbf, 0x9f, 0xff, 0x00 },	/* �Î� */
	{ 0x9f, 0xff, 0x3f, 0x00 },	/* �G�������h�O���[��(��) */
	{ 0x7f, 0xbf, 0x00, 0x00 }, /* �G�������h�O���[��(��) */
	{ 0xcf, 0xcf, 0xcf, 0x00 },	/* ���D */
};

/*-[ �T�uCPU�R���g���[���E�C���h�E ]-----------------------------------------*/

/*
 *	�T�uCPU�R���g���[���E�C���h�E
 *	�Z�b�g�A�b�v(���LRAM)
 */
static void FASTCALL SetupSubCtrlShared(BYTE *p, int cx, int y)
{
	char string[128];
	char temp[4];
	int i, j;

	ASSERT(p);
	ASSERT(cx > 0);

	/* �^�C�g�� */
	strncpy(string, "Shared RAM:", 128);
	memcpy(&p[cx * y], string, strlen(string));
	y++;

	/* ���[�v */
	for (i=0; i<8; i++) {
		/* ������쐬 */
		_snprintf(string, 128, "+%02X:", i * 16);
		for (j=0; j<16; j++) {
			_snprintf(temp, 4, " %02X", shared_ram[i * 16 + j]);
			strncat(string, temp, 128 - strlen(string) - 1);
		}

		/* �Z�b�g */
		memcpy(&p[cx * y], string, strlen(string));
		y++;
	}
}

/*
 *	�T�uCPU�R���g���[���E�C���h�E
 *	�Z�b�g�A�b�v(�t���O)
 */
static void FASTCALL SetupSubCtrlFlag(BYTE *p, int cx, int x, int y,
									char *title, BOOL flag)
{
	char string[32];

	ASSERT(p);
	ASSERT(cx > 0);

	/* ������ */
	memset(string, 0x20, sizeof(string));

	/* �^�C�g���Z�b�g */
	memcpy(string, title, strlen(title));

	/* On�܂���Off */
	if (flag) {
#ifdef XM7DASH
		strncpy(&string[20], "On", sizeof(string)-20);
#else
		strncpy(&string[20], "On", 12);
#endif
	}
	else {
#ifdef XM7DASH
		strncpy(&string[19], "Off", sizeof(string)-19);
#else
		strncpy(&string[19], "Off", 11);
#endif
	}

	/* �Z�b�g */
	memcpy(&p[cx * y + x], string, strlen(string));
}


#if XM7_VER == 1 && defined(L4CARD)
/*
 *	�T�uCPU�R���g���[���E�C���h�E
 *	�Z�b�g�A�b�v(CRTC���W�X�^)
 */
static void FASTCALL SetupSubCtrlCRTC(BYTE *p, int cx, int y)
{
	char string[128];
	char temp[4];
	int i, j;

	ASSERT(p);
	ASSERT(cx > 0);

	/* �^�C�g�� */
	strncpy(string, "CRTC Register:", 128);
	memcpy(&p[cx * y], string, strlen(string));
	y++;

	/* ���[�v */
	for (i=0; i<2; i++) {
		/* ������쐬 */
		_snprintf(string, 128, "+%02X:", i * 16);
		for (j=0; j<16; j++) {
			_snprintf(temp, 4, " %02X", crtc_register[i * 16 + j]);
			if (((i * 16 + j) == crtc_regnum) && enable_400line) {
				temp[1] |= 0x80;
				temp[2] |= 0x80;
			}
			strncat(string, temp, 128 - strlen(string) - 1);
		}

		/* �Z�b�g */
		memcpy(&p[cx * y], string, strlen(string));
		y++;
	}
}
#endif

/*
 *	�T�uCPU�R���g���[���E�C���h�E
 *	�Z�b�g�A�b�v
 */
static void FASTCALL SetupSubCtrl(BYTE *p, int x, int y)
{
#if XM7_VER >= 3
#define	YOFS	7
#else
#define	YOFS	6
#endif

	char string[128];

	ASSERT(p);
	ASSERT(x > 0);
	ASSERT(y > 0);

	/* ��U�X�y�[�X�Ŗ��߂� */
	memset(p, 0x20, x * y);

	/* FM-7�݊��t���O */
	SetupSubCtrlFlag(p, x,  0, 0, "Sub Halt", subhalt_flag);
	SetupSubCtrlFlag(p, x,  0, 1, "Busy Flag", subbusy_flag);
	SetupSubCtrlFlag(p, x,  0, 2, "CRT Display", crt_flag);
	SetupSubCtrlFlag(p, x, 30, 0, "Cancel IRQ", subcancel_flag);
	SetupSubCtrlFlag(p, x, 30, 1, "Attention FIRQ", subattn_flag);
	SetupSubCtrlFlag(p, x, 30, 2, "VRAM Access Flag", vrama_flag);

#if XM7_VER >= 2
	/* �T�u���j�^ROM */
	strncpy(string, "Sub Monitor", 128);
	memcpy(&p[x * 4 + 0], string, strlen(string));
	switch (subrom_bank) {
		case 0:
			strncpy(string, "Type-C", 128);
			break;
		case 1:
			strncpy(string, "Type-A", 128);
			break;
		case 2:
			strncpy(string, "Type-B", 128);
			break;
		case 3:
			strncpy(string, "CG ROM", 128);
			break;
#if XM7_VER >= 3
		case 4:
			strncpy(string, "   RAM", 128);

			/* Type-D/E��F�� */
			if ((subramde[0x1fe0] == 'S') &&
				(subramde[0x1fe1] == 'U') &&
				(subramde[0x1fe2] == 'B') &&
				(subramde[0x1fe3] == '8')) {
				if (subramde[0x1fe4] == 'A') {
					strncpy(string,"Type-D", 128);
				}
				else if (subramde[0x1fe4] == 'B') {
					strncpy(string,"Type-E", 128);
				}
			}
			break;
#endif
		default:
			ASSERT(FALSE);
			break;
	}
	memcpy(&p[x * 4 + 16], string, strlen(string));

	/* 320���[�h */
	strncpy(string, "Display Mode", 128);
	memcpy(&p[x * 4 + 30], string, strlen(string));
#if XM7_VER >= 3
	if (mode400l) {
		strncpy(string, "640x400", 128);
	}
	else if (mode256k) {
		strncpy(string, "262,144", 128);
	}
	else if (mode320) {
#else
	if (mode320) {
#endif
		strncpy(string, "320x200", 128);
	}
	else {
		strncpy(string, "640x200", 128);
	}
	memcpy(&p[x * 4 + 45], string, strlen(string));

	/* CG�o���N */
#if XM7_VER >= 3
	if (subrom_bank == 4) {
		strncpy(string, "CG RAM", 128);
		memcpy(&p[x * 5 + 0], string, strlen(string));
		_snprintf(string, 128, "Bank %1d", cgram_bank);
	}
	else {
		strncpy(string, "CG ROM", 128);
		memcpy(&p[x * 5 + 0], string, strlen(string));
		_snprintf(string, 128, "Bank %1d", cgrom_bank);
	}
#else
	strncpy(string, "CG ROM", 128);
	memcpy(&p[x * 5 + 0], string, strlen(string));
	_snprintf(string, 128, "Bank %1d", cgrom_bank);
#endif
	memcpy(&p[x * 5 + 16], string, strlen(string));

	/* �T�u���Z�b�g */
	strncpy(string, "Sub Reset", 128);
	memcpy(&p[x * 5 + 30], string, strlen(string));
	if (subreset_flag) {
		strncpy(string, "Software", 128);
	}
	else {
		strncpy(string, "Hardware", 128);
	}
	memcpy(&p[x * 5 + 44], string, strlen(string));

	/* VRAM�I�t�Z�b�g���W�X�^0 */
	strncpy(string, "VRAM Offset 0", 128);
	memcpy(&p[x * (YOFS + 0) + 30], string, strlen(string));
	_snprintf(string, 128, "$%04X", vram_offset[0]);
	memcpy(&p[x * (YOFS + 0) + 47], string, strlen(string));

	/* VRAM�I�t�Z�b�g���W�X�^1 */
	strncpy(string, "VRAM Offset 1", 128);
	memcpy(&p[x * (YOFS + 1) + 30], string, strlen(string));
	_snprintf(string, 128, "$%04X", vram_offset[1]);
	memcpy(&p[x * (YOFS + 1) + 47], string, strlen(string));

	/* �A�N�e�B�u�y�[�W */
	strncpy(string, "Active Page", 128);
	memcpy(&p[x * (YOFS + 0) + 0], string, strlen(string));
#if XM7_VER >= 3
	if (screen_mode & SCR_AV40) {
		_snprintf(string, 128, "Page %1d", subram_vrambank);
	}
	else {
		_snprintf(string, 128, "Page %1d", vram_active);
	}
#else
	_snprintf(string, 128, "Page %1d", vram_active);
#endif
	memcpy(&p[x * (YOFS + 0) + 16], string, strlen(string));

	/* �\���y�[�W */
	strncpy(string, "Display Page", 128);
	memcpy(&p[x * (YOFS + 1) + 0], string, strlen(string));
	_snprintf(string, 128, "Page %1d", vram_display);
	memcpy(&p[x * (YOFS + 1) + 16], string, strlen(string));

#if XM7_VER >= 3
	/* �R���\�[��RAM�o���N */
	strncpy(string, "Console RAM", 128);
	memcpy(&p[x * 6 + 0], string, strlen(string));
	if (subrom_bank == 4) {
		_snprintf(string, 128, "Bank %1d", consram_bank);
	}
	else {
		_snprintf(string, 128, "Bank 0");
	}
	memcpy(&p[x * 6 + 16], string, strlen(string));

	/* �T�u���j�^RAM�v���e�N�g */
	strncpy(string, "Sub Protect", 128);
	memcpy(&p[x * 6 + 30], string, strlen(string));
	if (subram_protect) {
		strncpy(string, " Enable", 128);
	}
	else {
		strncpy(string, "Disable", 128);
	}
	memcpy(&p[x * 6 + 45], string, strlen(string));

	/* �A�N�e�B�u�u���b�N */
	strncpy(string, "Active Block", 128);
	memcpy(&p[x * 9 + 0], string, strlen(string));
	_snprintf(string, 128, "Block %1d", block_active);
	memcpy(&p[x * 9 + 15], string, strlen(string));

	/* �\���u���b�N */
	strncpy(string, "Display Block", 128);
	memcpy(&p[x * 10 + 0], string, strlen(string));
	_snprintf(string, 128, "Block %1d", block_display);
	memcpy(&p[x * 10 + 15], string, strlen(string));

	/* �n�[�h�E�F�A�E�B���h�E */
	strncpy(string, "Window Start", 128);
	memcpy(&p[x * 9 + 30], string, strlen(string));
	strncpy(string, "Window End", 128);
	memcpy(&p[x * 10 + 30], string, strlen(string));
	if (window_open) {
		_snprintf(string, 128, "(%3d,%3d)", window_dx1, window_dy1);
		memcpy(&p[x * 9 + 43], string, strlen(string));
		_snprintf(string, 128, "(%3d,%3d)", window_dx2 - 1, window_dy2 - 1);
	}
	else {
		strncpy(string, "(  0,  0)", 128);
		memcpy(&p[x * 9 + 43], string, strlen(string));
	}
	memcpy(&p[x * 10 + 43], string, strlen(string));

	/* ���LRAM */
	SetupSubCtrlShared(p, x, 12);
#else
	/* ���LRAM */
	SetupSubCtrlShared(p, x, 9);
#endif
#elif defined(L4CARD)
	/* ��ʃ��[�h */
	strncpy(string, "Display Mode", 128);
	memcpy(&p[x * 4 + 0], string, strlen(string));
	if (enable_400line) {
		strncpy(string, "640x400", 128);
	}
	else {
		strncpy(string, "640x200", 128);
	}
	memcpy(&p[x * 4 + 15], string, strlen(string));

	/* VRAM�I�t�Z�b�g���W�X�^ */
	strncpy(string, "VRAM Offset", 128);
	memcpy(&p[x * 4 + 30], string, strlen(string));
	_snprintf(string, 128, "$%04X", vram_offset[0]);
	memcpy(&p[x * 4 + 47], string, strlen(string));

	/* �e�L�X�g�X�^�[�g�A�h���X */
	strncpy(string, "Text Start Addr", 128);
	memcpy(&p[x * 5 + 0], string, strlen(string));
	_snprintf(string, 128, "$%04X", text_start_addr);
	memcpy(&p[x * 5 + 17], string, strlen(string));

	/* �J�[�\���A�h���X���W�X�^ */
	strncpy(string, "Cursor Address", 128);
	memcpy(&p[x * 5 + 30], string, strlen(string));
	_snprintf(string, 128, "$%04X", cursor_addr);
	memcpy(&p[x * 5 + 47], string, strlen(string));

	/* CRTC���W�X�^ */
	SetupSubCtrlCRTC(p, x, 7);

	/* ���LRAM(V1,L4) */
	SetupSubCtrlShared(p, x, 11);
#else
	/* ���LRAM(V1,L2) */
	SetupSubCtrlShared(p, x, 4);
#endif
#undef	YOFS
}


/*
 *	�T�uCPU�R���g���[���E�C���h�E
 *	�`��
 */
static void FASTCALL DrawSubCtrl(HWND hWnd, HDC hDC)
{
	RECT rect;
	int x, y;

	ASSERT(hWnd);
	ASSERT(hDC);

	/* �E�C���h�E�W�I���g���𓾂� */
	GetClientRect(hWnd, &rect);
	x = rect.right / lCharWidth;
	y = rect.bottom / lCharHeight;
	if ((x == 0) || (y == 0)) {
		return;
	}

	/* �Z�b�g�A�b�v */
	if (!pSubCtrl) {
		return;
	}
	SetupSubCtrl(pSubCtrl, x, y);

	/* �`�� */
#if XM7_VER == 1 && defined(L4CARD)
	DrawWindowText2(hDC, pSubCtrl, x, y);
#else
	DrawWindowText(hDC, pSubCtrl, x, y);
#endif
}

/*
 *	�T�uCPU�R���g���[���E�C���h�E
 *	���t���b�V��
 */
void FASTCALL RefreshSubCtrl(void)
{
	HWND hWnd;
	HDC hDC;

	/* ��ɌĂ΂��̂ŁA���݃`�F�b�N���邱�� */
	if (hSubWnd[SWND_SUBCTRL] == NULL) {
		return;
	}

	/* �`�� */
	hWnd = hSubWnd[SWND_SUBCTRL];
	hDC = GetDC(hWnd);
	DrawSubCtrl(hWnd, hDC);
	ReleaseDC(hWnd, hDC);
}

/*
 *	�T�uCPU�R���g���[���E�C���h�E
 *	�ĕ`��
 */
static void FASTCALL PaintSubCtrl(HWND hWnd)
{
	HDC hDC;
	PAINTSTRUCT ps;
	RECT rect;
	BYTE *p;
	int x, y;

	ASSERT(hWnd);

	/* �|�C���^��ݒ�(���݂��Ȃ���Ή������Ȃ�) */
	p = pSubCtrl;
	if (!p) {
		return;
	}

	/* �E�C���h�E�W�I���g���𓾂� */
	GetClientRect(hWnd, &rect);
	x = rect.right / lCharWidth;
	y = rect.bottom / lCharHeight;

	/* �㔼�G���A��FF�Ŗ��߂� */
	if ((x > 0) && (y > 0)) {
		memset(&p[x * y], 0xff, x * y);
	}

	/* �`�� */
	hDC = BeginPaint(hWnd, &ps);
	ASSERT(hDC);
	DrawSubCtrl(hWnd, hDC);
	EndPaint(hWnd, &ps);
}

/*
 *	�T�uCPU�R���g���[���E�C���h�E
 *	�E�C���h�E�v���V�[�W��
 */
static LRESULT CALLBACK SubCtrlProc(HWND hWnd, UINT message,
								 WPARAM wParam, LPARAM lParam)
{
	/* ���b�Z�[�W�� */
	switch (message) {
		/* �E�C���h�E�ĕ`�� */
		case WM_PAINT:
			/* ���b�N���K�v */
			LockVM();
			PaintSubCtrl(hWnd);
			UnlockVM();
			return 0;

		/* �E�C���h�E�폜 */
		case WM_DESTROY:
			LockVM();

			/* ���C���E�C���h�E�֎����ʒm */
			DestroySubWindow(hWnd, &pSubCtrl, NULL);

			UnlockVM();
			break;

#ifdef XM7DASH
		/* �E�B���h�E�ړ� */
		case WM_MOVE:
			/* �ŏ������̃T�u�E�B���h�E���Ҕ� */
			MoveSubWindow(hWnd);
			break;
#endif
	}

	/* �f�t�H���g �E�C���h�E�v���V�[�W�� */
	return DefWindowProc(hWnd, message, wParam, lParam);
}

/*
 *	�T�uCPU�R���g���[���E�C���h�E
 *	�E�C���h�E�쐬
 */
HWND FASTCALL CreateSubCtrl(HWND hParent, int index)
{
	WNDCLASSEX wcex;
	char szClassName[] = "XM7_SubCtrl";
	char szWndName[128];
	RECT rect;
	RECT crect, wrect;
	HWND hWnd;
#ifdef XM7DASH
	DWORD dwExStyle;
#endif

	ASSERT(hParent);

	/* �E�C���h�E��`���v�Z */
#ifdef XM7DASH
	PositioningSubWindow(hParent, &rect, index);
#else
	rect.left = lCharWidth * index;
	rect.top = lCharHeight * index;
	if (rect.top >= 380) {
		rect.top -= 380;
	}
#endif
	rect.right = lCharWidth * 52;
#if XM7_VER >= 3
	rect.bottom = lCharHeight * 21;
#elif XM7_VER >= 2
	rect.bottom = lCharHeight * 18;
#elif defined(L4CARD)
	rect.bottom = lCharHeight * 20;
#else
	rect.bottom = lCharHeight * 13;
#endif

	/* �E�C���h�E�^�C�g��������A�o�b�t�@�m�� */
	LoadString(hResInstance, IDS_SWND_SUBCTRL,
				szWndName, sizeof(szWndName));
	pSubCtrl = malloc(2 * (rect.right / lCharWidth) *
								(rect.bottom / lCharHeight));

	/* �E�C���h�E�N���X�̓o�^ */
	memset(&wcex, 0, sizeof(wcex));
	wcex.cbSize = sizeof(wcex);
	wcex.style = CS_VREDRAW | CS_HREDRAW;
	wcex.lpfnWndProc = SubCtrlProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hResInstance;
	wcex.hIcon = LoadIcon(hAppInstance, MAKEINTRESOURCE(IDI_WNDICON));
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = szClassName;
	wcex.hIconSm = LoadIcon(hAppInstance, MAKEINTRESOURCE(IDI_WNDICON));
	RegisterClassEx(&wcex);

	/* �E�C���h�E�쐬 */
#ifdef XM7DASH
	if (bPopupSwnd) {
		dwExStyle =	WS_POPUP | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
					| WS_MINIMIZEBOX | WS_BORDER;
	}
	else {
		dwExStyle = WS_CHILD | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
					| WS_MINIMIZEBOX | WS_CLIPSIBLINGS;
	}
	if (bSwndVisible) {
		dwExStyle |= WS_VISIBLE;
	}
	hWnd = CreateWindow(szClassName,
						szWndName,
						dwExStyle,
						rect.left,
						rect.top,
						rect.right,
						rect.bottom,
						hParent,
						NULL,
						hResInstance,
						NULL);
#else
	hWnd = CreateWindow(szClassName,
						szWndName,
						WS_CHILD | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
						| WS_VISIBLE | WS_MINIMIZEBOX | WS_CLIPSIBLINGS,
						rect.left,
						rect.top,
						rect.right,
						rect.bottom,
						hParent,
						NULL,
						hResInstance,
						NULL);
#endif

	/* �L���Ȃ�A�T�C�Y�␳���Ď�O�ɒu�� */
	if (hWnd) {
		GetWindowRect(hWnd, &wrect);
		GetClientRect(hWnd, &crect);
		wrect.right += (rect.right - crect.right);
		wrect.bottom += (rect.bottom - crect.bottom);
		SetWindowPos(hWnd, HWND_TOP, wrect.left, wrect.top,
			wrect.right - wrect.left, wrect.bottom - wrect.top, SWP_NOMOVE);
	}

	/* ���ʂ������A�� */
	return hWnd;
}

/*-[ �_�����Z/������ԃE�C���h�E ]-------------------------------------------*/

#if XM7_VER >= 2
/*
 *	�_�����Z/������ԃE�C���h�E
 *	�Z�b�g�A�b�v
 */
static void FASTCALL SetupALULine(BYTE *p, int x, int y)
{
	static const char *ALUString[8] = {
		"PSET", "----", " OR ", " AND", " XOR", " NOT", "TILE", " CMP"
	};

	char string[128];
	int i;

	ASSERT(p);
	ASSERT(x > 0);
	ASSERT(y > 0);

	/* ��U�X�y�[�X�Ŗ��߂� */
	memset(p, 0x20, x * y);

	/* �_�����Z�R�}���h */
	strncpy(string, "ALU", 128);
	memcpy(&p[x * 0 + 0], string, strlen(string));
	if (alu_command & 0x80) {
		strncpy(string, ALUString[alu_command & 0x07], 128);
	}
	else {
		strncpy(string, " Off", 128);
	}
	memcpy(&p[x * 0 + 17], string, strlen(string));

	/* �������݃��[�h */
	strncpy(string, "Write Mode", 128);
	memcpy(&p[x * 1 + 0], string, strlen(string));
	if (alu_command & 0x40) {
		if (alu_command & 0x20) {
			strncpy(string, "Not Eq", 128);
		}
		else {
			strncpy(string, " Equal", 128);
		}
	}
	else {
		strncpy(string, "Always", 128);
	}
	memcpy(&p[x * 1 + 15], string, strlen(string));

	/* ���Z�J���[�f�[�^ */
	_snprintf(string, 128, "Color               %01d", alu_color & 0x07);
	memcpy(&p[x * 2 + 0], string, strlen(string));

	/* �}�X�N�r�b�g */
	_snprintf(string, 128, "Mask               %02X", alu_mask);
	memcpy(&p[x * 3 + 0], string, strlen(string));

	/* �R���y�A�r�b�g */
	strncpy(string, "Compare      --------", 128);
	for (i=0; i<8; i++) {
		if (~alu_cmpdat[i] & 0x80) {
			string[13 + i] = (char)(0x30 | (alu_cmpdat[i] & 0x07));
		}
	}
	memcpy(&p[x * 4 + 0], string, strlen(string));

	/* �f�B�Z�[�u���o���N */
	strncpy(string, "Disable           BRG", 128);
	for (i=0; i<3; i++) {
		if (~alu_disable & (1 << i)) {
			string[18 + i] = '-';
		}
	}
	memcpy(&p[x * 5 + 0], string, strlen(string));

	/* �^�C���y�C���g�f�[�^ */
	_snprintf(string, 128, "TILE   B:%02X R:%02X G:%02X",
		alu_tiledat[0], alu_tiledat[1], alu_tiledat[2]);
	memcpy(&p[x * 6 + 0], string, strlen(string));

	/* ������ԃX�e�[�^�X */
	strncpy(string, "Line LSI", 128);
	memcpy(&p[x * 0 + 25], string, strlen(string));
	if (line_busy) {
		strncpy(string, " Busy", 128);
	}
	else {
		strncpy(string, "Ready", 128);
	}
	memcpy(&p[x * 0 + 41], string, strlen(string));

	/* �A�h���X�I�t�Z�b�g */
	_snprintf(string, 128, "Offset           %04X", line_offset);
	memcpy(&p[x * 1 + 25], string, strlen(string));

	/* ���C���X�^�C�� */
	_snprintf(string, 128, "Line Style       %04X", line_style);
	memcpy(&p[x * 2 + 25], string, strlen(string));

	/* �n�_�E�I�_ */
	_snprintf(string, 128, "Line X0           %3d", line_x0);
	memcpy(&p[x * 3 + 25], string, strlen(string));
	_snprintf(string, 128, "Line Y0           %3d", line_y0);
	memcpy(&p[x * 4 + 25], string, strlen(string));
	_snprintf(string, 128, "Line X1           %3d", line_x1);
	memcpy(&p[x * 5 + 25], string, strlen(string));
	_snprintf(string, 128, "Line Y1           %3d", line_y1);
	memcpy(&p[x * 6 + 25], string, strlen(string));
}

/*
 *	�_�����Z/������ԃE�C���h�E
 *	�`��
 */
static void FASTCALL DrawALULine(HWND hWnd, HDC hDC)
{
	RECT rect;
	int x, y;

	ASSERT(hWnd);
	ASSERT(hDC);

	/* �E�C���h�E�W�I���g���𓾂� */
	GetClientRect(hWnd, &rect);
	x = rect.right / lCharWidth;
	y = rect.bottom / lCharHeight;
	if ((x == 0) || (y == 0)) {
		return;
	}

	/* �Z�b�g�A�b�v */
	if (!pALULine) {
		return;
	}
	SetupALULine(pALULine, x, y);

	/* �`�� */
	DrawWindowText(hDC, pALULine, x, y);
}

/*
 *	�_�����Z/������ԃE�C���h�E
 *	���t���b�V��
 */
void FASTCALL RefreshALULine(void)
{
	HWND hWnd;
	HDC hDC;

	/* ��ɌĂ΂��̂ŁA���݃`�F�b�N���邱�� */
	if (hSubWnd[SWND_ALULINE] == NULL) {
		return;
	}

	/* �`�� */
	hWnd = hSubWnd[SWND_ALULINE];
	hDC = GetDC(hWnd);
	DrawALULine(hWnd, hDC);
	ReleaseDC(hWnd, hDC);
}

/*
 *	�_�����Z/������ԃE�C���h�E
 *	�ĕ`��
 */
static void FASTCALL PaintALULine(HWND hWnd)
{
	HDC hDC;
	PAINTSTRUCT ps;
	RECT rect;
	BYTE *p;
	int x, y;

	ASSERT(hWnd);

	/* �|�C���^��ݒ�(���݂��Ȃ���Ή������Ȃ�) */
	p = pALULine;
	if (!p) {
		return;
	}

	/* �E�C���h�E�W�I���g���𓾂� */
	GetClientRect(hWnd, &rect);
	x = rect.right / lCharWidth;
	y = rect.bottom / lCharHeight;

	/* �㔼�G���A��FF�Ŗ��߂� */
	if ((x > 0) && (y > 0)) {
		memset(&p[x * y], 0xff, x * y);
	}

	/* �`�� */
	hDC = BeginPaint(hWnd, &ps);
	ASSERT(hDC);
	DrawALULine(hWnd, hDC);
	EndPaint(hWnd, &ps);
}

/*
 *	�_�����Z/������ԃE�C���h�E
 *	�E�C���h�E�v���V�[�W��
 */
static LRESULT CALLBACK ALULineProc(HWND hWnd, UINT message,
								 WPARAM wParam, LPARAM lParam)
{
	/* ���b�Z�[�W�� */
	switch (message) {
		/* �E�C���h�E�ĕ`�� */
		case WM_PAINT:
			/* ���b�N���K�v */
			LockVM();
			PaintALULine(hWnd);
			UnlockVM();
			return 0;

		/* �E�C���h�E�폜 */
		case WM_DESTROY:
			LockVM();

			/* ���C���E�C���h�E�֎����ʒm */
			DestroySubWindow(hWnd, &pALULine, NULL);

			UnlockVM();
			break;

#ifdef XM7DASH
		/* �E�B���h�E�ړ� */
		case WM_MOVE:
			/* �ŏ������̃T�u�E�B���h�E���Ҕ� */
			MoveSubWindow(hWnd);
			break;
#endif
	}

	/* �f�t�H���g �E�C���h�E�v���V�[�W�� */
	return DefWindowProc(hWnd, message, wParam, lParam);
}

/*
 *	�_�����Z/������ԃE�C���h�E
 *	�E�C���h�E�쐬
 */
HWND FASTCALL CreateALULine(HWND hParent, int index)
{
	WNDCLASSEX wcex;
	char szClassName[] = "XM7_ALULine";
	char szWndName[128];
	RECT rect;
	RECT crect, wrect;
	HWND hWnd;
#ifdef XM7DASH
	DWORD dwExStyle;
#endif

	ASSERT(hParent);

	/* �E�C���h�E��`���v�Z */
#ifdef XM7DASH
	PositioningSubWindow(hParent, &rect, index);
#else
	rect.left = lCharWidth * index;
	rect.top = lCharHeight * index;
	if (rect.top >= 380) {
		rect.top -= 380;
	}
#endif
	rect.right = lCharWidth * 46;
	rect.bottom = lCharHeight * 7;

	/* �E�C���h�E�^�C�g��������A�o�b�t�@�m�� */
	LoadString(hResInstance, IDS_SWND_ALULINE,
				szWndName, sizeof(szWndName));
	pALULine = malloc(2 * (rect.right / lCharWidth) *
								(rect.bottom / lCharHeight));

	/* �E�C���h�E�N���X�̓o�^ */
	memset(&wcex, 0, sizeof(wcex));
	wcex.cbSize = sizeof(wcex);
	wcex.style = CS_VREDRAW | CS_HREDRAW;
	wcex.lpfnWndProc = ALULineProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hResInstance;
	wcex.hIcon = LoadIcon(hAppInstance, MAKEINTRESOURCE(IDI_WNDICON));
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = szClassName;
	wcex.hIconSm = LoadIcon(hAppInstance, MAKEINTRESOURCE(IDI_WNDICON));
	RegisterClassEx(&wcex);

	/* �E�C���h�E�쐬 */
#ifdef XM7DASH
	if (bPopupSwnd) {
		dwExStyle =	WS_POPUP | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
					| WS_MINIMIZEBOX | WS_BORDER;
	}
	else {
		dwExStyle = WS_CHILD | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
					| WS_MINIMIZEBOX | WS_CLIPSIBLINGS;
	}
	if (bSwndVisible) {
		dwExStyle |= WS_VISIBLE;
	}
	hWnd = CreateWindow(szClassName,
						szWndName,
						dwExStyle,
						rect.left,
						rect.top,
						rect.right,
						rect.bottom,
						hParent,
						NULL,
						hResInstance,
						NULL);
#else
	hWnd = CreateWindow(szClassName,
						szWndName,
						WS_CHILD | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
						| WS_VISIBLE | WS_MINIMIZEBOX | WS_CLIPSIBLINGS,
						rect.left,
						rect.top,
						rect.right,
						rect.bottom,
						hParent,
						NULL,
						hResInstance,
						NULL);
#endif

	/* �L���Ȃ�A�T�C�Y�␳���Ď�O�ɒu�� */
	if (hWnd) {
		GetWindowRect(hWnd, &wrect);
		GetClientRect(hWnd, &crect);
		wrect.right += (rect.right - crect.right);
		wrect.bottom += (rect.bottom - crect.bottom);
		SetWindowPos(hWnd, HWND_TOP, wrect.left, wrect.top,
			wrect.right - wrect.left, wrect.bottom - wrect.top, SWP_NOMOVE);
	}

	/* ���ʂ������A�� */
	return hWnd;
}
#endif

/*-[ OPN�f�B�X�v���C�E�C���h�E ]---------------------------------------------*/

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	�h�b�g�`��
 */
static void FASTCALL PSetOPNDisp(int x, int y, int color)
{
	int w;
	BYTE *p;
	BYTE dat;

	ASSERT((x >= 0) && (x < rOPNDisp.right));
	ASSERT((y >= 0) && (y < rOPNDisp.bottom));
	ASSERT((color >= 0) && (color <= 15));

	/* rOPNDisp���A�r�b�g�}�b�v�̉��T�C�Y���v�Z(4�o�C�g�A���C�����g) */
	w = (((rOPNDisp.right / 2) + 3) >> 2) << 2;

	/* �A�h���X�A�f�[�^�擾 */
	if (!pOPNDisp) {
		return;
	}
	p = &pOPNDisp[w * y + (x >> 1)];
	dat = *p;

	/* �Q�ɕ����� */
	if (x & 1) {
		dat &= 0xf0;
		dat |= (BYTE)color;
	}
	else {
		dat &= 0x0f;
		dat |= (BYTE)(color << 4);
	}

	/* �������� */
	*p = dat;
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	�{�b�N�X�t�B���`��
 */
static void FASTCALL BfOPNDisp(int x, int y, int cx, int cy, int color)
{
	int i;
	int j;

	ASSERT((color >= 0) && (color < 16));

	for (i=0; i<cy; i++) {
		for (j=0; j<cx; j++) {
			PSetOPNDisp(x + j, y, color);
		}
		y++;
	}
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	���x�����[�^�`��
 */
static void FASTCALL LvlOPNDisp(int x, int y, int cx, int cy,
								int color1, int color2, int color3)
{
	int i;
	int j;

	ASSERT((color1 >= 0) && (color1 < 16));
	ASSERT((color2 >= 0) && (color2 < 16));
	ASSERT((color3 >= 0) && (color3 < 16));

	for (i=0; i<cy; i++) {
		for (j=0; j<cx; j++) {
			if ((j % 4) == 3) {
				PSetOPNDisp(x + j, y, 8);
			}
			else {
				if (j < 48) {
					PSetOPNDisp(x + j, y, color1);
				}
				else if (j < 80) {
					PSetOPNDisp(x + j, y, color2);
				}
				else {
					PSetOPNDisp(x + j, y, color3);
				}
			}
		}
		y++;
	}
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	�L�����N�^�`��
 */
static void FASTCALL ChrOPNDisp(char c, int x, int y, int color)
{
	int i;
	int j;
	BYTE *p;
	BYTE dat;

	ASSERT((color >= 0) && (color < 16));

	/* �T�uROM(C)�̃t�H���g�A�h���X�𓾂� */
	p = &subrom_c[c * 8];

	/* y���[�v */
	for (i=0; i<8; i++) {
		/* �f�[�^�擾 */
		dat = *p;
		p++;

		/* x���[�v */
		for (j=0; j<8; j++) {
			if (dat & 0x80) {
				PSetOPNDisp(x, y, color);
			}
			else {
				PSetOPNDisp(x, y, 0);
			}
			dat <<= 1;
			x++;
		}

		/* ����y�� */
		x -= 8;
		y++;
	}
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	���Օ`��
 *
 *	��ʃj�u��	�I�N�^�[�u 0�`7
 *	���ʃj�u��	C, C#, D, D#, E, F, F#, G, G#, A, A#, B
 *	x, y�̓g���b�N��̊�_�Bcolor=-1�̓f�t�H���g�J���[
 */
static void FASTCALL KbdOPNDisp(int code, int x, int y, int color)
{
	int i;
	int j;
	int ys;

	/* x���W�B��=5dot���A��=4dot���B���Ɣ��̌��Ԃ�1dot�}�� */
	static const int x_table[] = {
		0, 0+4, 6, 6+4, 12, 18, 18+4, 24, 24+4, 30, 30+4, 36
	};
	/* 0:�E���� 1:���E���� 2:������ 3:���� */
	static const int type_table[] = {
		0, 3, 1 ,3, 2, 0, 3, 1, 3, 1, 3, 2
	};

	ASSERT(code <= 0x7f);
	ASSERT((code & 0x0f) <= 0x0b);

	/* �c�T�C�Y���� */
#ifdef XM7DASH
#ifdef OPNAMODE
	if ((((nOPNDisp & 32) && ((nOPNDisp & 7) >= 1)) ||
		 ((nOPNDisp & 7) == 2)) && !bPopupSwnd) {
#else
	if (((nOPNDisp & 7) == 2) && !bPopupSwnd) {
#endif
#else
	if ((nOPNDisp & 7) == 2) {
#endif
		ys = 6;
	}
	else {
		ys = 8;
	}

	/* x�ʒu���� */
	x = (code >> 4) * 42;
	code &= 0x0f;
	x += x_table[code];

	/* �F�ݒ� */
	if (color < 0) {
		if (type_table[code] < 3) {
			color = 15;
		}
		else {
			color = 8;
		}
	}

	/* �^�C�v�� */
	switch (type_table[code]) {
		/* �����B�E���ɍ������� */
		case 0:
			/* ���Ԃ������� */
			for (i=0; i<ys * 2; i++) {
				PSetOPNDisp(x, y + i, 0);
			}
			/* ������� */
			for (i=0; i<ys; i++) {
				for (j=1; j<=3; j++) {
					PSetOPNDisp(x + j, y + i, color);
				}
			}
			/* ������� */
			for (i=0; i<ys; i++) {
				for (j=1; j<=5; j++) {
					PSetOPNDisp(x + j, y + ys + i, color);
				}
			}
			break;

		/* �����B���E�ɍ������� */
		case 1:
			/* ���Ԃ������� */
			for (i=0; i<ys; i++) {
				PSetOPNDisp(x, y + ys + i, 0);
			}
			/* ������� */
			for (i=0; i<ys; i++) {
				for (j=3; j<=3; j++) {
					PSetOPNDisp(x + j, y + i, color);
				}
			}
			/* ������� */
			for (i=0; i<ys; i++) {
				for (j=1; j<=5; j++) {
					PSetOPNDisp(x + j, y + ys + i, color);
				}
			}
			break;

		/* �����B�����ɍ������� */
		case 2:
			/* ���Ԃ������� */
			for (i=0; i<ys; i++) {
				PSetOPNDisp(x, y + ys + i, 0);
			}
			/* ������� */
			for (i=0; i<ys; i++) {
				for (j=3; j<=5; j++) {
					PSetOPNDisp(x + j, y + i, color);
				}
			}
			/* ������� */
			for (i=0; i<ys; i++) {
				for (j=1; j<=5; j++) {
					PSetOPNDisp(x + j, y + ys + i, color);
				}
			}
			break;

		/* ���� */
		case 3:
			for (i=0; i<ys; i++) {
				for (j=0; j<5; j++) {
					PSetOPNDisp(x + j, y + i, color);
				}
			}
			break;

		default:
			ASSERT(FALSE);
	}
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	���ՑS�`��
 *
 *	x, y�̓g���b�N��̊�_
 */
void FASTCALL AllKbdOPNDisp(int x, int y)
{
	int i;
	int j;

	/* �Q�d���[�v */
	for (i=0; i<8; i++) {
		for (j=0; j<12; j++) {
			KbdOPNDisp((i * 16) + j, x, y, -1);
		}
	}
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	�Z�b�g�A�b�v
 */
static BOOL FASTCALL SetupOPNDisp(int *first, int *end)
{
	int i;
	int j;
	int y;
	int n;
	int ys;
#if defined(XM7DASH) && defined(OPNAMODE)
	BOOL flag[27];
#else
	BOOL flag[18];
#endif

	/* ������ */
	memset(flag, 0, sizeof(flag));

	/* �i���o�[���� */
	if (nOPNDisp & 16) {
		n = 3;
	}
#if defined(XM7DASH) && defined(OPNAMODE)
	else if (nOPNDisp & 32) {
		n = (((nOPNDisp & 7) + 1) * 9);
		if (nOPNDisp & 8) {
			/* THG���g�p���̂�PSG��ǉ� */
			n += 3;
		}
	}
#endif
	else {
		n = (((nOPNDisp & 7) + 1) * 6);
		if (nOPNDisp & 8) {
			/* THG���g�p���̂�PSG��ǉ� */
			n += 3;
		}
	}
#ifdef XM7DASH
#ifdef OPNAMODE
	if ((((nOPNDisp & 32) && ((nOPNDisp & 7) >= 1)) ||
		 ((nOPNDisp & 7) == 2)) && !bPopupSwnd) {
#else
	if (((nOPNDisp & 7) == 2) && !bPopupSwnd) {
#endif
#else
	if ((nOPNDisp & 7) == 2) {
#endif
		ys = (8 + 12 + 1);
	}
	else {
		ys = (8 * 3 + 1);
	}

	/* ���� */
	y = 0;
	for (i=0; i<n; i++) {
		for (j=0; j<42; j++) {
			/* ��v�`�F�b�N */
			if (cnOPNDisp[i][j * 2] == ctOPNDisp[i][j * 2]) {
				if (cnOPNDisp[i][j*2+1] == ctOPNDisp[i][j*2+1]) {
					continue;
				}
			}

			/* �`�� */
			ChrOPNDisp(ctOPNDisp[i][j * 2], j * 8, y, ctOPNDisp[i][j * 2 + 1]);

			/* �R�s�[ */
			cnOPNDisp[i][j * 2] = ctOPNDisp[i][j * 2];
			cnOPNDisp[i][j * 2 + 1] = ctOPNDisp[i][j * 2 + 1];

			/* �t���O���� */
			flag[i] = TRUE;
		}

		/* ���� */
		y += ys;
	}

	/* ���� */
	y = 8;
	for (i=0; i<n; i++) {
		/* �����ԂȂ�A�L�[�I�t��Ԃɂ���̂��挈 */
		if (knOPNDisp[i] == -2) {
			AllKbdOPNDisp(0, y);
			knOPNDisp[i] = -1;
			flag[i] = TRUE;
		}

		/* �`�F�b�N */
		if (knOPNDisp[i] != ktOPNDisp[i]) {
			/* �L�[�I�t��ԂȂ�A���� */
			if (knOPNDisp[i] >= 0) {
				KbdOPNDisp(knOPNDisp[i], 0, y, -1);
			}
			/* �L�[�I���ɂ���Ȃ�A���� */
			if (ktOPNDisp[i] >= 0) {
				if (!(nOPNDisp & 16)) {
#if defined(XM7DASH) && defined(OPNAMODE)
					if ((nOPNDisp & 32)) {
						/* PSG */
						if ((nOPNDisp & 8) &&
							(i >= (int)((nOPNDisp & 7) + 1) * 9)) {
							if (!GetMute2(OPN_THG, (i % 3) + 6)) {
								KbdOPNDisp(ktOPNDisp[i], 0, y, 13);
							}
						}
						/* FM */
						else if ((i % 9) < 6) {
							if (!GetMute2(i / 9, i % 9)) {
								KbdOPNDisp(ktOPNDisp[i], 0, y, 10);
							}
						}
						/* SSG */
						else {
							if (!GetMute2(i / 9, i % 9)) {
								KbdOPNDisp(ktOPNDisp[i], 0, y, 9);
							}
						}
					}
					else
#endif
					if ((nOPNDisp & 8) &&
						(i >= (int)((nOPNDisp & 7) + 1) * 6)) {
						if (!GetMute((i % 3) + 15)) {
							KbdOPNDisp(ktOPNDisp[i], 0, y, 13);
						}
					}
					else if ((i % 6) < 3) {
						if (!GetMute(i)) {
							KbdOPNDisp(ktOPNDisp[i], 0, y, 10);
						}
					}
					else {
						if (!GetMute(i)) {
							KbdOPNDisp(ktOPNDisp[i], 0, y, 9);
						}
					}
				}
				else {
#if defined(XM7DASH) && defined(OPNAMODE)
					if ((nOPNDisp & 32)) {
						if (!GetMute((i % 3) + 24)) {
							KbdOPNDisp(ktOPNDisp[i], 0, y, 13);
						}
					}
					else {
						if (!GetMute((i % 3) + 15)) {
							KbdOPNDisp(ktOPNDisp[i], 0, y, 13);
						}
					}
#else
					if (!GetMute((i % 3) + 15)) {
						KbdOPNDisp(ktOPNDisp[i], 0, y, 13);
					}
#endif
				}
			}

			/* �X�V */
			knOPNDisp[i] = ktOPNDisp[i];
			flag[i] = TRUE;
		}

		/* ���� */
		y += ys;
	}

	/* ���x�� */
	y = 0;
	for (i=0; i<n; i++) {
		/* ��v�`�F�b�N */
		if (lnOPNDisp[i] != ltOPNDisp[i]) {
			/* �؂�ւ��_�ƂȂ�x���W�����߂� */
			if (ltOPNDisp[i] >= 500) {
				ltOPNDisp[i] = 499;
			}
			else if (ltOPNDisp[i] < 0) {
				ltOPNDisp[i] = 0;
			}
			j = 100 * ltOPNDisp[i];
			j /= 500;

			/* �`�� */
#ifdef XM7DASH
			BfOPNDisp(236 + j, y, 100 - j, 7, 8);
			LvlOPNDisp(236, y, j, 7, 14, 13, 12);
#else
			BfOPNDisp(236, y, 100, 7, 8);
			LvlOPNDisp(236, y, j, 7, 14, 13, 12);
#endif

			/* �X�V */
			lnOPNDisp[i] = ltOPNDisp[i];
			flag[i] = TRUE;
		}

		/* ���� */
		y += ys;
	}

	/* flag���������� */
	y = -1;
	j = n;
	for (i=0; i<n; i++) {
		if (flag[i]) {
			/* ���������� */
			if (i < j) {
				j = i;
			}
			/* ��������� */
			if (y < i) {
				y = i;
			}
		}
	}

	/* j����y�܂ŁA��������΂悢 */
	if (y >= 0) {
		*first = j;
		*end = y;
		return TRUE;
	}

	/* �`��̕K�v�Ȃ� */
	return FALSE;
}

/*
 *	�����e�[�u��
 *	�������Ƃ̂������肵�������łȂ��A���̒��Ԃ̂������l��\��������
 */
static const double pitch_table[] = {
	31.772, 33.661, 35.663, 37.784, 40.030, 42.411, 44.933, 47.605, 50.435, 53.434, 56.612, 59.978,
	63.544, 67.323, 71.326, 75.567, 80.061, 84.822, 89.865, 95.209, 100.870, 106.869, 113.223, 119.956,
	127.089, 134.646, 142.652, 151.135, 160.122, 169.643, 179.731, 190.418, 201.741, 213.737, 226.446, 239.912,
	254.178, 269.292, 285.305, 302.270, 320.244, 339.287, 359.461, 380.836, 403.482, 427.474, 452.893, 479.823,
	508.356, 538.584, 570.610, 604.540, 640.488, 678.573, 718.923, 761.672, 806.964, 854.948, 905.786, 959.647,
	1016.711, 1077.168, 1141.220, 1209.080, 1280.975, 1357.146, 1437.846, 1523.345, 1613.927, 1709.896, 1811.572, 1919.293,
	2033.422, 2154.336, 2282.439, 2418.160, 2561.951, 2714.292, 2875.692, 3046.689, 3227.855, 3419.792, 3623.144, 3838.587,
	4066.845, 4308.672, 4564.878, 4836.319, 5123.901, 5428.584, 5751.384, 6093.378, 6455.709, 6839.585, 7246.287, 7677.173,
	8133.681
};

/*
 *	�������R�[�h�ϊ�
 *	-1�͔͈͊O������
 */
static int FASTCALL ConvOPNDisp(double freq)
{
	int i;
	int ret;

	/* �͈͊O���`�F�b�N */
	if (freq < pitch_table[0]) {
		return -1;
	}
	if (pitch_table[96] <= freq) {
		return -1;
	}

	/* ���[�v�A���� */
	ret = -1;
	for (i=0; i<96; i++) {
		if ((pitch_table[i] <= freq) && (freq <pitch_table[i + 1])) {
			/* i��ϊ� */
			ret = i / 12;
			ret <<= 4;
			ret += (i % 12);
			break;
		}
	}

	return ret;
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	FM�������R�[�h�ϊ�
 */
static int FASTCALL FMConvOPNDisp(BYTE a4, BYTE a0, int scale)
{
	int oct;
	int fnum;
	double freq;
	double d;

	/* Octave, F-Number�����߂� */
	oct = (int)a4;
	oct >>= 3;
	fnum = (int)a4;
	fnum &= 0x07;
	fnum <<= 8;
	fnum |= (int)a0;

	/* ���g�������߂� */
	freq = OPN_CLOCK * 100;
	while (oct != 0) {
		freq *= 2;
		oct--;
	}
	freq *= fnum;
	d = (double)(1 << 20);
	d *= 12;
	d *= scale;
	freq /= d;

	/* �ϊ� */
	return ConvOPNDisp(freq);
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	PSG�������R�[�h�ϊ�
 */
static int FASTCALL PSGConvOPNDisp(BYTE low, BYTE high, int scale)
{
	int pitch;
	double freq;
	double d;

	/* �s�b�`�Z�o */
	pitch = (int)high;
	pitch &= 0x0f;
	pitch <<= 8;
	pitch |= (int)low;

	/* ���g�������߂� */
	freq = OPN_CLOCK * 100;
	d = 8;
	d *= pitch;
	switch (scale) {
		case 3:
			d *= 2;
			break;
		case 6:
			d *= 4;
			break;
		case 2:
			d *= 1;
			break;
	}
	if (d == 0) {
		freq = 0;
	}
	else {
		freq /= d;
	}

	/* �ϊ� */
	return ConvOPNDisp(freq);
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	�L�[�{�[�h�X�e�[�^�X
 */
static void FASTCALL StatKbdOPNDisp(void)
{
	int i;
	int tmp;
#if defined(XM7DASH) && defined(OPNAMODE)
	int sft, ttl, ssg;
#endif
#if defined(XM7DASH) && defined(FMDLL)
	BYTE vol;
#endif

	/* THG PSG�I�t�Z�b�g���� */
#if defined(XM7DASH) && defined(OPNAMODE)
	if ((nOPNDisp & 32)) {
		ttl = 9;
		ssg = 6;
	}
	else {
		ttl = 6;
		ssg = 3;
	}
	if ((nOPNDisp & 15) == 8) {
		tmp = ttl;
	}
	else if ((nOPNDisp & 15) == 9) {
		tmp = ttl * 2;
	}
	else if ((nOPNDisp & 15) == 2) {
		tmp = ttl * 2 + ssg;
	}
	else {
		tmp = 0;
	}
#else
	if (nOPNDisp == 8) {
		tmp = 6;
	}
	else if (nOPNDisp == 9) {
		tmp = 12;
	}
	else if (nOPNDisp == 2) {
		tmp = 15;
	}
	else {
		tmp = 0;
	}
#endif

	/* FM���� */
#if defined(XM7DASH) && defined(OPNAMODE)
	for (i=0; i<ssg; i++) {
		if (nOPNDisp & 16) {
			break;
		}

		if ((nOPNDisp & 32)) {
			sft = ((i >= 3) ? (0x0100) : (0x0000));
		}
		else {
			sft = 0;
		}

		if (!opn_key[OPN_STD][i]) {
			ktOPNDisp[i + 0] = -1;
		}
		else {
			ktOPNDisp[i + 0] = FMConvOPNDisp(opn_reg[OPN_STD][0xa4 + (i % 3) + sft],
									opn_reg[OPN_STD][0xa0 + (i % 3) + sft],
									opn_scale[OPN_STD]);
		}

		if ((nOPNDisp & 7) >= 1) {
			if (!opn_key[OPN_WHG][i]) {
				ktOPNDisp[i + ttl] = -1;
			}
			else {
				ktOPNDisp[i + ttl] = FMConvOPNDisp(opn_reg[OPN_WHG][0xa4 + (i % 3) + sft],
										opn_reg[OPN_WHG][0xa0 + (i % 3) + sft],
										opn_scale[OPN_WHG]);
			}
		}

		if ((nOPNDisp & 7) >= 2) {
			if (!opn_key[OPN_THG][i]) {
				ktOPNDisp[i + ttl * 2] = -1;
			}
			else {
				ktOPNDisp[i + ttl * 2] = FMConvOPNDisp(opn_reg[OPN_THG][0xa4 + (i % 3) + sft],
										opn_reg[OPN_THG][0xa0 + (i % 3) + sft],
										opn_scale[OPN_THG]);
			}
		}
	}
#else
	for (i=0; i<3; i++) {
		if (nOPNDisp & 16) {
			break;
		}

		if (!opn_key[OPN_STD][i]) {
			ktOPNDisp[i + 0] = -1;
		}
		else {
			ktOPNDisp[i + 0] = FMConvOPNDisp(opn_reg[OPN_STD][0xa4 + i],
									opn_reg[OPN_STD][0xa0 + i],
									opn_scale[OPN_STD]);
		}

		if ((nOPNDisp & 7) >= 1) {
			if (!opn_key[OPN_WHG][i]) {
				ktOPNDisp[i + 6] = -1;
			}
			else {
				ktOPNDisp[i + 6] = FMConvOPNDisp(opn_reg[OPN_WHG][0xa4 + i],
										opn_reg[OPN_WHG][0xa0 + i],
										opn_scale[OPN_WHG]);
			}
		}

		if ((nOPNDisp & 7) >= 2) {
			if (!opn_key[OPN_THG][i]) {
				ktOPNDisp[i + 12] = -1;
			}
			else {
				ktOPNDisp[i + 12] = FMConvOPNDisp(opn_reg[OPN_THG][0xa4 + i],
										opn_reg[OPN_THG][0xa0 + i],
										opn_scale[OPN_THG]);
			}
		}
	}
#endif

	/* PSG���� */
#if defined(XM7DASH) && defined(OPNAMODE)
	for (i=0; i<3; i++) {
		if (!(nOPNDisp & 16)) {
#if defined(XM7DASH) && defined(FMDLL)
			vol = opn_reg[OPN_STD][i + 8];
			if ((vol & 0x10) != 0) {
				vol = ltOPNDisp[i + ssg];
			}
			if (vol) {
#else
			if (ltOPNDisp[i + ssg] > 0) {
#endif
				ktOPNDisp[i + ssg] = PSGConvOPNDisp(
										opn_reg[OPN_STD][i * 2 + 0],
										opn_reg[OPN_STD][i * 2 + 1],
										opn_scale[OPN_STD]);
			}
			else {
				ktOPNDisp[i + ssg] = -1;
			}
		}

		if ((nOPNDisp & 7) >= 1) {
#if defined(XM7DASH) && defined(FMDLL)
			vol = opn_reg[OPN_WHG][i + 8];
			if ((vol & 0x10) != 0) {
				vol = ltOPNDisp[i + ssg];
			}
			if (vol) {
#else
			if (ltOPNDisp[i + ttl + ssg] > 0) {
#endif
				ktOPNDisp[i + ttl + ssg] = PSGConvOPNDisp(
										opn_reg[OPN_WHG][i * 2 + 0],
										opn_reg[OPN_WHG][i * 2 + 1],
										opn_scale[OPN_WHG]);
			}
			else {
				ktOPNDisp[i + ttl + ssg] = -1;
			}
		}

		if ((tmp > 0) || (nOPNDisp & 16)) {
#if defined(XM7DASH) && defined(FMDLL)
			vol = opn_reg[OPN_THG][i + 8];
			if ((vol & 0x10) != 0) {
				vol = ltOPNDisp[i + ssg];
			}
			if (vol) {
#else
			if (ltOPNDisp[i + tmp] > 0) {
#endif
				ktOPNDisp[i + tmp] = PSGConvOPNDisp(
										opn_reg[OPN_THG][i * 2 + 0],
										opn_reg[OPN_THG][i * 2 + 1],
										opn_scale[OPN_THG]);
			}
			else {
				ktOPNDisp[i + tmp] = -1;
			}
		}
	}
#else
	for (i=0; i<3; i++) {
		if (!(nOPNDisp & 16)) {
#if defined(XM7DASH) && defined(FMDLL)
			vol = opn_reg[OPN_STD][i + 8];
			if ((vol & 0x10) != 0) {
				vol = ltOPNDisp[i + 3];
			}
			if (vol) {
#else
			if (ltOPNDisp[i + 3] > 0) {
#endif
				ktOPNDisp[i + 3] = PSGConvOPNDisp(
										opn_reg[OPN_STD][i * 2 + 0],
										opn_reg[OPN_STD][i * 2 + 1],
										opn_scale[OPN_STD]);
			}
			else {
				ktOPNDisp[i + 3] = -1;
			}
		}

		if ((nOPNDisp & 7) >= 1) {
#if defined(XM7DASH) && defined(FMDLL)
			vol = opn_reg[OPN_WHG][i + 8];
			if ((vol & 0x10) != 0) {
				vol = ltOPNDisp[i + 9];
			}
			if (vol) {
#else
			if (ltOPNDisp[i + 9] > 0) {
#endif
				ktOPNDisp[i + 9] = PSGConvOPNDisp(
										opn_reg[OPN_WHG][i * 2 + 0],
										opn_reg[OPN_WHG][i * 2 + 1],
										opn_scale[OPN_WHG]);
			}
			else {
				ktOPNDisp[i + 9] = -1;
			}
		}

		if ((tmp > 0) || (nOPNDisp & 16)) {
#if defined(XM7DASH) && defined(FMDLL)
			vol = opn_reg[OPN_THG][i + 8];
			if ((vol & 0x10) != 0) {
				vol = ltOPNDisp[i + tmp];
			}
			if (vol) {
#else
			if (ltOPNDisp[i + tmp] > 0) {
#endif
				ktOPNDisp[i + tmp] = PSGConvOPNDisp(
										opn_reg[OPN_THG][i * 2 + 0],
										opn_reg[OPN_THG][i * 2 + 1],
										opn_scale[OPN_THG]);
			}
			else {
				ktOPNDisp[i + tmp] = -1;
			}
		}
	}
#endif
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	���x���X�e�[�^�X
 */
static void FASTCALL StatLevOPNDisp(void)
{
	BYTE m;
	BYTE p;
	int i;
#if defined(XM7DASH) && defined(OPNAMODE)
	int	ttl, ssg;
#endif

#if defined(XM7DASH) && defined(OPNAMODE)
	if (nOPNDisp & 32) {
		ttl = 9;
		ssg = 6;
	}
	else {
		ttl = 6;
		ssg = 3;
	}

	/* ��U�擾���� */
	if (nOPNDisp & 32) {
		for (i=0; i<ttl * 3; i++) {
			if (GetMute2(i / 9, i % 9)) {
				ltOPNDisp[i] = 0;
			}
			else {
				ltOPNDisp[i] = GetLevelSnd2(i);
			}
		}
	}
	else {
		for (i=0; i<ttl * 3; i++) {
			if (GetMute(i)) {
				ltOPNDisp[i] = 0;
			}
			else {
				ltOPNDisp[i] = GetLevelSnd(i);
			}
		}
	}

	/* SSG�}�X�N�`�F�b�N:OPN */
	m = opn_reg[OPN_STD][7];
	p = 9;
	for (i=0; i<3; i++) {
		if ((m & p) == p) {
			ltOPNDisp[i + ssg] = 0;
		}
		p <<= 1;
	}

	/* SSG�}�X�N�`�F�b�N:WHG */
	m = opn_reg[OPN_WHG][7];
	p = 9;
	for (i=0; i<3; i++) {
		if ((m & p) == p) {
			ltOPNDisp[i + ttl * 1 + ssg] = 0;
		}
		p <<= 1;
	}

	/* SSG�}�X�N�`�F�b�N:THG */
	m = opn_reg[OPN_THG][7];
	p = 9;
	for (i=0; i<3; i++) {
		if ((m & p) == p) {
			ltOPNDisp[i + ttl * 2 + ssg] = 0;
		}
		p <<= 1;
	}

	/* THG��Ԃ�PSG���Ɉړ� */
	if (nOPNDisp & 32) {
		if ((nOPNDisp & 15) == 8) {
			for (i=0; i<3; i++) {
				ltOPNDisp[i + 9] = ltOPNDisp[i + 24];
			}
		}
		else if ((nOPNDisp & 15) == 9) {
			for (i=0; i<3; i++) {
				ltOPNDisp[i + 18] = ltOPNDisp[i + 24];
			}
		}
	}
	else {
		if (nOPNDisp & 16) {
			for (i=0; i<3; i++) {
				ltOPNDisp[i] = ltOPNDisp[i + 15];
			}
		}
		else if (nOPNDisp == 8) {
			for (i=0; i<3; i++) {
				ltOPNDisp[i + 6] = ltOPNDisp[i + 15];
			}
		}
		else if (nOPNDisp == 9) {
			for (i=0; i<3; i++) {
				ltOPNDisp[i + 12] = ltOPNDisp[i + 15];
			}
		}
	}
#else
	/* ��U�擾���� */
	for (i=0; i<18; i++) {
		if (GetMute(i)) {
			ltOPNDisp[i] = 0;
		}
		else {
			ltOPNDisp[i] = GetLevelSnd(i);
		}
	}

	/* SSG�}�X�N�`�F�b�N:OPN */
	m = opn_reg[OPN_STD][7];
	p = 9;
	for (i=0; i<3; i++) {
		if ((m & p) == p) {
			ltOPNDisp[i + 0 + 3] = 0;
		}
		p <<= 1;
	}

	/* SSG�}�X�N�`�F�b�N:WHG */
	m = opn_reg[OPN_WHG][7];
	p = 9;
	for (i=0; i<3; i++) {
		if ((m & p) == p) {
			ltOPNDisp[i + 6 + 3] = 0;
		}
		p <<= 1;
	}

	/* SSG�}�X�N�`�F�b�N:THG */
	m = opn_reg[OPN_THG][7];
	p = 9;
	for (i=0; i<3; i++) {
		if ((m & p) == p) {
			ltOPNDisp[i + 12 + 3] = 0;
		}
		p <<= 1;
	}

	/* THG��Ԃ�PSG���Ɉړ� */
	if (nOPNDisp & 16) {
		for (i=0; i<3; i++) {
			ltOPNDisp[i] = ltOPNDisp[i + 15];
		}
	}
	else if (nOPNDisp == 8) {
		for (i=0; i<3; i++) {
			ltOPNDisp[i + 6] = ltOPNDisp[i + 15];
		}
	}
	else if (nOPNDisp == 9) {
		for (i=0; i<3; i++) {
			ltOPNDisp[i + 12] = ltOPNDisp[i + 15];
		}
	}
#endif
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	������Z�b�g
 */
static void FASTCALL StrOPNDisp(char *string, int x, int y, int color)
{
	char ch;

	ASSERT(string);
	ASSERT((x >= 0) && (x < 49));
	ASSERT((y >= 0) && (y < 18));
	ASSERT((color >= 0) && (color < 16));

	/* �������[�v */
	for (;;) {
		/* �����擾 */
		ch = *string++;
		if (ch == '\0') {
			break;
		}

		/* x�`�F�b�N */
		if (x >= 49) {
			continue;
		}

		/* �Z�b�g */
		ctOPNDisp[y][x * 2 + 0] = ch;
		ctOPNDisp[y][x * 2 + 1] = (BYTE)color;
		x++;
	}
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	�����f�[�^�Z�b�g
 */
static void FASTCALL StatChrOPNDisp(void)
{
	const BYTE cslot[4] = {2, 3, 3, 4};
	int i;
	int j;
	int n;
	int ch;
	char string[128];
	int no;
	BOOL fm_flag;
	BYTE alg;
	BYTE tl;
	int vols;
#if defined(XM7DASH) && defined(OPNAMODE)
	int sft, ttl;
	BOOL mute;
#endif

	/* �i���o�[���� */
	if (nOPNDisp & 16) {
		n = 0;
	}
#if defined(XM7DASH) && defined(OPNAMODE)
	else if ((nOPNDisp & 32)) {
		n = (((nOPNDisp & 7) + 1) * 9);
	}
#endif
	else {
		n = (((nOPNDisp & 7) + 1) * 6);
	}

	/* THG���g�p���̂�PSG��ǉ� */
	if (nOPNDisp & 8) {
		n += 3;
	}

	no = OPN_STD;
	for (i=0; i<n; i++) {
		/* �|�C���^�ݒ� */
#if defined(XM7DASH) && defined(OPNAMODE)
		if ((nOPNDisp & 32)) {
			if ((i == 9) && ((nOPNDisp & 15) != 8)) {
				no = OPN_WHG;
			}
			if ((i == 18) || (((nOPNDisp & 15) == 8) && (i == 9))) {
				no = OPN_THG;
			}
		}
		else {
			if ((i == 6) && (nOPNDisp != 8)) {
				no = OPN_WHG;
			}
			if ((i == 12) || ((nOPNDisp == 8) && (i == 6))) {
				no = OPN_THG;
			}
		}
#else
		if ((i == 6) && (nOPNDisp != 8)) {
			no = OPN_WHG;
		}
		if ((i == 12) || ((nOPNDisp == 8) && (i == 6))) {
			no = OPN_THG;
		}
#endif
		if ((i == 0) && (nOPNDisp & 16)) {
			no = OPN_THG;
		}

#if defined(XM7DASH) && defined(OPNAMODE)
		if ((nOPNDisp & 32)) {
			sft = (((i % 9) >= 3) ? (0x0100) : (0x0000));
		}
		else {
			sft = 0;
		}
#endif

		/* �`�����l�� */
		ch = i;
		if (nOPNDisp & 16) {
#if defined(XM7DASH) && defined(OPNAMODE)
			if ((nOPNDisp & 32)) {
				ch = (i % 3) + 24;
			}
			else {
				ch = (i % 3) + 15;
			}
#else
			ch = (i % 3) + 15;
#endif
			fm_flag = FALSE;
			_snprintf(string, 128, "PSG%1d", (i % 6) + 1);
		}
#if defined(XM7DASH) && defined(OPNAMODE)
		else if ((nOPNDisp & 32)) {
			if ((i % 9) < 6) {
				fm_flag = TRUE;
			}
			else {
				fm_flag = FALSE;
			}
			if (i < 9) {
				_snprintf(string, 128, "STD%1d", (i % 9) + 1);
			}
			else {
				if (i < 18) {
					_snprintf(string, 128, "WHG%1d", (i % 9) + 1);
				}
				else {
					_snprintf(string, 128, "THG%1d", (i % 9) + 1);
				}
				if (nOPNDisp & 8) {
					if (i >= (int)((nOPNDisp & 7) + 1) * 9) {
						ch = (i % 3) + 24;
						fm_flag = FALSE;
						_snprintf(string, 128, "PSG%1d", (i % 9) + 1);
					}
				}
			}
		}
#endif
		else {
			if ((i % 6) < 3) {
				fm_flag = TRUE;
			}
			else {
				fm_flag = FALSE;
			}
			if (i < 6) {
				_snprintf(string, 128, "OPN%1d", (i % 6) + 1);
			}
			else {
				if (i < 12) {
					_snprintf(string, 128, "WHG%1d", (i % 6) + 1);
				}
				else {
					_snprintf(string, 128, "THG%1d", (i % 6) + 1);
				}
				if (nOPNDisp & 8) {
					if (i >= (int)((nOPNDisp & 7) + 1) * 6) {
						ch = (i % 3) + 15;
						fm_flag = FALSE;
						_snprintf(string, 128, "PSG%1d", (i % 6) + 1);
					}
				}
			}
		}
		StrOPNDisp(string, 0, i, 7);

		/* ���g�� */
		if (fm_flag) {
#if defined(XM7DASH) && defined(OPNAMODE)
			j = opn_reg[no][0xa4 + (i % 3) + sft];
			j <<= 8;
			j |= opn_reg[no][0xa0 + (i % 3) + sft];
#else
			j = opn_reg[no][0xa4 + (i % 3)];
			j <<= 8;
			j |= opn_reg[no][0xa0 + (i % 3)];
#endif
			_snprintf(string, 128, "F:$%04X", j);
		}
		else {
			j = opn_reg[no][(i % 3) * 2 + 1];
			j &= 0x0f;
			j <<= 8;
			j |= opn_reg[no][(i % 3) * 2 + 0];
			_snprintf(string, 128, "P:$%04X", j);
		}
		StrOPNDisp(string, 6, i, 12);

		/* �{�����[�� */
#if defined(XM7DASH) && defined(OPNAMODE)
		if ((nOPNDisp & 32)) {
			mute = GetMute2(ch / 9, ch % 9);
		}
		else {
			mute = GetMute(ch);
		}
		if (mute) {
#else
		if (GetMute(ch)) {
#endif
			strncpy(string, "MUTE          ", 128);
			StrOPNDisp(string, 14, i, 15);
		}
		else {
			if (fm_flag) {
#if defined(XM7DASH) && defined(OPNAMODE)
				alg = (BYTE)(opn_reg[no][0xb0 + (i % 3) + sft] & 0x07);
#else
				alg = (BYTE)(opn_reg[no][0xb0 + (i % 3)] & 0x07);
#endif
				if (alg >= 4) {
					alg -= (BYTE)4;
					vols = 127;
					for (j=0; j<cslot[alg]; j++) {
#if defined(XM7DASH) && defined(OPNAMODE)
						tl = (BYTE)(opn_reg[no][0x4c - (j << 2) + (i % 3) + sft] & 0x7f);
#else
						tl = (BYTE)(opn_reg[no][0x4c - (j << 2) + (i % 3)] & 0x7f);
#endif
						if (vols > tl) {
							vols = tl;
						}
					}
				}
				else {
#if defined(XM7DASH) && defined(OPNAMODE)
					vols = opn_reg[no][0x4c + (i % 3) + sft];
#else
					vols = opn_reg[no][0x4c + (i % 3)];
#endif
				}

				/* 7bit�̂ݗL�� */
				vols &= 0x7f;
				_snprintf(string, 128, "V:%03d", 127 - vols);
			}
			else {
				j = opn_reg[no][8 + (i % 3)];
				/* 0�`15�ƁA16�ȏ�ɕ����� */
				j &= 0x1f;
				if (j >= 0x10) {
					j = 0x10;
				}
				_snprintf(string, 128, "V:%03d", j);
			}
			StrOPNDisp(string, 14, i, 12);

			if (fm_flag) {
				/* �L�[�I�� */
#if defined(XM7DASH) && defined(OPNAMODE)
				if ((nOPNDisp & 32)) {
					if (opn_key[no][(i % 9)]) {
						strncpy(string, "KEYON   ", 128);
					}
					else {
						strncpy(string, "        ", 128);
					}
				}
				else {
					if (opn_key[no][(i % 3)]) {
						strncpy(string, "KEYON   ", 128);
					}
					else {
						strncpy(string, "        ", 128);
					}
				}
#else
				if (opn_key[no][(i % 3)]) {
					strncpy(string, "KEYON   ", 128);
				}
				else {
					strncpy(string, "        ", 128);
				}
#endif
			}
			else {
				/* �~�L�T */
				j = opn_reg[no][7];
				if ((i % 3) == 1) {
					j >>= 1;
				}
				if ((i % 3) == 2) {
					j >>= 2;
				}
				j &= 0x09;

				switch (j) {
					case 0:
#ifdef XM7DASH
						if ((uStereoOut == 0) ||
#ifdef OPNAMODE
							(opn_reg[no][0x29] & 0x80) ||
#endif
							(!whg_use && !thg_use)) {
							_snprintf(string, 128, "T + N:%2d", (BYTE)(opn_reg[no][6] & 0x1f));
						}
						else {
							_snprintf(string, 128, "TN:%2d   ", (BYTE)(opn_reg[no][6] & 0x1f));
						}
#else
						_snprintf(string, 128, "T + N:%2d", (BYTE)(opn_reg[no][6] & 0x1f));
#endif
						break;
					case 1:
#ifdef XM7DASH
						if ((uStereoOut == 0) ||
#ifdef OPNAMODE
							(opn_reg[no][0x29] & 0x80) ||
#endif
							(!whg_use && !thg_use)) {
							_snprintf(string, 128, "NOISE:%2d", (BYTE)(opn_reg[no][6] & 0x1f));
						}
						else {
							_snprintf(string, 128, "N :%2d   ", (BYTE)(opn_reg[no][6] & 0x1f));
						}
#else
						_snprintf(string, 128, "NOISE:%2d", (BYTE)(opn_reg[no][6] & 0x1f));
#endif
						break;
					case 8:
						strncpy(string, "TONE    ", 128);
						break;
					case 9:
						strncpy(string, "        ", 128);
						break;
				}
			}
			StrOPNDisp(string, 20, i, 12);

#ifdef XM7DASH
#ifdef OPNAMODE
			if ((opn_reg[no][0x29] & 0x80)) {
				if (i != ch) {
					/* PSG */
					strncpy(string, "LR", 128);
				}
				else if ((i % 9) < 6) {
					switch (opn_reg[no][0xb4 + (i % 3) + sft] & 0xC0) {
						case 0x00:
							strncpy(string, "  ", 128);
							break;
						case 0x40:
							strncpy(string, " R", 128);
							break;
						case 0x80:
							strncpy(string, "L ", 128);
							break;
						case 0xC0:
						default:
							strncpy(string, "LR", 128);
							break;
					}
				}
				else {
					/* SSG */
					strncpy(string, "LR", 128);
				}
			}
			else if ((uStereoOut == 0) ||
					 (!whg_use && !thg_use)) {
					/* ���m���� */
					continue;
			}
			else if (i != ch) {
				/* PSG */
				strncpy(string, "LR", 128);
			}
			else {
				if ((nOPNDisp & 32)) {
					ttl = 9;
				}
				else {
					ttl = 6;
				}
				switch (uStereoOut) {
					case 1:
						if (i < ttl) {
							/* OPN */
							strncpy(string, "L ", 128);
						}
						else if (i < ttl * 2) {
							/* WHG */
							strncpy(string, " R", 128);
						}
						else {
							/* THG */
							strncpy(string, "LR", 128);
						}
						break;
					case 2:
						if (i < ttl) {
							/* OPN */
							strncpy(string, " R", 128);
						}
						else if (i < ttl * 2) {
							/* WHG */
							strncpy(string, "L ", 128);
						}
						else {
							/* THG */
							strncpy(string, "LR", 128);
						}
						break;
					case 3:
						if (i < ttl) {
							/* OPN */
							strncpy(string, "LR", 128);
						}
						else if (i < ttl * 2) {
							/* WHG */
							strncpy(string, " R", 128);
						}
						else {
							/* THG */
							strncpy(string, "L ", 128);
						}
						break;
				}
			}
#else
			if ((uStereoOut == 0) ||
				(!whg_use && !thg_use)) {
				/* ���m���� */
				continue;
			}
			else if (i != ch) {
				/* PSG */
				strncpy(string, "LR", 128);
			}
			else {
				switch (uStereoOut) {
					case 1:
						if (i < 6) {
							/* OPN */
							strncpy(string, "L ", 128);
						}
						else if (i < 12) {
							/* WHG */
							strncpy(string, " R", 128);
						}
						else {
							/* THG */
							strncpy(string, "LR", 128);
						}
						break;
					case 2:
						if (i < 6) {
							/* OPN */
							strncpy(string, " R", 128);
						}
						else if (i < 12) {
							/* WHG */
							strncpy(string, "L ", 128);
						}
						else {
							/* THG */
							strncpy(string, "LR", 128);
						}
						break;
					case 3:
						if (i < 6) {
							/* OPN */
							strncpy(string, "LR", 128);
						}
						else if (i < 12) {
							/* WHG */
							strncpy(string, " R", 128);
						}
						else {
							/* THG */
							strncpy(string, "L ", 128);
						}
						break;
				}
			}
#endif
			StrOPNDisp(string, 26, i, 12);
#endif
		}
	}
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	�`��
 */
static void FASTCALL DrawOPNDisp(HDC hDC, BOOL flag)
{
	HDC hMemDC;
	HBITMAP hBitmap;
	int first, end;
	int ys;

	ASSERT(hDC);

	/* �r�b�g�}�b�v�n���h���E�|�C���^�������Ȃ�A�������Ȃ� */
	if (!hOPNDisp || !pOPNDisp) {
		return;
	}

	/* �X�e�[�^�X�`�F�b�N */
	StatLevOPNDisp();
	StatKbdOPNDisp();
	StatChrOPNDisp();

	/* �Z�b�g�A�b�v���`��`�F�b�N */
	if (!SetupOPNDisp(&first, &end) && !flag) {
		return;
	}
	if (flag) {
		first = 0;
		if (nOPNDisp & 16) {
			end = 0;
		}
#if defined(XM7DASH) && defined(OPNAMODE)
		else if ((nOPNDisp & 32)) {
			end = (((nOPNDisp & 7) + 1) * 9);
		}
#endif
		else {
			end = (((nOPNDisp & 7) + 1) * 6);
		}

		/* THG���g�p���̂�PSG��ǉ� */
		if (nOPNDisp & 8) {
			end += 3;
		}
	}

#ifdef XM7DASH
#ifdef OPNAMODE
	if ((((nOPNDisp & 32) && ((nOPNDisp & 7) >= 1)) ||
		 ((nOPNDisp & 7) == 2)) && !bPopupSwnd) {
#else
	if (((nOPNDisp & 7) == 2) && !bPopupSwnd) {
#endif
#else
	if ((nOPNDisp & 7) == 2) {
#endif
		ys = (8 + 12 + 1);
	}
	else {
		ys = (8 * 3 + 1);
	}

	/* �r�b�g�}�b�v�n���h���E�|�C���^���L����������x�`�F�b�N */
	if (!hOPNDisp || !pOPNDisp) {
		return;
	}

	/* ������DC���쐬���A�r�b�g�}�b�v���Z���N�g */
	hMemDC = CreateCompatibleDC(hDC);
	ASSERT(hMemDC);
	hBitmap = (HBITMAP)SelectObject(hMemDC, hOPNDisp);

	/* �f�X�N�g�b�v�̏󋵂�����ł́A���ۂ����蓾��l */
	if (hBitmap) {
		/* �p���b�g�ݒ�ABitBlt */
		SetDIBColorTable(hMemDC, 0, 16, rgbOPNDisp);
		BitBlt(hDC,
				0, ys * first,
				rOPNDisp.right, ys * (end - first + 1), hMemDC,
				0, ys * first, SRCCOPY);

		/* �I�u�W�F�N�g�ăZ���N�g */
		SelectObject(hMemDC, hBitmap);
	}

	/* ������DC�폜 */
	DeleteDC(hMemDC);
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	���t���b�V��
 */
void FASTCALL RefreshOPNDisp(void)
{
	HWND hWnd;
	HDC hDC;

	/* ��ɌĂ΂��̂ŁA���݃`�F�b�N���邱�� */
	if (hSubWnd[SWND_OPNDISP] == NULL) {
		return;
	}

	/* �`�� */
	hWnd = hSubWnd[SWND_OPNDISP];
	hDC = GetDC(hWnd);
	DrawOPNDisp(hDC, TRUE);
	ReleaseDC(hWnd, hDC);
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	�ĕ`��
 */
static void FASTCALL PaintOPNDisp(HWND hWnd, BOOL flag)
{
	HDC hDC;
	PAINTSTRUCT ps;
	int i;

	ASSERT(hWnd);

	/* ���[�N�G���A�����ׂĖ���� */
#if defined(XM7DASH) && defined(OPNAMODE)
	for (i=0; i<27; i++) {
#else
	for (i=0; i<18; i++) {
#endif
		knOPNDisp[i] = -2;
		lnOPNDisp[i] = -1;
	}
	memset(cnOPNDisp, 0xff, sizeof(cnOPNDisp));

	/* �`�� */
	hDC = BeginPaint(hWnd, &ps);
	ASSERT(hDC);
	DrawOPNDisp(hDC, flag);
	EndPaint(hWnd, &ps);
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	�~���[�g�����@�`�����l���v�Z
 */
static int CalcCh(LPARAM lParam)
{
	int y;
	int ch;
	
	y = HIWORD(lParam);
	
#if defined(XM7DASH) && defined(OPNAMODE)
	if ((((nOPNDisp & 32) && ((nOPNDisp & 7) >= 1)) ||
		 ((nOPNDisp & 7) == 2)) && !bPopupSwnd) {
		ch = y / (8 + 12 + 1);
		if (nOPNDisp & 16) {
			/* PSG only */
			ch = (ch % 3) + 24;
		}
		else {
			if ((nOPNDisp & 8) && (ch >= (int)(((nOPNDisp & 7) + 1) * 6))) {
				ch = (ch % 3) + 24;
			}
		}
	}
#else
#ifdef XM7DASH
	if (((nOPNDisp & 7) == 2) && !bPopupSwnd) {
#else
	if ((nOPNDisp & 7) == 2) {
#endif
		/* THG */
		ch = y / (8 + 12 + 1);
	}
#endif
	else {
		ch = y / (8 * 3 + 1);
		if (nOPNDisp & 16) {
			/* PSG only */
#if defined(XM7DASH) && defined(OPNAMODE)
			if (nOPNDisp & 32) {
				ch = (ch % 3) + 24;
			}
			else {
				ch = (ch % 3) + 15;
			}
#else
			ch = (ch % 3) + 15;
#endif
		}
		else {
#if defined(XM7DASH) && defined(OPNAMODE)
			if (nOPNDisp & 32) {
				if ((nOPNDisp & 8) && (ch >= (int)(((nOPNDisp & 7) + 1) * 9))) {
					ch = (ch % 3) + 24;
				}
			}
			else {
				if ((nOPNDisp & 8) && (ch >= (int)(((nOPNDisp & 7) + 1) * 6))) {
					ch = (ch % 3) + 15;
				}
			}
#else
			if ((nOPNDisp & 8) && (ch >= (int)(((nOPNDisp & 7) + 1) * 6))) {
				ch = (ch % 3) + 15;
			}
#endif
		}
	}

	return ch;
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	�E�C���h�E�v���V�[�W��
 */
static LRESULT CALLBACK OPNDispProc(HWND hWnd, UINT message,
								 WPARAM wParam, LPARAM lParam)
{
	int i;
#if defined(XM7DASH) && defined(OPNAMODE)
	int no, ch;
#endif
	static BOOL bDblClk = FALSE;

	/* ���b�Z�[�W�� */
	switch (message) {
		/* �E�C���h�E�ĕ`�� */
		case WM_PAINT:
			/* ���b�N���K�v */
			LockVM();
			PaintOPNDisp(hWnd, TRUE);
			UnlockVM();
			return 0;

		/* �w�i�`�� */
		case WM_ERASEBKGND:
			return TRUE;

		/* �~���[�g */
		case WM_LBUTTONUP:
			if (bDblClk) {
				bDblClk = FALSE;
			}
			else {
				LockVM();
#if defined(XM7DASH) && defined(OPNAMODE)
				if ((nOPNDisp & 32)) {
					no = CalcCh(lParam) / 9;
					ch = CalcCh(lParam) % 9;
					SetMute2(no, ch, !GetMute2(no, ch));
				}
				else {
					SetMute(CalcCh(lParam), !GetMute(CalcCh(lParam)));
				}
#else
				SetMute(CalcCh(lParam), !GetMute(CalcCh(lParam)));
#endif
				PaintOPNDisp(hWnd, FALSE);
				UnlockVM();
			}
			return 0;

		/* �\�����t */
		case WM_LBUTTONDBLCLK:
			LockVM();
#if defined(XM7DASH) && defined(OPNAMODE)
			if ((nOPNDisp & 32)) {
				no = CalcCh(lParam) / 9;
				ch = CalcCh(lParam) % 9;
				for (i=0; i<27; i++) {
					SetMute2(i / 9, i % 9, (BOOL)(i != (no * 9 + ch)));
				}
			}
			else {
				for (i=0; i<18; i++) {
					SetMute(i, (BOOL)(i != CalcCh(lParam)));
				}
			}
#else
			for (i=0; i<18; i++) {
				SetMute(i, (BOOL)(i != CalcCh(lParam)));
			}
#endif
			PaintOPNDisp(hWnd, FALSE);
			UnlockVM();
			bDblClk = TRUE;
			return 0;

		/* �~���[�g�S���� */
		case WM_RBUTTONUP:
			LockVM();
#if defined(XM7DASH) && defined(OPNAMODE)
			for (i=0; i<27; i++) {
				SetMute2(i / 9, i % 9, FALSE);
			}
#else
			for (i=0; i<18; i++) {
				SetMute(i, FALSE);
			}
#endif
			PaintOPNDisp(hWnd, FALSE);
			UnlockVM();
			return 0;

		/* �E�C���h�E�폜 */
		case WM_DESTROY:
			LockVM();

			/* ���C���E�C���h�E�֎����ʒm */
			DestroySubWindow(hWnd, NULL, NULL);

			/* �r�b�g�}�b�v��� */
			if (hOPNDisp) {
				DeleteObject(hOPNDisp);
				hOPNDisp = NULL;
				pOPNDisp = NULL;
			}

			UnlockVM();
			break;

#ifdef XM7DASH
		/* �E�B���h�E�ړ� */
		case WM_MOVE:
			/* �ŏ������̃T�u�E�B���h�E���Ҕ� */
			MoveSubWindow(hWnd);
			break;
#endif
	}

	/* �f�t�H���g �E�C���h�E�v���V�[�W�� */
	return DefWindowProc(hWnd, message, wParam, lParam);
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	������
 */
void FASTCALL InitOPNDisp(HWND hWnd)
{
	BITMAPINFOHEADER *pbmi;
	HDC hDC;
	int i;

	/* �S�̃��[�N������ */
	pOPNDisp = NULL;
	hOPNDisp = NULL;

	/* �\���Ǘ����[�N������ */
#if defined(XM7DASH) && defined(OPNAMODE)
	for (i=0; i<27; i++) {
#else
	for (i=0; i<18; i++) {
#endif
		knOPNDisp[i] = -2;
		ktOPNDisp[i] = -1;
		lnOPNDisp[i] = -1;
		ltOPNDisp[i] = 0;
	}
	memset(cnOPNDisp, 0xff, sizeof(cnOPNDisp));
	memset(ctOPNDisp, 0, sizeof(ctOPNDisp));

	/* �r�b�g�}�b�v�w�b�_���� */
	pbmi = (BITMAPINFOHEADER*)malloc(sizeof(BITMAPINFOHEADER)
										 + sizeof(RGBQUAD) * 16);
	if (pbmi) {
		memset(pbmi, 0, sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * 16);
		pbmi->biSize = sizeof(BITMAPINFOHEADER);
		pbmi->biWidth = rOPNDisp.right;
		pbmi->biHeight = -rOPNDisp.bottom;
		pbmi->biPlanes = 1;
		pbmi->biBitCount = 4;
		pbmi->biCompression = BI_RGB;

		/* DC�擾�ADIB�Z�N�V�����쐬 */
		hDC = GetDC(hWnd);
		hOPNDisp = CreateDIBSection(hDC, (BITMAPINFO*)pbmi, DIB_RGB_COLORS,
								(void**)&pOPNDisp, NULL, 0);
		ReleaseDC(hWnd, hDC);
		free(pbmi);
	}
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	�T�C�Y�ύX
 */
void FASTCALL ReSizeOPNDisp(void)
{
	HWND hWnd;
	UINT uMode;
	RECT wrect;
	RECT crect;
	char szWndName[128];
	int n;
	int ys;

	/* ��ɌĂ΂��̂ŁA���݃`�F�b�N���邱�� */
	if (hSubWnd[SWND_OPNDISP] == NULL) {
		return;
	}

	/* �W�I���g���ύX�`�F�b�N */
	hWnd = hSubWnd[SWND_OPNDISP];
	uMode = 0;
	n = 0;
	if (opn_use) {
		uMode = 0;
		n = 6;
	}
	if (whg_use) {
		uMode = 1;
		n = 12;
	}
	if (thg_use) {
		uMode = 2;
		n = 18;
	}
#if defined(XM7DASH) && defined(OPNAMODE)
	if ((opna_use[OPN_STD] && opn_use) ||
		(opna_use[OPN_WHG] && whg_use) ||
		(opna_use[OPN_THG] && thg_use)) {
		uMode |= 32;
		if (opn_use) {
			n = 9;
		}
		if (whg_use) {
			n = 18;
		}
		if (thg_use) {
			n = 27;
		}
	}
#if XM7_VER >= 3
	if (((uMode & 31) < 2) && (fm_subtype < FMSUB_FM77AV)) {
#else
	if (((uMode & 31) < 2) && (fm7_ver == 1)) {
#endif
#elif XM7_VER >= 3 && defined(XM7DASH)
	if ((uMode < 2) && (fm_subtype < FMSUB_FM77AV)) {
#else
	if ((uMode < 2) && (fm7_ver == 1)) {
#endif
		uMode |= 8;
		n += 3;
	}
#if XM7_VER >= 3 && defined(XM7DASH)
	if (!opn_use && (fm_subtype < FMSUB_FM77AV)) {
#else
	if (!opn_use && (fm7_ver == 1)) {
#endif
		uMode = 24;
		n = 3;
	}
	if (IsIconic(hWnd)) {
		/* �A�C�R�����`�F�b�N */
		uMode |= 0x80000000;
	}
	if (uMode == nOPNDisp) {
		return;
	}

	/* ���b�N */
	LockVM();

	/* �E�C���h�E�^�C�g����ύX */
	if ((uMode & 16) ^ (nOPNDisp & 16)) {
		if (opn_use) {
			LoadString(hResInstance, IDS_SWND_OPNDISP,
						szWndName, sizeof(szWndName));
		}
		else {
			LoadString(hResInstance, IDS_SWND_PSGDISP,
						szWndName, sizeof(szWndName));
		}
		SetWindowText(hWnd, szWndName);
	}

	/* ���[�h�`�F���W */
	nOPNDisp = uMode;

	/* �r�b�g�}�b�v��� */
	if (hOPNDisp) {
		DeleteObject(hOPNDisp);
		hOPNDisp = NULL;
		pOPNDisp = NULL;
	}

	/* ���̑������� */
#ifdef XM7DASH
#ifdef OPNAMODE
	if ((((nOPNDisp & 32) && ((nOPNDisp & 7) >= 1)) ||
		 ((nOPNDisp & 7) == 2)) && !bPopupSwnd) {
#else
	if (((nOPNDisp & 7) == 2) && !bPopupSwnd) {
#endif
#else
	if ((nOPNDisp & 7) == 2) {
#endif
		ys = (8 + 12 + 1);
	}
	else {
		ys = (8 * 3 + 1);
	}

	rOPNDisp.bottom = (ys * n);
	InitOPNDisp(hWnd);

	/* �E�B���h�E��`�ύX */
	GetWindowRect(hWnd, &wrect);
	GetClientRect(hWnd, &crect);
	wrect.right -= wrect.left;
	wrect.right -= crect.right;
	wrect.right += (42 * 8);
	wrect.bottom -= wrect.top;
	wrect.bottom -= crect.bottom;
	wrect.bottom += (ys * n);
	SetWindowPos(hWnd, HWND_TOP, 0, 0, wrect.right, wrect.bottom,
							SWP_NOZORDER | SWP_NOMOVE);
#ifdef XM7DASH
	if (bPopupSwnd) {
		SetForegroundWindow(hMainWnd);
	}
#endif

	/* �A�����b�N */
	UnlockVM();
}

/*
 *	OPN�f�B�X�v���C�E�C���h�E
 *	�E�C���h�E�쐬
 */
HWND FASTCALL CreateOPNDisp(HWND hParent, int index)
{
	WNDCLASSEX wcex;
	char szClassName[] = "XM7_OPNDisp";
	char szWndName[128];
	RECT rect;
	RECT crect, wrect;
	HWND hWnd;
#ifdef XM7DASH
	DWORD dwExStyle;
#endif

	ASSERT(hParent);

	/* �E�C���h�E��`���v�Z */
#ifdef XM7DASH
	PositioningSubWindow(hParent, &rect, index);
#else
	rect.left = lCharWidth * index;
	rect.top = lCharHeight * index;
	if (rect.top >= 380) {
		rect.top -= 380;
	}
#endif

	/* �E�C���h�E�����́A42�h�b�g * 8 �I�N�^�[�u */
	rect.right = 42 * 8;
	if (opn_use) {
		/* �E�C���h�E�c���́A8 * 3 + 1�h�b�g * 6 �`�����l�� */
		rect.bottom = (8 * 3 + 1) * 6;
	}
	else {
		/* �E�C���h�E�c���́A8 * 3 + 1�h�b�g * 3 �`�����l�� */
		rect.bottom = (8 * 3 + 1) * 3;
	}

	/* �E�C���h�E�^�C�g�������� */
	if (opn_use) {
		LoadString(hResInstance, IDS_SWND_OPNDISP,
					szWndName, sizeof(szWndName));
	}
	else {
		LoadString(hResInstance, IDS_SWND_PSGDISP,
					szWndName, sizeof(szWndName));
	}

	/* �E�C���h�E�N���X�̓o�^ */
	memset(&wcex, 0, sizeof(wcex));
	wcex.cbSize = sizeof(wcex);
	wcex.style = CS_DBLCLKS | CS_VREDRAW | CS_HREDRAW;
	wcex.lpfnWndProc = OPNDispProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hResInstance;
	wcex.hIcon = LoadIcon(hAppInstance, MAKEINTRESOURCE(IDI_WNDICON));
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = szClassName;
	wcex.hIconSm = LoadIcon(hAppInstance, MAKEINTRESOURCE(IDI_WNDICON));
	RegisterClassEx(&wcex);

	/* �E�C���h�E�쐬 */
#ifdef XM7DASH
	if (bPopupSwnd) {
		dwExStyle =	WS_POPUP | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
					| WS_MINIMIZEBOX | WS_BORDER;
	}
	else {
		dwExStyle = WS_CHILD | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
					| WS_MINIMIZEBOX | WS_CLIPSIBLINGS;
	}
	if (bSwndVisible) {
		dwExStyle |= WS_VISIBLE;
	}
	hWnd = CreateWindow(szClassName,
						szWndName,
						dwExStyle,
						rect.left,
						rect.top,
						rect.right,
						rect.bottom,
						hParent,
						NULL,
						hResInstance,
						NULL);
#else
	hWnd = CreateWindow(szClassName,
						szWndName,
						WS_CHILD |
						WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
						| WS_VISIBLE | WS_MINIMIZEBOX | WS_CLIPSIBLINGS,
						rect.left,
						rect.top,
						rect.right,
						rect.bottom,
						hParent,
						NULL,
						hResInstance,
						NULL);
#endif

	/* �L���Ȃ�A�T�C�Y�␳���Ď�O�ɒu�� */
	if (hWnd) {
		GetWindowRect(hWnd, &wrect);
		GetClientRect(hWnd, &crect);
		wrect.right += (rect.right - crect.right);
		wrect.bottom += (rect.bottom - crect.bottom);
		SetWindowPos(hWnd, HWND_TOP, wrect.left, wrect.top,
			wrect.right - wrect.left, wrect.bottom - wrect.top, SWP_NOMOVE);

		/* ��`��ۑ� */
		rOPNDisp = rect;
		if (opn_use) {
			nOPNDisp = 0;
		}
		else {
			nOPNDisp = 24;
		}

		/* ���̑������� */
		InitOPNDisp(hWnd);
	}

	/* ���ʂ������A�� */
	return hWnd;
}

/*-[ OPN���W�X�^�E�C���h�E ]-------------------------------------------------*/

/*
 *	OPN���W�X�^�E�C���h�E
 *	�Z�b�g�A�b�v(OPN���W�X�^�Z�b�g)
 */
static void FASTCALL SetupOPNRegSub(BYTE *p, int cx, BYTE *reg, int x, int y, BOOL fm_flag)
{
	int i;
	int j;
	char string[128];

	/* X�����K�C�h�\�� */
	strncpy(string, "+0+1+2+3+4+5+6+7+8+9+A+B+C+D+E+F", 128);
	memcpy(&p[cx * y + x], string, strlen(string));

	/* ���[�v */
	for (i=0; i<16; i++) {
		if ((i != 0) && (nOPNReg & 16)) {
			continue;
		}

		for (j=0; j<16; j++) {
			if ((i == 0) || fm_flag) {
				_snprintf(string, 128, "%02X", reg[i * 16 + j]);
			}
			else {
				strncpy(string, "--", 128);
			}
			memcpy(&p[cx * (y + i + 2) + x + j * 2], string, strlen(string));
		}
	}
}

/*
 *	OPN���W�X�^�E�C���h�E
 *	�Z�b�g�A�b�v(�v���X�P�[��)
 */
static void FASTCALL SetupOPNRegPs(BYTE *p, int cx, int scale, int x, int y)
{
	char string[128];
	int i;

	/* �v���X�P�[�� */
	if (scale == 2) {
		i = 1;
	}
	else {
		i = (scale * 2) / 3;
	}
	if (nOPNReg & 16) {
		strncpy(string, "Prescaler   FM : -/-   PSG : 1/2", 128);
	}
	else {
		_snprintf(string, 128, "Prescaler   FM : 1/%d   PSG : 1/%d", scale, i);
	}
	memcpy(&p[cx * y + x], string, strlen(string));
}

/*
 *	OPN���W�X�^�E�C���h�E
 *	�Z�b�g�A�b�v
 */
static void FASTCALL SetupOPNReg(BYTE *p, int x, int y)
{
	char string[128];
	int i;

	ASSERT(p);
	ASSERT(x > 0);
	ASSERT(y > 0);

	/* ��U�X�y�[�X�Ŗ��߂� */
	memset(p, 0x20, x * y);

	/* Y�����K�C�h�\�� */
	for (i=0; i<16; i++) {
		if ((i != 0) && (nOPNReg & 16)) {
			continue;
		}

		_snprintf(string, 128, "+%02X", i * 16);
		if (nOPNReg & 16) {
			memcpy(&p[x * (i + 4) + 0], string, strlen(string));
		}
		else {
			memcpy(&p[x * (i + 6) + 0], string, strlen(string));
#if defined(XM7DASH) && defined(OPNAMODE)
			if (nOPNReg & 32) {
				memcpy(&p[x * (i + 25) + 0], string, strlen(string));
			}
#endif
		}
	}

	/* PSG */
	if (nOPNReg & 16) {
#ifdef ROMEO
#if defined(XM7DASH) && defined(FMDLL)
		if (GetUseFmDllFlag(OPN_THG)) {
			strncpy(string, "PSG (Standard / fmdll)", 128);
		}
		else {
			strncpy(string, "PSG (Standard / fmgen)", 128);
		}
#else
		strncpy(string, "PSG (Standard / fmgen)", 128);
#endif
#else
		strncpy(string, "PSG (Standard)", 128);
#endif
		memcpy(&p[x * 0 + 4], string, strlen(string));
		SetupOPNRegSub(p, x, opn_reg[OPN_THG], 4, 2, FALSE);
	}
	else {
#ifdef ROMEO
		/* OPN */
		if (bUseRomeo) {
			strncpy(string, "OPN (Standard / ROMEO)", 128);
		}
#if defined(XM7DASH) && defined(OPNAMODE)
		else if ((nOPNReg & 32) && opna_use[OPN_STD] && opn_use) {
#if defined(XM7DASH) && defined(FMDLL)
			if (GetUseFmDllFlag(OPN_STD)) {
				strncpy(string, "OPNA(Standard / fmdll)", 128);
			}
			else {
				strncpy(string, "OPNA(Standard / fmgen)", 128);
			}
#else
			strncpy(string, "OPNA(Standard / fmgen)", 128);
#endif
		}
#endif
		else {
#if defined(XM7DASH) && defined(FMDLL)
			if (GetUseFmDllFlag(OPN_STD)) {
				strncpy(string, "OPN (Standard / fmdll)", 128);
			}
			else {
				strncpy(string, "OPN (Standard / fmgen)", 128);
			}
#else
			strncpy(string, "OPN (Standard / fmgen)", 128);
#endif
		}
#else
		strncpy(string, "OPN (Standard)", 128);
#endif
		memcpy(&p[x * 0 + 4], string, strlen(string));
		SetupOPNRegPs(p, x, opn_scale[OPN_STD], 4, 2);
		SetupOPNRegSub(p, x, opn_reg[OPN_STD], 4, 4, TRUE);
#if defined(XM7DASH) && defined(OPNAMODE)
		if ((nOPNReg & 32) && opna_use[OPN_STD] && opn_use) {
			SetupOPNRegSub(p, x, opn_reg[OPN_STD] + 256, 4, 23, TRUE);
		}
#endif
	}

	/* WHG */
	if (((nOPNReg & 7) >= 1) && (x > 38)) {
#ifdef ROMEO
		if (bUseRomeo) {
#if defined(XM7DASH) && defined(FMDLL)
			if (GetUseFmDllFlag(OPN_WHG)) {
				strncpy(string, "WHG (Extension / ROMEO+fmdll)", 128);
			}
			else {
				strncpy(string, "WHG (Extension / ROMEO+fmgen)", 128);
			}
#else
			strncpy(string, "WHG (Extension / ROMEO+fmgen)", 128);
#endif
		}
		else {
#if defined(XM7DASH) && defined(FMDLL)
			if (GetUseFmDllFlag(OPN_WHG)) {
				strncpy(string, "WHG (Extension / fmdll)", 128);
			}
			else {
				strncpy(string, "WHG (Extension / fmgen)", 128);
			}
#else
			strncpy(string, "WHG (Extension / fmgen)", 128);
#endif
		}
#else
		strncpy(string, "WHG (Extension)", 128);
#endif
		memcpy(&p[x * 0 + 4 + 32 + 2], string, strlen(string));
		SetupOPNRegPs(p, x, opn_scale[OPN_WHG], 38, 2);
		SetupOPNRegSub(p, x, opn_reg[OPN_WHG], 38, 4, TRUE);
#if defined(XM7DASH) && defined(OPNAMODE)
		if ((nOPNReg & 32) && opna_use[OPN_WHG] && whg_use) {
			SetupOPNRegSub(p, x, opn_reg[OPN_WHG] + 256, 38, 23, TRUE);
		}
#endif
	}
#if defined(XM7DASH) && defined(OPNAMODE)
	else if (((nOPNReg & 8) && ((nOPNReg & 7) == 0)) && (x > 38)) {
#else
	else if ((nOPNReg == 8) && (x > 38)) {
#endif
#ifdef ROMEO
#if defined(XM7DASH) && defined(FMDLL)
		if (GetUseFmDllFlag(OPN_THG)) {
			strncpy(string, "PSG (Standard / fmdll)", 128);
		}
		else {
			strncpy(string, "PSG (Standard / fmgen)", 128);
		}
#else
		strncpy(string, "PSG (Standard / fmgen)", 128);
#endif
#else
		strncpy(string, "PSG (Standard)", 128);
#endif
		memcpy(&p[x * 0 + 4 + 32 + 2], string, strlen(string));
		SetupOPNRegSub(p, x, opn_reg[OPN_THG], 38, 4, FALSE);
	}

	/* THG */
	if (((nOPNReg & 7) >= 2) && (x > 72)) {
#ifdef ROMEO
#if defined(XM7DASH) && defined(FMDLL)
		if (GetUseFmDllFlag(OPN_THG)) {
			strncpy(string, "THG (Extension / fmdll)", 128);
		}
		else {
			strncpy(string, "THG (Extension / fmgen)", 128);
		}
#else
		strncpy(string, "THG (Extension / fmgen)", 128);
#endif
#else
		strncpy(string, "THG (Extension)", 128);
#endif
		memcpy(&p[x * 0 + 38 + 32 + 2], string, strlen(string));
		SetupOPNRegPs(p, x, opn_scale[OPN_THG], 72, 2);
		SetupOPNRegSub(p, x, opn_reg[OPN_THG], 72, 4, TRUE);
#if defined(XM7DASH) && defined(OPNAMODE)
		if ((nOPNReg & 32) && opna_use[OPN_THG] && thg_use) {
			SetupOPNRegSub(p, x, opn_reg[OPN_THG] + 256, 72, 23, TRUE);
		}
#endif
	}
#if defined(XM7DASH) && defined(OPNAMODE)
	else if (((nOPNReg & 8) && ((nOPNReg & 7) == 1)) && (x > 72)) {
#else
	else if ((nOPNReg == 9) && (x > 72)) {
#endif
#ifdef ROMEO
#if defined(XM7DASH) && defined(FMDLL)
		if (GetUseFmDllFlag(OPN_THG)) {
			strncpy(string, "PSG (Standard / fmdll)", 128);
		}
		else {
			strncpy(string, "PSG (Standard / fmgen)", 128);
		}
#else
		strncpy(string, "PSG (Standard / fmgen)", 128);
#endif
#else
		strncpy(string, "PSG (Standard)", 128);
#endif
		memcpy(&p[x * 0 + 38 + 32 + 2], string, strlen(string));
		SetupOPNRegSub(p, x, opn_reg[OPN_THG], 72, 4, FALSE);
	}

#if defined(XM7DASH) && defined(OPNAMODE)
	if (nOPNReg & 32) {
		strncpy(string, "STD", sizeof(string));
		memcpy(&p[x * 4], string, strlen(string));
		strncpy(string, "EXT", sizeof(string));
		memcpy(&p[x * 23], string, strlen(string));
	}
#endif
}

/*
 *	OPN���W�X�^�E�C���h�E
 *	�`��
 */
static void FASTCALL DrawOPNReg(HWND hWnd, HDC hDC)
{
	RECT rect;
	int x, y;

	ASSERT(hWnd);
	ASSERT(hDC);

	/* �E�C���h�E�W�I���g���𓾂� */
	GetClientRect(hWnd, &rect);
	x = rect.right / lCharWidth;
	y = rect.bottom / lCharHeight;
	if ((x == 0) || (y == 0)) {
		return;
	}

	/* �Z�b�g�A�b�v */
	if (!pOPNReg) {
		return;
	}
	SetupOPNReg(pOPNReg, x, y);

	/* �`�� */
	DrawWindowText(hDC, pOPNReg, x, y);
}

/*
 *	OPN���W�X�^�E�C���h�E
 *	���t���b�V��
 */
void FASTCALL RefreshOPNReg(void)
{
	HWND hWnd;
	HDC hDC;

	/* ��ɌĂ΂��̂ŁA���݃`�F�b�N���邱�� */
	if (hSubWnd[SWND_OPNREG] == NULL) {
		return;
	}

	/* �`�� */
	hWnd = hSubWnd[SWND_OPNREG];
	hDC = GetDC(hWnd);
	DrawOPNReg(hWnd, hDC);
	ReleaseDC(hWnd, hDC);
}

/*
 *	OPN���W�X�^�E�C���h�E
 *	�T�C�Y�ύX
 */
void FASTCALL ReSizeOPNReg(void)
{
	HWND hWnd;
	UINT uMode;
	RECT wrect;
	RECT crect;
	char szWndName[128];
	int cx;
	int cy;

	/* ��ɌĂ΂��̂ŁA���݃`�F�b�N���邱�� */
	if (hSubWnd[SWND_OPNREG] == NULL) {
		return;
	}

	/* �W�I���g���ύX�`�F�b�N */
	hWnd = hSubWnd[SWND_OPNREG];
	uMode = 0;
	cx = 36;
	cy = 22;
	if (whg_use) {
		uMode = 1;
		cx = 36 + 32 + 2;
	}
	if (thg_use) {
		uMode = 2;
		cx = 36 + (32 + 2) * 2;
	}
#if XM7_VER >= 3 && defined(XM7DASH)
	if ((uMode < 2) && (fm_subtype < FMSUB_FM77AV)) {
#else
	if ((uMode < 2) && (fm7_ver == 1)) {
#endif
		uMode |= 8;
		cx += 32 + 2;
	}
#if XM7_VER >= 3 && defined(XM7DASH)
	if (!opn_use && (fm_subtype < FMSUB_FM77AV)) {
#else
	if (!opn_use && (fm7_ver == 1)) {
#endif
		uMode = 24;
		cx = 36;
		cy = 5;
	}
#if defined(XM7DASH) && defined(OPNAMODE)
	if ((opna_use[OPN_STD] && opn_use) ||
		(opna_use[OPN_WHG] && whg_use) ||
		(opna_use[OPN_THG] && thg_use)) {
		uMode |= 32;
		cy = 22 + 19;
	}
#endif
	if (IsIconic(hWnd)) {
		/* �A�C�R�����`�F�b�N */
		uMode |= 0x80000000;
	}
	if (uMode == nOPNReg) {
		return;
	}

	/* ���b�N */
	LockVM();

	/* �E�C���h�E�^�C�g����ύX */
#if defined(XM7DASH) && defined(OPNAMODE)
	if ((uMode & 48) ^ (nOPNReg & 48)) {
		if (uMode & 32) {
			LoadString(hResInstance, IDS_SWND_OPNAREG,
						szWndName, sizeof(szWndName));
		}
		else
#else
	if ((uMode & 16) ^ (nOPNReg & 16)) {
#endif
		if (opn_use) {
			LoadString(hResInstance, IDS_SWND_OPNREG,
						szWndName, sizeof(szWndName));
		}
		else {
			LoadString(hResInstance, IDS_SWND_PSGREG,
						szWndName, sizeof(szWndName));
		}
		SetWindowText(hWnd, szWndName);
	}

	/* ���[�h�`�F���W */
	nOPNReg = uMode;

	/* �o�b�t�@��� */
	free(pOPNReg);
	pOPNReg = malloc(2 * cx * cy);
	memset(pOPNReg, 0xff, 2 * cx * cy);
	ASSERT(pOPNReg);

	/* �E�B���h�E��`�ύX */
	GetWindowRect(hWnd, &wrect);
	GetClientRect(hWnd, &crect);
	wrect.right -= wrect.left;
	wrect.right -= crect.right;
	wrect.right += cx * lCharWidth;
	wrect.bottom -= wrect.top;
	wrect.bottom -= crect.bottom;
	wrect.bottom += cy * lCharHeight;
	SetWindowPos(hWnd, HWND_TOP, 0, 0, wrect.right, wrect.bottom,
							SWP_NOZORDER | SWP_NOMOVE);
#ifdef XM7DASH
	if (bPopupSwnd) {
		SetForegroundWindow(hMainWnd);
	}
#endif

	/* �A�����b�N */
	UnlockVM();
}

/*
 *	OPN���W�X�^�E�C���h�E
 *	�ĕ`��
 */
static void FASTCALL PaintOPNReg(HWND hWnd)
{
	HDC hDC;
	PAINTSTRUCT ps;
	RECT rect;
	BYTE *p;
	int x, y;

	ASSERT(hWnd);

	/* �|�C���^��ݒ�(���݂��Ȃ���Ή������Ȃ�) */
	p = pOPNReg;
	if (!p) {
		return;
	}

	/* �E�C���h�E�W�I���g���𓾂� */
	GetClientRect(hWnd, &rect);
	x = rect.right / lCharWidth;
	y = rect.bottom / lCharHeight;

	/* �㔼�G���A��FF�Ŗ��߂� */
	if ((x > 0) && (y > 0)) {
		memset(&p[x * y], 0xff, x * y);
	}

	/* �`�� */
	hDC = BeginPaint(hWnd, &ps);
	ASSERT(hDC);
	DrawOPNReg(hWnd, hDC);
	EndPaint(hWnd, &ps);
}

/*
 *	OPN���W�X�^�E�C���h�E
 *	�E�C���h�E�v���V�[�W��
 */
static LRESULT CALLBACK OPNRegProc(HWND hWnd, UINT message,
								 WPARAM wParam, LPARAM lParam)
{
	/* ���b�Z�[�W�� */
	switch (message) {
		/* �E�C���h�E�ĕ`�� */
		case WM_PAINT:
			/* ���b�N���K�v */
			LockVM();
			PaintOPNReg(hWnd);
			UnlockVM();
			return 0;

		/* �E�C���h�E�폜 */
		case WM_DESTROY:
			LockVM();

			/* ���C���E�C���h�E�֎����ʒm */
			DestroySubWindow(hWnd, &pOPNReg, NULL);

			UnlockVM();
			break;

#ifdef XM7DASH
		/* �E�B���h�E�ړ� */
		case WM_MOVE:
			/* �ŏ������̃T�u�E�B���h�E���Ҕ� */
			MoveSubWindow(hWnd);
			break;
#endif
	}

	/* �f�t�H���g �E�C���h�E�v���V�[�W�� */
	return DefWindowProc(hWnd, message, wParam, lParam);
}

/*
 *	OPN���W�X�^�E�C���h�E
 *	�E�C���h�E�쐬
 */
HWND FASTCALL CreateOPNReg(HWND hParent, int index)
{
	WNDCLASSEX wcex;
	char szClassName[] = "XM7_OPNReg";
	char szWndName[128];
	RECT rect;
	RECT crect, wrect;
	HWND hWnd;
#ifdef XM7DASH
	DWORD dwExStyle;
#endif

	ASSERT(hParent);

	/* �E�C���h�E��`���v�Z */
#ifdef XM7DASH
	PositioningSubWindow(hParent, &rect, index);
#else
	rect.left = lCharWidth * index;
	rect.top = lCharHeight * index;
	if (rect.top >= 380) {
		rect.top -= 380;
	}
#endif
	rect.right = lCharWidth * 36;
	if (opn_use) {
		rect.bottom = lCharHeight * 22;
	}
	else {
		rect.bottom = lCharHeight * 5;
	}

	/* �E�C���h�E�^�C�g��������A�o�b�t�@�m�� */
	if (opn_use) {
		LoadString(hResInstance, IDS_SWND_OPNREG,
					szWndName, sizeof(szWndName));
		nOPNReg = 0;
	}
	else {
		LoadString(hResInstance, IDS_SWND_PSGREG,
					szWndName, sizeof(szWndName));
		nOPNReg = 24;
	}
	pOPNReg = malloc(2 * (rect.right / lCharWidth) *
								(rect.bottom / lCharHeight));

	/* �E�C���h�E�N���X�̓o�^ */
	memset(&wcex, 0, sizeof(wcex));
	wcex.cbSize = sizeof(wcex);
	wcex.style = CS_VREDRAW | CS_HREDRAW;
	wcex.lpfnWndProc = OPNRegProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hResInstance;
	wcex.hIcon = LoadIcon(hAppInstance, MAKEINTRESOURCE(IDI_WNDICON));
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = szClassName;
	wcex.hIconSm = LoadIcon(hAppInstance, MAKEINTRESOURCE(IDI_WNDICON));
	RegisterClassEx(&wcex);

	/* �E�C���h�E�쐬 */
#ifdef XM7DASH
	if (bPopupSwnd) {
		dwExStyle =	WS_POPUP | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
					| WS_MINIMIZEBOX | WS_BORDER;
	}
	else {
		dwExStyle = WS_CHILD | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
					| WS_MINIMIZEBOX | WS_CLIPSIBLINGS;
	}
	if (bSwndVisible) {
		dwExStyle |= WS_VISIBLE;
	}
	hWnd = CreateWindow(szClassName,
						szWndName,
						dwExStyle,
						rect.left,
						rect.top,
						rect.right,
						rect.bottom,
						hParent,
						NULL,
						hResInstance,
						NULL);
#else
	hWnd = CreateWindow(szClassName,
						szWndName,
						WS_CHILD |
						WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
						| WS_VISIBLE | WS_MINIMIZEBOX | WS_CLIPSIBLINGS,
						rect.left,
						rect.top,
						rect.right,
						rect.bottom,
						hParent,
						NULL,
						hResInstance,
						NULL);
#endif

	/* �L���Ȃ�A�T�C�Y�␳���Ď�O�ɒu�� */
	if (hWnd) {
		GetWindowRect(hWnd, &wrect);
		GetClientRect(hWnd, &crect);
		wrect.right += (rect.right - crect.right);
		wrect.bottom += (rect.bottom - crect.bottom);
		SetWindowPos(hWnd, HWND_TOP, wrect.left, wrect.top,
			wrect.right - wrect.left, wrect.bottom - wrect.top, SWP_NOMOVE);
	}

	/* ���ʂ������A�� */
	return hWnd;
}

/*-[ FDC�E�C���h�E ]---------------------------------------------------------*/

/*
 *	FDC�E�C���h�E
 *	�Z�b�g�A�b�v(�t���O)
 */
static void FASTCALL SetupFDCFlag(BYTE *p, BYTE length, char *title, BYTE flag)
{
	char string[20];
	int i;

	/* ������ */
	memset(string, 0x20, length);
	string[length] = '\0';

	/* �R�s�[ */
	for (i=0; i<length; i++) {
		if (title[i] == '\0') {
			break;
		}
		string[i] = title[i];
	}

	/* �t���O�ɉ����Đݒ� */
	if (flag) {
#ifdef XM7DASH
		strncpy(&string[length - 2], "On", sizeof(string)-length+2);
#else
		strncpy(&string[length - 2], "On", 4);
#endif
	}
	else {
#ifdef XM7DASH
		strncpy(&string[length - 3], "Off", sizeof(string)-length+3);
#else
		strncpy(&string[length - 3], "Off", 4);
#endif
	}

	/* �Z�b�g */
	memcpy(p, string, length);
}

/*
 *	FDC�E�C���h�E
 *	�Z�b�g�A�b�v(�R�}���h)
 */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
static void FASTCALL SetupFDCCmd(BYTE *p, int x, int cx, int no)
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
static void FASTCALL SetupFDCCmd(BYTE *p, int x, int cx)
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
{
	const BYTE steprate[4] = { 6, 12, 20, 30 };

	BYTE high, low;
	char buffer[128];
	int y;

	ASSERT(p);
	ASSERT(cx > 0);

	/* ������ */
	y = 0;

#if XM7_VER >= 3
	/* 2DD���[�h */
	if (fdc_2ddmode) {
		strncpy(buffer, "2DD Mode", 128);
		memcpy(&p[x + 2 * cx], buffer, strlen(buffer));
	}

	/* DMA */
	if (dma_pcr & 0x01) {
		_snprintf(buffer, 128,  "DMA %04X", dma_bcr[0]);
		memcpy(&p[10 + 2 * cx], buffer, strlen(buffer));
	}
#elif XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	/* FDC */
	if (nFDC != 0) {
		if (fm_subtype == FMSUB_FM77) {
			if (no) {
				strncpy(buffer, "1MB FDC        ", sizeof(buffer)-1);
			}
			else {
				strncpy(buffer, "320KB FDC      ", sizeof(buffer)-1);
			}
			if ((no && sfdc_mode) || (!no && !sfdc_mode)) {
				strncat(buffer, "[*]", sizeof(buffer)-strlen(buffer)-1);
			}
			else {
				strncat(buffer, "[ ]", sizeof(buffer)-strlen(buffer)-1);
			}
		}
		else {
			if (no) {
				if (dma_pcr & 0x08) {
					_snprintf(buffer, sizeof(buffer)-1,"SFDC      DMA %04X",
																dma_bcr[3]);
				}
				else {
					strncpy(buffer, "SFDC", sizeof(buffer)-1);
				}
			}
			else {
				strncpy(buffer, "MFDC", sizeof(buffer)-1);
			}
		}
		memcpy(&p[x + 2 * cx], buffer, strlen(buffer));
	}
#endif

#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	if (fdc_command[no] == 0xff) {
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	if (fdc_command == 0xff) {
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		/* �R�}���h���� */
		strncpy(buffer, "NO COMMAND", 128);
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		return;
	}

#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	high = (BYTE)(fdc_command[no] >> 4);
	low = (BYTE)(fdc_command[no] & 0x0f);
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	high = (BYTE)(fdc_command >> 4);
	low = (BYTE)(fdc_command & 0x0f);
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	if (high < 8) {
		/* TYPE I */
		switch (high) {
			/* RESTORE */
			case 0:
				strncpy(buffer, "RESTORE", 128);
				break;
			/* SEEK */
			case 1:
				strncpy(buffer, "SEEK", 128);
				break;
			/* STEP */
			case 2:
			case 3:
				strncpy(buffer, "STEP", 128);
				break;
			/* STEP IN */
			case 4:
			case 5:
				strncpy(buffer, "STEP IN", 128);
				break;
			/* STEP IN */
			case 6:
			case 7:
				strncpy(buffer, "STEP OUT", 128);
				break;
		}
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		y++;

		strncpy(buffer, "(TYPE I)", 128);
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		y += 3;

		_snprintf(buffer, 128,  "Step Rate     %2dms", steprate[low & 0x03]);
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		y++;

		SetupFDCFlag(&p[x + y * cx], 18, "Verify", (BYTE)(low & 0x04));
		y++;

		strncpy(buffer, "Head        ", 128);
		if (low & 0x08) {
#ifdef XM7DASH
			strncat(buffer, "  Load", 128 - strlen(buffer) - 1);
#else
			strncat(buffer, "  Load", 128 - 6 - 1);
#endif
		}
		else {
#ifdef XM7DASH
			strncat(buffer, "Unload", 128 - strlen(buffer) - 1);
#else
			strncat(buffer, "Unload", 128 - 6 - 1);
#endif
		}
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		y++;

		if (high >= 2) {
			SetupFDCFlag(&p[x + y * cx], 18, "Update Track", (BYTE)(low & 0x10));
		}
#if !(XM7_VER == 1 && defined(SFDC) && defined(XM7DASH))
		return;
#endif	/* !(XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)) */
	}
	else if (high == 0x0d) {
		/* TYPE IV */
		strncpy(buffer, "FORCE INTERRUPT", 128);
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		y++;

		strncpy(buffer, "(TYPE IV)", 128);
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		y += 3;

		SetupFDCFlag(&p[x + (y + 0) * cx], 18, "READY  In", (BYTE)(low & 0x01));
		SetupFDCFlag(&p[x + (y + 1) * cx], 18, "READY Out", (BYTE)(low & 0x02));
		SetupFDCFlag(&p[x + (y + 2) * cx], 18, "INDEX", (BYTE)(low & 0x04));
		SetupFDCFlag(&p[x + (y + 3) * cx], 18, "One Shot", (BYTE)(low & 0x08));
	}
	else {
		/* TYPE II/III */
		switch (high) {
			case 0x08:
			case 0x09:
				strncpy(buffer, "READ DATA", 128);
				break;
			case 0x0a:
			case 0x0b:
				strncpy(buffer, "WRITE DATA", 128);
				break;
			case 0x0c:
				strncpy(buffer, "READ ADDRESS", 128);
				break;
			case 0x0e:
				strncpy(buffer, "READ TRACK", 128);
				break;
			case 0x0f:
				strncpy(buffer, "WRITE TRACK", 128);
				break;
		}
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		y++;

		if (high < 0x0c) {
			strncpy(buffer, "(TYPE II)", 128);
			memcpy(&p[x + y * cx], buffer, strlen(buffer));
			y += 2;

			SetupFDCFlag(&p[x + y * cx], 18, "Multi Sector", (BYTE)(high & 0x01));
			y++;

			strncpy(buffer, "Compare Side   ", 128);
			if (low & 0x02) {
				if (low & 0x08) {
#ifdef XM7DASH
					strncat(buffer, "  0", 128 - strlen(buffer) - 1);
#else
					strncat(buffer, "  0", 128 - 3 - 1);
#endif
				}
				else {
#ifdef XM7DASH
					strncat(buffer, "  1", 128 - strlen(buffer) - 1);
#else
					strncat(buffer, "  1", 128 - 3 - 1);
#endif
				}
			} else {
#ifdef XM7DASH
				strncat(buffer, "Off", 128 - strlen(buffer) - 1);
#else
				strncat(buffer, "Off", 128 - 3 - 1);
#endif
			}
			memcpy(&p[x + y * cx], buffer, strlen(buffer));
			y++;

			strncpy(buffer, "Addr. Mark ", 128);
			if (low & 0x01) {
#ifdef XM7DASH
				strncat(buffer, "Deleted", 128 - strlen(buffer) - 1);
#else
				strncat(buffer, "Deleted", 128 - 7 - 1);
#endif
			}
			else {
#ifdef XM7DASH
				strncat(buffer, " Normal", 128 - strlen(buffer) - 1);
#else
				strncat(buffer, " Normal", 128 - 7 - 1);
#endif
			}
			memcpy(&p[x + y * cx], buffer, strlen(buffer));
			y++;
		}
		else {
			strncpy(buffer, "(TYPE III)", 128);
			memcpy(&p[x + y * cx], buffer, strlen(buffer));
			y += 5;
		}

#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		_snprintf(buffer, 128,  "Total Bytes   %04X", fdc_totalcnt[no]);
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		y++;

		_snprintf(buffer, 128,  "Xfer. Bytes   %04X", fdc_nowcnt[no]);
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		_snprintf(buffer, 128,  "Total Bytes   %04X", fdc_totalcnt);
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		y++;

		_snprintf(buffer, 128,  "Xfer. Bytes   %04X", fdc_nowcnt);
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	}

#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	/* 1MB���[�h */
	if (fm_subtype == FMSUB_FM77 && no) {
		/* SFD���荞�݃��[�h */
		strncpy(buffer, "Interrupt   ", sizeof(buffer)-1);
		if (sfd_firq_mode) {
			strncat(buffer, "   SFD", sizeof(buffer)-strlen(buffer)-1);
		}
		else {
			strncat(buffer, "Normal", sizeof(buffer)-strlen(buffer)-1);
		}
		memcpy(&p[x + 8 * cx], buffer, strlen(buffer));
	}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
}

/*
 *	FDC�E�C���h�E
 *	�Z�b�g�A�b�v(���W�X�^)
 */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
static void FASTCALL SetupFDCReg(BYTE *p, int x, int cx, int no)
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
static void FASTCALL SetupFDCReg(BYTE *p, int x, int cx)
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
{
	int y;
	char buffer[128];

	ASSERT(p);
	ASSERT(cx > 0);

	/* ������ */
	y = 0;

#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	_snprintf(buffer, 128,  "Drive   %1d", fdc_drvreg[no]);
	if (fdc_motor[no]) {
		strncat(buffer, "( On)", sizeof(buffer)-strlen(buffer)-1);
	}
	else {
		strncat(buffer, "(Off)", sizeof(buffer)-strlen(buffer)-1);
	}
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

	if (fdc_drvreg[no] < FDC_DRIVES) {
		_snprintf(buffer, 128, "Track       %02X", fdc_track[no][fdc_drvreg[no]]);
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
	}
	y++;

	_snprintf(buffer, 128, "Track  Reg. %02X", fdc_trkreg[no]);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

	_snprintf(buffer, 128, "Sector Reg. %02X", fdc_secreg[no]);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

	_snprintf(buffer, 128, "Side   Reg. %02X", fdc_sidereg[no]);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

	_snprintf(buffer, 128, "Data   Reg. %02X", fdc_datareg[no]);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

	SetupFDCFlag(&p[x + (y + 0) * cx], 14, "DRQ", (BYTE)(fdc_drqirq[no] & 0x80));
	SetupFDCFlag(&p[x + (y + 1) * cx], 14, "IRQ", (BYTE)(fdc_drqirq[no] & 0x40));
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	_snprintf(buffer, 128,  "Drive   %1d", fdc_drvreg);
	if (fdc_motor) {
#ifdef XM7DASH
		strncat(buffer, "( On)", 128 - strlen(buffer) - 1);
#else
		strncat(buffer, "( On)", 128 - 4 - 1);
#endif
	}
	else {
#ifdef XM7DASH
		strncat(buffer, "(Off)", 128 - strlen(buffer) - 1);
#else
		strncat(buffer, "(Off)", 128 - 4 - 1);
#endif
	}
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

	if (fdc_drvreg < FDC_DRIVES) {
		_snprintf(buffer, 128,  "Track       %02X", fdc_track[fdc_drvreg]);
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
	}
	y++;

	_snprintf(buffer, 128,  "Track  Reg. %02X", fdc_trkreg);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

	_snprintf(buffer, 128,  "Sector Reg. %02X", fdc_secreg);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

	_snprintf(buffer, 128,  "Side   Reg. %02X", fdc_sidereg);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

	_snprintf(buffer, 128,  "Data   Reg. %02X", fdc_datareg);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

	SetupFDCFlag(&p[x + (y + 0) * cx], 14, "DRQ", (BYTE)(fdc_drqirq & 0x80));
	SetupFDCFlag(&p[x + (y + 1) * cx], 14, "IRQ", (BYTE)(fdc_drqirq & 0x40));
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */

#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	if (no) {
		y+=2;

		/* SFDC�P���x/�{���x */
		if (sfdc_density) {
			strncpy(buffer, "Double ", sizeof(buffer)-1);
		}
		else {
			strncpy(buffer, "Single ", sizeof(buffer)-1);
		}
		strncat(buffer, "Density", sizeof(buffer)-strlen(buffer)-1);
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
	}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
}

/*
 *	FDC�E�C���h�E
 *	�Z�b�g�A�b�v(�X�e�[�^�X)
 */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
static void FASTCALL SetupFDCStat(BYTE *p, int x, int cx, int no)
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
static void FASTCALL SetupFDCStat(BYTE *p, int x, int cx)
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
{
	int y;
	int type;
	int i;
	BYTE dat;
	BYTE bit;
	char buffer[128];

	ASSERT(p);
	ASSERT(cx > 0);

	/* ������ */
	y = 0;

	/* �^�C�v���� */
	type = 0;
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	switch (fdc_cmdtype[no]) {
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	switch (fdc_cmdtype) {
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		case 2:
			/* READ DATA */
			type = 1;
			break;
		case 3:
			/* WRITE DATA */
			type = 2;
			break;
		case 4:
			/* READ ADDRESS */
			type = 1;
			break;
		case 5:
			/* WRITE TRACK */
			type = 2;
			break;
		case 6:
			/* READ TRACK */
			type = 1;
			break;
		default:
			break;
	}

	/* �����ݒ� */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	dat = fdc_status[no];
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	dat = fdc_status;
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	bit = 0x80;

	/* �W�r�b�g���[�v */
	for (i=7; i>=0; i--) {
		_snprintf(buffer, 128,  "bit%d ", i);
		if (dat & bit) {
			switch (i) {
				/* BUSY */
				case 0:
#ifdef XM7DASH
					strncat(buffer, "BUSY", 128 - strlen(buffer) - 1);
#else
					strncat(buffer, "BUSY", 128 - 4 - 1);
#endif
					break;
				/* INDEX or DATA REQUEST */
				case 1:
					if (type == 0) {
#ifdef XM7DASH
						strncat(buffer, "INDEX", 128 - strlen(buffer) - 1);
#else
						strncat(buffer, "INDEX", 128 - 5 - 1);
#endif
					}
					else {
#ifdef XM7DASH
						strncat(buffer, "DATA REQUEST", 128 - strlen(buffer) - 1);
#else
						strncat(buffer, "DATA REQUEST", 128 - 13 - 1);
#endif
					}
					break;
				/* TRACK00 or LOST DATA */
				case 2:
					if (type == 0) {
#ifdef XM7DASH
						strncat(buffer, "TRACK00", 128 - strlen(buffer) - 1);
#else
						strncat(buffer, "TRACK00", 128 - 7 - 1);
#endif
					}
					else {
#ifdef XM7DASH
						strncat(buffer, "LOST DATA", 128 - strlen(buffer) - 1);
#else
						strncat(buffer, "LOST DATA", 128 - 9 - 1);
#endif
					}
					break;
				/* CRC ERROR */
				case 3:
#ifdef XM7DASH
					strncat(buffer, "CRC ERROR", 128 - strlen(buffer) - 1);
#else
					strncat(buffer, "CRC ERROR", 128 - 9 - 1);
#endif
					break;
				/* SEEK ERROR or RECORD NOT FOUND */
				case 4:
					if (type == 0) {
#ifdef XM7DASH
						strncat(buffer, "SEEK ERROR", 128 - strlen(buffer) - 1);
#else
						strncat(buffer, "SEEK ERROR", 128 - 9 - 1);
#endif
					}
					else {
#ifdef XM7DASH
						strncat(buffer, "RECORD NOT FOUND", 128 - strlen(buffer) - 1);
#else
						strncat(buffer, "RECORD NOT FOUND", 128 - 16 - 1);
#endif
					}
					break;
				/* HEAD ENGAGED or RECORD TYPE or WRITE FAULT */
				case 5:
					switch (type) {
						case 0:
#ifdef XM7DASH
							strncat(buffer, "HEAD ENGAGED", 128 - strlen(buffer) - 1);
#else
							strncat(buffer, "HEAD ENGAGED", 128 - 12 - 1);
#endif
							break;
						case 1:
#ifdef XM7DASH
							strncat(buffer, "RECORD TYPE", 128 - strlen(buffer) - 1);
#else
							strncat(buffer, "RECORD TYPE", 128 - 11 - 1);
#endif
							break;
						case 2:
#ifdef XM7DASH
							strncat(buffer, "WRITE FAULT", 128 - strlen(buffer) - 1);
#else
							strncat(buffer, "WRITE FAULT", 128 - 11 - 1);
#endif
							break;
					}
					break;
				/* WRITE PROTECT */
				case 6:
#ifdef XM7DASH
					strncat(buffer, "WRITE PROTECT", 128 - strlen(buffer) - 1);
#else
					strncat(buffer, "WRITE PROTECT", 128 - 13 - 1);
#endif
					break;
				/* NOT READY */
				case 7:
#ifdef XM7DASH
					strncat(buffer, "NOT READY", 128 - strlen(buffer) - 1);
#else
					strncat(buffer, "NOT READY", 128 - 9 - 1);
#endif
					break;
			}
		}
		else {
#ifdef XM7DASH
			strncat(buffer, "----------------", 128 - strlen(buffer) - 1);
#else
			strncat(buffer, "----------------", 128 - 16 - 1);
#endif
		}
		bit >>= 1;
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		y++;
	}

#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	if (no) {
		/* Door Lock */
		if (fdc_doorlock[fdc_drvreg[no]]) {
			strncpy(buffer, "Door Lock", sizeof(buffer)-1);
			memcpy(&p[x + y * cx], buffer, strlen(buffer));
		}
	}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
}

#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
/*
 *	IFDC�E�C���h�E
 */
static void FASTCALL SetupIFDC(BYTE *p, int xx, int cx)
{
	int x, y;
	char buffer[128];

	ASSERT(p);
	ASSERT(cx > 0);

	x = xx;
	y = 0;

	strncpy(buffer, "IFDC", sizeof(buffer)-1);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x = xx + 12;

	/* IFDC ���W�X�^���U�[�u���W�X�^(RRR) */
	_snprintf(buffer, 128, "RRR:%02X", ifdc_rrr);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x = xx + 12 + strlen(buffer);
	switch (ifdc_rrr) {
		/* CMDREG */
		case 0x00:
			strncpy(buffer, "CMDREG", sizeof(buffer)-1);
			break;
		/* TRKREG */
		case 0x01:
			strncpy(buffer, "TRKREG", sizeof(buffer)-1);
			break;
		/* SSREG */
		case 0x02:
			strncpy(buffer, "SSREG", sizeof(buffer)-1);
			break;
		/* SEREG */
		case 0x03:
			strncpy(buffer, "SEREG", sizeof(buffer)-1);
			break;
		/* SIDREG */
		case 0x04:
			strncpy(buffer, "SIDREG", sizeof(buffer)-1);
			break;
		/* DNSREG */
		case 0x05:
			strncpy(buffer, "DNSREG", sizeof(buffer)-1);
			break;
		/* DRVREG */
		case 0x06:
			strncpy(buffer, "DRVREG", sizeof(buffer)-1);
			break;
		/* DLCREG */
		case 0x07:
			strncpy(buffer, "DLCREG", sizeof(buffer)-1);
			break;
		/* ERESET */
		case 0x08:
			strncpy(buffer, "ERESET", sizeof(buffer)-1);
			break;
		/* SFORMT */
		case 0x09:
			strncpy(buffer, "SFORMT", sizeof(buffer)-1);
			break;
		/* SECDAT */
		case 0x0a:
			strncpy(buffer, "SECDAT", sizeof(buffer)-1);
			break;
		/* MODREG */
		case 0x0b:
			strncpy(buffer, "MODREG", sizeof(buffer)-1);
			break;
		/* OTHERS */
		default:
			strncpy(buffer, "OTHERS", sizeof(buffer)-1);
			break;
	}
	memcpy(&p[x + y * cx], "[", 1);
	x += 1;
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x += strlen(buffer);
	memcpy(&p[x + y * cx], "]", 1);
	x = xx + 12 + 18;

	/* IFDC ���W�X�^�f�[�^���W�X�^(RDR) */
	_snprintf(buffer, 128, "RDR:%02X", ifdc_rdr);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x = xx + 12 + 18 + 9;

	/* IFDC �V�X�e���X�e�[�^�X���W�X�^(SSR) */
	_snprintf(buffer, 128, "SSR:%02X", ifdc_ssr);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x = xx + 12 + 18 + 9 + 9;

	/* IFDC FDC�X�e�[�^�X���W�X�^(FSR) */
	_snprintf(buffer, 128, "FSR:%02X", ifdc_fsr);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));

	x = xx;
	y = 1;

	/* IFDC �R�}���h���W�X�^(CMDREG) */
	_snprintf(buffer, 128, "CMDREG:%02X", ifdc_cmdreg);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x += strlen(buffer) + 3;
	memcpy(&p[x + y * cx], "[", 1);
	x += 1;
	switch (ifdc_cmdreg) {
		/* IFDC INITIALIZE */
		case 0x00:
			strncpy(buffer, "IFDC INITIALIZE", sizeof(buffer)-1);
			break;
		/* MAKE SOFT SECTOR FORMAT */
		case 0x01:
			strncpy(buffer, "MAKE SOFT SECTOR FORMAT", sizeof(buffer)-1);
			break;
		/* SEEK TRACK */
		case 0x02:
			strncpy(buffer, "SEEK TRACK", sizeof(buffer)-1);
			break;
		/* READ SECTOR (FLOPPY --> IFDC BUFFER) */
		case 0x03:
			strncpy(buffer, "READ SECTOR (FLOPPY --> IFDC BUFFER)", sizeof(buffer)-1);
			break;
		/* WRITE SECTOR(FLOPPY <-- IFDC BUFFER) */
		case 0x04:
			strncpy(buffer, "WRITE SECTOR(FLOPPY <-- IFDC BUFFER)", sizeof(buffer)-1);
			break;
		/* DATA GET (PROGRAM TRANSFER) FM8 <-- IFDC */
		case 0x05:
			strncpy(buffer, "DATA GET (PROGRAM TRANSFER) FM8 <-- IFDC", sizeof(buffer)-1);
			break;
		/* DATA PUT (PROGRAM TRANSFER) FM8 --> IFDC */
		case 0x06:
			strncpy(buffer, "DATA PUT (PROGRAM TRANSFER) FM8 --> IFDC", sizeof(buffer)-1);
			break;
		/* DATA GET (DMA TRANSFER)     FM8 <-- IFDC */
		case 0x07:
			strncpy(buffer, "DATA GET (DMA TRANSFER)     FM8 <-- IFDC", sizeof(buffer)-1);
			break;
		/* DATA PUT (DMA TRANSFER)     FM8 --> IFDC */
		case 0x08:
			strncpy(buffer, "DATA PUT (DMA TRANSFER)     FM8 --> IFDC", sizeof(buffer)-1);
			break;
		/* DIRECT READ SECTOR (PROGRAM) FM8 <-- FLOPPY */
		case 0x09:
			strncpy(buffer, "DIRECT READ SECTOR (PROGRAM) FM8 <-- FLOPPY", sizeof(buffer)-1);
			break;
		/* DIRECT WRITE SECTOR(PROGRAM) FM8 --> FLOPPY */
		case 0x0a:
			strncpy(buffer, "DIRECT WRITE SECTOR(PROGRAM) FM8 --> FLOPPY", sizeof(buffer)-1);
			break;
		/* DIRECT READ SECTOR (DMA)     FM8 <-- FLOPPY) */
		case 0x0b:
			strncpy(buffer, "DIRECT READ SECTOR (DMA)     FM8 <-- FLOPPY", sizeof(buffer)-1);
			break;
		/* DIRECT WRITE SECTOR(DMA)     FM8 --> FLOPPY) */
		case 0x0c:
			strncpy(buffer, "DIRECT WRITE SECTOR(DMA)     FM8 --> FLOPPY", sizeof(buffer)-1);
			break;
		/* FLOPPY DISK SEEK TRACK OPERATION */
		case 0x0d:
			strncpy(buffer, "FLOPPY DISK SEEK TRACK OPERATION", sizeof(buffer)-1);
			break;
		/* OTHERS */
		default:
			strncpy(buffer, "OTHERS", sizeof(buffer)-1);
			break;
	}
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x += strlen(buffer);
	memcpy(&p[x + y * cx], "]", 1);

	x = xx;
	y = 2;

	/* IFDC �g���b�N���W�X�^(TRKREG) */
	_snprintf(buffer, 128, "TRKREG:%02X", ifdc_trkreg);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x += 12;

	/* IFDC �Z�N�^�X�^�[�g���W�X�^(SSREG) */
	_snprintf(buffer, 128, "SSREG: %02X", ifdc_ssreg);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x += 12;

	/* IFDC �Z�N�^�G���h���W�X�^(SEREG) */
	_snprintf(buffer, 128, "SEREG: %02X", ifdc_sereg);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x += 12;

	/* IFDC �T�C�h���W�X�^(SIDREG) */
	_snprintf(buffer, 128, "SIDREG:%02X", ifdc_sidreg);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x += 12;

	/* IFDC ���x���W�X�^(DNSREG) */
	_snprintf(buffer, 128, "DNSREG:%02X", ifdc_dnsreg);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));

	x = xx;
	y++;

	/* IFDC �h���C�u���W�X�^(DRVREG) */
	_snprintf(buffer, 128, "DRVREG:%02X", ifdc_drvreg);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x += 12;

	/* IFDC �h�A���b�N���W�X�^(DLCREG) */
	_snprintf(buffer, 128, "DLCREG:%02X", ifdc_dlcreg);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x += 12;

	/* IFDC �Z�N�^�t�H�[�}�b�g(SFORMT) */
	_snprintf(buffer, 128, "SFORMT:%02X", ifdc_sformt);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x += 12;

	/* IFDC �Z�N�^�����O�X(SECDAT) */
	_snprintf(buffer, 128, "SECDAT:%02X", ifdc_secdat);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	x += 12;

	/* IFDC ���[�h�Z�b�g���W�X�^(MODREG) */
	_snprintf(buffer, 128, "MODREG:%02X", ifdc_modreg);
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */

/*
 *	FDC�E�C���h�E
 *	�Z�b�g�A�b�v
 */
static void FASTCALL SetupFDC(BYTE *p, int x, int y)
{
	ASSERT(p);
	ASSERT(x > 0);
	ASSERT(y > 0);

	/* ��U�X�y�[�X�Ŗ��߂� */
	memset(p, 0x20, x * y);

	/* �T�u�֐����Ă� */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	SetupFDCCmd(p, 0, x, FDC_M);
	SetupFDCReg(p, 20, x, FDC_M);
	SetupFDCStat(p, 36, x, FDC_M);

	if (nFDC != 0) {
		memset(&p[8 * x], '-', x);
		SetupFDCCmd(p, 9 * x + 0, x, FDC_S);
		SetupFDCReg(p, 9 * x + 20, x, FDC_S);
		SetupFDCStat(p, 9 * x + 36, x, FDC_S);
	}

	if (nFDC != 0 && fm_subtype == FMSUB_FM8) {
		memset(&p[18 * x], '-', x);
		SetupIFDC(p, 19 * x + 0, x);
	}
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	SetupFDCCmd(p, 0, x);
	SetupFDCReg(p, 20, x);
	SetupFDCStat(p, 36, x);
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
}

/*
 *	FDC�E�C���h�E
 *	�`��
 */
static void FASTCALL DrawFDC(HWND hWnd, HDC hDC)
{
	RECT rect;
	int x, y;

	ASSERT(hWnd);
	ASSERT(hDC);

	/* �E�C���h�E�W�I���g���𓾂� */
	GetClientRect(hWnd, &rect);
	x = rect.right / lCharWidth;
	y = rect.bottom / lCharHeight;
	if ((x == 0) || (y == 0)) {
		return;
	}

	/* �Z�b�g�A�b�v */
	if (!pFDC) {
		return;
	}
	SetupFDC(pFDC, x, y);

	/* �`�� */
	DrawWindowText(hDC, pFDC, x, y);
}

/*
 *	FDC�E�C���h�E
 *	���t���b�V��
 */
void FASTCALL RefreshFDC(void)
{
	HWND hWnd;
	HDC hDC;

	/* ��ɌĂ΂��̂ŁA���݃`�F�b�N���邱�� */
	if (hSubWnd[SWND_FDC] == NULL) {
		return;
	}

	/* �`�� */
	hWnd = hSubWnd[SWND_FDC];
	hDC = GetDC(hWnd);
	DrawFDC(hWnd, hDC);
	ReleaseDC(hWnd, hDC);
}

#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
/*
 *	FDC�E�C���h�E
 *	�T�C�Y�ύX
 */
void FASTCALL ReSizeFDC(void)
{
	HWND hWnd;
	UINT uMode;
	RECT wrect;
	RECT crect;
	int cx;
	int cy;

	/* ��ɌĂ΂��̂ŁA���݃`�F�b�N���邱�� */
	if (hSubWnd[SWND_FDC] == NULL) {
		return;
	}

	/* �ŏ����Ȃ�A�������Ȃ� */
	hWnd = hSubWnd[SWND_FDC];
	if (IsIconic(hWnd)) {
		return;
	}

	/* �W�I���g���ύX�`�F�b�N */
	uMode = 0;
	cx = 57;
	cy = 8;
	if (fdc_command[FDC_S] != 0xff ||
		(fm_subtype == FMSUB_FM8 && ifdc_rrr != 0xff)) {
		if (fm_subtype == FMSUB_FM8) {
			uMode = 2;
			cy = 23;
		}
		else {
			uMode = 1;
			cy = 18;
		}
	}

	if (uMode == nFDC) {
		return;
	}

	/* ���b�N */
	LockVM();

	/* ���[�h�`�F���W */
	nFDC = uMode;

	/* �o�b�t�@��� */
	free(pFDC);
	pFDC = malloc(2 * cx * cy);
	memset(pFDC, 0xff, 2 * cx * cy);
	ASSERT(pFDC);

	/* �E�B���h�E��`�ύX */
	GetWindowRect(hWnd, &wrect);
	GetClientRect(hWnd, &crect);
	wrect.right -= wrect.left;
	wrect.right -= crect.right;
	wrect.right += cx * lCharWidth;
	wrect.bottom -= wrect.top;
	wrect.bottom -= crect.bottom;
	wrect.bottom += cy * lCharHeight;
	SetWindowPos(hWnd, HWND_TOP, 0, 0, wrect.right, wrect.bottom,
							SWP_NOZORDER | SWP_NOMOVE);
#ifdef XM7DASH
	if (bPopupSwnd) {
		SetForegroundWindow(hMainWnd);
	}
#endif

	/* �A�����b�N */
	UnlockVM();
}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */

/*
 *	FDC�E�C���h�E
 *	�ĕ`��
 */
static void FASTCALL PaintFDC(HWND hWnd)
{
	HDC hDC;
	PAINTSTRUCT ps;
	RECT rect;
	BYTE *p;
	int x, y;

	ASSERT(hWnd);

	/* �|�C���^��ݒ�(���݂��Ȃ���Ή������Ȃ�) */
	p = pFDC;
	if (!p) {
		return;
	}

	/* �E�C���h�E�W�I���g���𓾂� */
	GetClientRect(hWnd, &rect);
	x = rect.right / lCharWidth;
	y = rect.bottom / lCharHeight;

	/* �㔼�G���A��FF�Ŗ��߂� */
	if ((x > 0) && (y > 0)) {
		memset(&p[x * y], 0xff, x * y);
	}

	/* �`�� */
	hDC = BeginPaint(hWnd, &ps);
	ASSERT(hDC);
	DrawFDC(hWnd, hDC);
	EndPaint(hWnd, &ps);
}

/*
 *	FDC�E�C���h�E
 *	�E�C���h�E�v���V�[�W��
 */
static LRESULT CALLBACK FDCProc(HWND hWnd, UINT message,
								 WPARAM wParam, LPARAM lParam)
{
	/* ���b�Z�[�W�� */
	switch (message) {
		/* �E�C���h�E�ĕ`�� */
		case WM_PAINT:
			/* ���b�N���K�v */
			LockVM();
			PaintFDC(hWnd);
			UnlockVM();
			return 0;

		/* �E�C���h�E�폜 */
		case WM_DESTROY:
			LockVM();

			/* ���C���E�C���h�E�֎����ʒm */
			DestroySubWindow(hWnd, &pFDC, NULL);

			UnlockVM();
			break;

#ifdef XM7DASH
		/* �E�B���h�E�ړ� */
		case WM_MOVE:
			/* �ŏ������̃T�u�E�B���h�E���Ҕ� */
			MoveSubWindow(hWnd);
			break;
#endif
	}

	/* �f�t�H���g �E�C���h�E�v���V�[�W�� */
	return DefWindowProc(hWnd, message, wParam, lParam);
}

/*
 *	FDC�E�C���h�E
 *	�E�C���h�E�쐬
 */
HWND FASTCALL CreateFDC(HWND hParent, int index)
{
	WNDCLASSEX wcex;
	char szClassName[] = "XM7_FDC";
	char szWndName[128];
	RECT rect;
	RECT crect, wrect;
	HWND hWnd;
#ifdef XM7DASH
	DWORD dwExStyle;
#endif

	ASSERT(hParent);

	/* �E�C���h�E��`���v�Z */
#ifdef XM7DASH
	PositioningSubWindow(hParent, &rect, index);
#else
	rect.left = lCharWidth * index;
	rect.top = lCharHeight * index;
	if (rect.top >= 380) {
		rect.top -= 380;
	}
#endif
	rect.right = lCharWidth * 57;
	rect.bottom = lCharHeight * 8;

	/* �E�C���h�E�^�C�g��������A�o�b�t�@�m�� */
	LoadString(hResInstance, IDS_SWND_FDC,
				szWndName, sizeof(szWndName));
	pFDC = malloc(2 * (rect.right / lCharWidth) *
								(rect.bottom / lCharHeight));
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	nFDC = 0;
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */

	/* �E�C���h�E�N���X�̓o�^ */
	memset(&wcex, 0, sizeof(wcex));
	wcex.cbSize = sizeof(wcex);
	wcex.style = CS_VREDRAW | CS_HREDRAW;
	wcex.lpfnWndProc = FDCProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hResInstance;
	wcex.hIcon = LoadIcon(hAppInstance, MAKEINTRESOURCE(IDI_WNDICON));
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = szClassName;
	wcex.hIconSm = LoadIcon(hAppInstance, MAKEINTRESOURCE(IDI_WNDICON));
	RegisterClassEx(&wcex);

	/* �E�C���h�E�쐬 */
#ifdef XM7DASH
	if (bPopupSwnd) {
		dwExStyle =	WS_POPUP | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
					| WS_MINIMIZEBOX | WS_BORDER;
	}
	else {
		dwExStyle = WS_CHILD | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
					| WS_MINIMIZEBOX | WS_CLIPSIBLINGS;
	}
	if (bSwndVisible) {
		dwExStyle |= WS_VISIBLE;
	}
	hWnd = CreateWindow(szClassName,
						szWndName,
						dwExStyle,
						rect.left,
						rect.top,
						rect.right,
						rect.bottom,
						hParent,
						NULL,
						hResInstance,
						NULL);
#else
	hWnd = CreateWindow(szClassName,
						szWndName,
						WS_CHILD | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
						| WS_VISIBLE | WS_MINIMIZEBOX | WS_CLIPSIBLINGS,
						rect.left,
						rect.top,
						rect.right,
						rect.bottom,
						hParent,
						NULL,
						hResInstance,
						NULL);
#endif

	/* �L���Ȃ�A�T�C�Y�␳���Ď�O�ɒu�� */
	if (hWnd) {
		GetWindowRect(hWnd, &wrect);
		GetClientRect(hWnd, &crect);
		wrect.right += (rect.right - crect.right);
		wrect.bottom += (rect.bottom - crect.bottom);
		SetWindowPos(hWnd, HWND_TOP, wrect.left, wrect.top,
			wrect.right - wrect.left, wrect.bottom - wrect.top, SWP_NOMOVE);
	}

	/* ���ʂ������A�� */
	return hWnd;
}

/*-[ �o�u���������R���g���[���E�C���h�E ]------------------------------------*/

#if XM7_VER == 1 && defined(BUBBLE)
/*
 *	�o�u���������R���g���[���E�C���h�E
 *	�Z�b�g�A�b�v(�R�}���h/���W�X�^)
 */
#ifdef XM7DASH
static void FASTCALL SetupBMCReg(BYTE *p, int x, int cx, int no)
#else
static void FASTCALL SetupBMCReg(BYTE *p, int x, int cx)
#endif
{
	char buffer[128];
	int y;

	ASSERT(p);
	ASSERT(cx > 0);

	/* ������ */
	y = 0;

#ifdef XM7DASH
	/* BMC */
	if (no) {
		strncpy(buffer, "128KB BMC", sizeof(buffer)-1);
	}
	else {
		strncpy(buffer, "32KB BMC", sizeof(buffer)-1);
	}
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;
#endif

#ifdef XM7DASH
	if (!no && (!bmc_enable[BMC_32] ||
				(fm_subtype != FMSUB_FM8 && opn_enable))) {
#else
	if (!bmc_enable || (fm_subtype != FMSUB_FM8)) {
#endif
		/* 32KB�o�u���J�Z�b�g���� */
		strncpy(buffer, "Disabled", 128);
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		return;
	}

#ifdef XM7DASH
	if (bmc_command[no] == 0xff) {
#else
	if (bmc_command == 0xff) {
#endif
		/* �R�}���h���� */
		strncpy(buffer, "NO COMMAND", 128);
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		return;
	}

#ifdef XM7DASH
	switch (bmc_command[no]) {
#else
	switch (bmc_command) {
#endif
		case 0x01:
			strncpy(buffer, "READ", 128);
			break;
		case 0x02:
			strncpy(buffer, "WRITE", 128);
			break;
		case 0x04:
		case 0x0f:
			strncpy(buffer, "INITIALIZE", 128);
			break;
		default:
			strncpy(buffer, "UNDEFINED", 128);
			break;
	}
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
#ifdef XM7DASH
	y++;
#else
	y+=2;
#endif

#ifdef XM7DASH
	_snprintf(buffer, 128,  "Data Reg.     %02X", bmc_datareg[no]);
#else
	_snprintf(buffer, 128,  "Data Reg.     %02X", bmc_datareg);
#endif
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

#ifdef XM7DASH
	_snprintf(buffer, 128,  "Unit          %2d", bmc_unit[no]);
#else
	_snprintf(buffer, 128,  "Unit          %2d", bmc_unit);
#endif
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

#ifdef XM7DASH
	_snprintf(buffer, 128,  "Page Reg.   %04X", bmc_pagereg[no]);
#else
	_snprintf(buffer, 128,  "Page Reg.   %04X", bmc_pagereg & 0xfbff);
#endif
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

#ifdef XM7DASH
	_snprintf(buffer, 128,  "Count Reg.  %04X", bmc_countreg[no]);
#else
	_snprintf(buffer, 128,  "Count Reg.  %04X", bmc_countreg);
#endif
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

#ifdef XM7DASH
	_snprintf(buffer, 128,  "Total Bytes %04X", bmc_totalcnt[no]);
#else
	_snprintf(buffer, 128,  "Total Bytes %04X", bmc_totalcnt);
#endif
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
	y++;

#ifdef XM7DASH
	_snprintf(buffer, 128,  "Xfer. Bytes %04X", bmc_nowcnt[no]);
#else
	_snprintf(buffer, 128,  "Xfer. Bytes %04X", bmc_nowcnt);
#endif
	memcpy(&p[x + y * cx], buffer, strlen(buffer));
}

/*
 *	�o�u���������R���g���[���E�C���h�E
 *	�Z�b�g�A�b�v(�X�e�[�^�X)
 */
#ifdef XM7DASH
static void FASTCALL SetupBMCStat(BYTE *p, int x, int cx, int no)
#else
static void FASTCALL SetupBMCStat(BYTE *p, int x, int cx)
#endif
{
	int y;
	int i;
#ifdef XM7DASH
	BYTE dat;
#endif
	BYTE bit;
	char buffer[128];

	ASSERT(p);
	ASSERT(cx > 0);

	/* ������ */
	y = 0;

	/* �����ݒ� */
#ifdef XM7DASH
	dat = bmc_status[no];
#endif
	bit = 0x80;

	/* �W�r�b�g���[�v */
	for (i=7; i>=0; i--) {
		_snprintf(buffer, 128,  "bit%d ", i);
#ifdef XM7DASH
		if (dat & bit) {
#else
		if (bmc_status & bit) {
#endif
			switch (i) {
				/* BUSY */
				case 0:
#ifdef XM7DASH
					strncat(buffer, "BUSY", 128 - strlen(buffer) - 1);
#else
					strncat(buffer, "BUSY", 128 - 4 - 1);
#endif
					break;
				/* ERROR ANALYSIS */
				case 1:
#ifdef XM7DASH
					strncat(buffer, "ERROR ANALYSIS", 128 - strlen(buffer) - 1);
#else
					strncat(buffer, "ERROR ANALYSIS", 128 - 14 - 1);
#endif
					break;
				/* WRITE PROTECT */
				case 2:
#ifdef XM7DASH
					strncat(buffer, "WRITE PROTECT", 128 - strlen(buffer) - 1);
#else
					strncat(buffer, "WRITE PROTECT", 128 - 13 - 1);
#endif
					break;
				/* ---------------- */
				case 3:
#ifdef XM7DASH
					strncat(buffer, "-----------------", 128 - strlen(buffer) - 1);
#else
					strncat(buffer, "-----------------", 128 - 16 - 1);
#endif
					break;
				/* DEVICE NOT READY */
				case 4:
#ifdef XM7DASH
					strncat(buffer, "DEVICE NOT READY", 128 - strlen(buffer) - 1);
#else
					strncat(buffer, "DEVICE NOT READY", 128 - 15 - 1);
#endif
					break;
				/* RDA */
				case 5:
#ifdef XM7DASH
					strncat(buffer, "RDA", 128 - strlen(buffer) - 1);
#else
					strncat(buffer, "RDA", 128 - 3 - 1);
#endif
					break;
				/* TDRA */
				case 6:
#ifdef XM7DASH
					strncat(buffer, "TDRA", 128 - strlen(buffer) - 1);
#else
					strncat(buffer, "TDRA", 128 - 4 - 1);
#endif
					break;
				/* CME */
				case 7:
#ifdef XM7DASH
					strncat(buffer, "CME", 128 - strlen(buffer) - 1);
#else
					strncat(buffer, "CME", 128 - 3 - 1);
#endif
					break;
			}
		}
		else {
#ifdef XM7DASH
			strncat(buffer, "-----------------", 128 - strlen(buffer) - 1);
#else
			strncat(buffer, "-----------------", 128 - 16 - 1);
#endif
		}
		bit >>= 1;
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		y++;
	}
}

/*
 *	�o�u���������R���g���[���E�C���h�E
 *	�Z�b�g�A�b�v(�G���[�X�e�[�^�X)
 */
#ifdef XM7DASH
static void FASTCALL SetupBMCErr(BYTE *p, int x, int cx, int no)
#else
static void FASTCALL SetupBMCErr(BYTE *p, int x, int cx)
#endif
{
	int y;
	int i;
#ifdef XM7DASH
	BYTE dat;
#endif
	BYTE bit;
	char buffer[128];

	ASSERT(p);
	ASSERT(cx > 0);

	/* ������ */
	y = 0;

	/* �����ݒ� */
#ifdef XM7DASH
	dat = bmc_errorreg[no];
#endif
	bit = 0x80;

	/* �W�r�b�g���[�v */
	for (i=7; i>=0; i--) {
		memset(buffer, 0, sizeof(buffer));
#ifdef XM7DASH
		if (dat & bit) {
#else
		if (bmc_errorreg & bit) {
#endif
			switch (i) {
				/* UNDEFINED COMMAND ERROR */
				case 0:
					strncpy(buffer, "UNDEFINED CMD ERR", 128);
					break;
				/* NO MARKER */
				case 1:
					strncpy(buffer, "NO MARKER", 128);
					break;
				/* MANY BAD LOOP */
				case 2:
					strncpy(buffer, "MANY BAD LOOP", 128);
					break;
				/* TRANSFER MISSING */
				case 3:
					strncpy(buffer, "TRANSFER MISSING", 128);
					break;
				/* CRC ERROR */
				case 4:
					strncpy(buffer, "CRC ERROR", 128);
					break;
				/* PAGE ADDRESS ERROR */
				case 5:
					strncpy(buffer, "PAGE ADDRESS ERR.", 128);
					break;
				/* DEVICE NOT READY */
				case 6:
				case 7:
					strncpy(buffer, "EJECT ERROR", 128);
					break;
			}
		}
		else {
			strncpy(buffer, "-----------------", 128);
		}
		bit >>= 1;
		memcpy(&p[x + y * cx], buffer, strlen(buffer));
		y++;
	}
}

/*
 *	�o�u���������R���g���[���E�C���h�E
 *	�Z�b�g�A�b�v
 */
static void FASTCALL SetupBMC(BYTE *p, int x, int y)
{
	ASSERT(p);
	ASSERT(x > 0);
	ASSERT(y > 0);

	/* ��U�X�y�[�X�Ŗ��߂� */
	memset(p, 0x20, x * y);

	/* �T�u�֐����Ă� */
#ifdef XM7DASH
	SetupBMCReg( p,  0, x, BMC_32);
	SetupBMCStat(p, 17, x, BMC_32);
	SetupBMCErr( p, 40, x, BMC_32);

	if (nBMC == 1) {
		memset(&p[8 * x], '-', x);
		SetupBMCReg( p, 9 * x +  0, x, BMC_128);
		SetupBMCStat(p, 9 * x + 17, x, BMC_128);
		SetupBMCErr( p, 9 * x + 40, x, BMC_128);
	}
#else
	SetupBMCReg( p,  0, x);
	SetupBMCStat(p, 17, x);
	SetupBMCErr( p, 40, x);
#endif
}

/*
 *	�o�u���������R���g���[���E�C���h�E
 *	�`��
 */
static void FASTCALL DrawBMC(HWND hWnd, HDC hDC)
{
	RECT rect;
	int x, y;

	ASSERT(hWnd);
	ASSERT(hDC);

	/* �E�C���h�E�W�I���g���𓾂� */
	GetClientRect(hWnd, &rect);
	x = rect.right / lCharWidth;
	y = rect.bottom / lCharHeight;
	if ((x == 0) || (y == 0)) {
		return;
	}

	/* �Z�b�g�A�b�v */
	if (!pBMC) {
		return;
	}
	SetupBMC(pBMC, x, y);

	/* �`�� */
	DrawWindowText(hDC, pBMC, x, y);
}

/*
 *	�o�u���������R���g���[���E�C���h�E
 *	���t���b�V��
 */
void FASTCALL RefreshBMC(void)
{
	HWND hWnd;
	HDC hDC;

	/* ��ɌĂ΂��̂ŁA���݃`�F�b�N���邱�� */
	if (hSubWnd[SWND_BMC] == NULL) {
		return;
	}

	/* �`�� */
	hWnd = hSubWnd[SWND_BMC];
	hDC = GetDC(hWnd);
	DrawBMC(hWnd, hDC);
	ReleaseDC(hWnd, hDC);
}

#ifdef XM7DASH
/*
 *	�o�u���������R���g���[���E�C���h�E
 *	�T�C�Y�ύX
 */
void FASTCALL ReSizeBMC(void)
{
	HWND hWnd;
	UINT uMode;
	RECT wrect;
	RECT crect;
	int cx;
	int cy;

	/* ��ɌĂ΂��̂ŁA���݃`�F�b�N���邱�� */
	if (hSubWnd[SWND_BMC] == NULL) {
		return;
	}

	/* �ŏ����Ȃ�A�������Ȃ� */
	hWnd = hSubWnd[SWND_BMC];
	if (IsIconic(hWnd)) {
		return;
	}

	/* �W�I���g���ύX�`�F�b�N */
	uMode = 0;
	cx = 57;
	cy = 8;
	if (bmc_command[BMC_128] != 0xff) {
		uMode = 1;
		cy = 17;
	}

	if (uMode == nBMC) {
		return;
	}

	/* ���b�N */
	LockVM();

	/* ���[�h�`�F���W */
	nBMC = uMode;

	/* �o�b�t�@��� */
	free(pBMC);
	pBMC = malloc(2 * cx * cy);
	memset(pBMC, 0xff, 2 * cx * cy);
	ASSERT(pBMC);

	/* �E�B���h�E��`�ύX */
	GetWindowRect(hWnd, &wrect);
	GetClientRect(hWnd, &crect);
	wrect.right -= wrect.left;
	wrect.right -= crect.right;
	wrect.right += cx * lCharWidth;
	wrect.bottom -= wrect.top;
	wrect.bottom -= crect.bottom;
	wrect.bottom += cy * lCharHeight;
	SetWindowPos(hWnd, HWND_TOP, 0, 0, wrect.right, wrect.bottom,
							SWP_NOZORDER | SWP_NOMOVE);
#ifdef XM7DASH
	if (bPopupSwnd) {
		SetForegroundWindow(hMainWnd);
	}
#endif

	/* �A�����b�N */
	UnlockVM();
}
#endif

/*
 *	�o�u���������R���g���[���E�C���h�E
 *	�ĕ`��
 */
static void FASTCALL PaintBMC(HWND hWnd)
{
	HDC hDC;
	PAINTSTRUCT ps;
	RECT rect;
	BYTE *p;
	int x, y;

	ASSERT(hWnd);

	/* �|�C���^��ݒ�(���݂��Ȃ���Ή������Ȃ�) */
	p = pBMC;
	if (!p) {
		return;
	}

	/* �E�C���h�E�W�I���g���𓾂� */
	GetClientRect(hWnd, &rect);
	x = rect.right / lCharWidth;
	y = rect.bottom / lCharHeight;

	/* �㔼�G���A��FF�Ŗ��߂� */
	if ((x > 0) && (y > 0)) {
		memset(&p[x * y], 0xff, x * y);
	}

	/* �`�� */
	hDC = BeginPaint(hWnd, &ps);
	ASSERT(hDC);
	DrawBMC(hWnd, hDC);
	EndPaint(hWnd, &ps);
}

/*
 *	�o�u���������R���g���[���E�C���h�E
 *	�E�C���h�E�v���V�[�W��
 */
static LRESULT CALLBACK BMCProc(HWND hWnd, UINT message,
								 WPARAM wParam, LPARAM lParam)
{
	/* ���b�Z�[�W�� */
	switch (message) {
		/* �E�C���h�E�ĕ`�� */
		case WM_PAINT:
			/* ���b�N���K�v */
			LockVM();
			PaintBMC(hWnd);
			UnlockVM();
			return 0;

		/* �E�C���h�E�폜 */
		case WM_DESTROY:
			LockVM();

			/* ���C���E�C���h�E�֎����ʒm */
			DestroySubWindow(hWnd, &pBMC, NULL);

			UnlockVM();
			break;

#ifdef XM7DASH
		/* �E�B���h�E�ړ� */
		case WM_MOVE:
			/* �ŏ������̃T�u�E�B���h�E���Ҕ� */
			MoveSubWindow(hWnd);
			break;
#endif
	}

	/* �f�t�H���g �E�C���h�E�v���V�[�W�� */
	return DefWindowProc(hWnd, message, wParam, lParam);
}

/*
 *	�o�u���������R���g���[���E�C���h�E
 *	�E�C���h�E�쐬
 */
HWND FASTCALL CreateBMC(HWND hParent, int index)
{
	WNDCLASSEX wcex;
	char szClassName[] = "XM7_BMC";
	char szWndName[128];
	RECT rect;
	RECT crect, wrect;
	HWND hWnd;
#ifdef XM7DASH
	DWORD dwExStyle;
#endif

	ASSERT(hParent);

	/* �E�C���h�E��`���v�Z */
#ifdef XM7DASH
	PositioningSubWindow(hParent, &rect, index);
#else
	rect.left = lCharWidth * index;
	rect.top = lCharHeight * index;
	if (rect.top >= 380) {
		rect.top -= 380;
	}
#endif
	rect.right = lCharWidth * 57;
	rect.bottom = lCharHeight * 8;

	/* �E�C���h�E�^�C�g��������A�o�b�t�@�m�� */
	LoadString(hResInstance, IDS_SWND_BMC,
				szWndName, sizeof(szWndName));
	pBMC = malloc(2 * (rect.right / lCharWidth) *
								(rect.bottom / lCharHeight));
#ifdef XM7DASH
	nBMC = 0;
#endif

	/* �E�C���h�E�N���X�̓o�^ */
	memset(&wcex, 0, sizeof(wcex));
	wcex.cbSize = sizeof(wcex);
	wcex.style = CS_VREDRAW | CS_HREDRAW;
	wcex.lpfnWndProc = BMCProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hResInstance;
	wcex.hIcon = LoadIcon(hAppInstance, MAKEINTRESOURCE(IDI_WNDICON));
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = szClassName;
	wcex.hIconSm = LoadIcon(hAppInstance, MAKEINTRESOURCE(IDI_WNDICON));
	RegisterClassEx(&wcex);

	/* �E�C���h�E�쐬 */
#ifdef XM7DASH
	if (bPopupSwnd) {
		dwExStyle =	WS_POPUP | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
					| WS_MINIMIZEBOX | WS_BORDER;
	}
	else {
		dwExStyle = WS_CHILD | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
					| WS_MINIMIZEBOX | WS_CLIPSIBLINGS;
	}
	if (bSwndVisible) {
		dwExStyle |= WS_VISIBLE;
	}
	hWnd = CreateWindow(szClassName,
						szWndName,
						dwExStyle,
						rect.left,
						rect.top,
						rect.right,
						rect.bottom,
						hParent,
						NULL,
						hResInstance,
						NULL);
#else
	hWnd = CreateWindow(szClassName,
						szWndName,
						WS_CHILD | WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION
						| WS_VISIBLE | WS_MINIMIZEBOX | WS_CLIPSIBLINGS,
						rect.left,
						rect.top,
						rect.right,
						rect.bottom,
						hParent,
						NULL,
						hResInstance,
						NULL);
#endif

	/* �L���Ȃ�A�T�C�Y�␳���Ď�O�ɒu�� */
	if (hWnd) {
		GetWindowRect(hWnd, &wrect);
		GetClientRect(hWnd, &crect);
		wrect.right += (rect.right - crect.right);
		wrect.bottom += (rect.bottom - crect.bottom);
		SetWindowPos(hWnd, HWND_TOP, wrect.left, wrect.top,
			wrect.right - wrect.left, wrect.bottom - wrect.top, SWP_NOMOVE);
	}

	/* ���ʂ������A�� */
	return hWnd;
}
#endif

#endif	/* _WIN32 */
