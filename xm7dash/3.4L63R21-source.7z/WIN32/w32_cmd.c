/*
 *	FM-7 EMULATOR "XM7"
 *
 *	Copyright (C) 1999-2014 �o�h�D(yasushi@tanaka.net)
 *	Copyright (C) 2001-2014 Ryu Takegami
 *	Copyright (C) 2010-2015 Toma
 *	line printer support 2010-2013 by Ben.JP
 *
 *	[ Win32API ���j���[�R�}���h ]
 */

#ifdef _WIN32

#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#ifdef XM7DASH
#include <commctrl.h>
#endif
#include <commdlg.h>
#include <shellapi.h>
#include <stdlib.h>
#include <assert.h>
#include <tchar.h>
#define DIRECTINPUT_VERSION		0x0300		/* DirectX3���w�� */
#include <dinput.h>
#include <direct.h>
#include "xm7.h"
#ifdef XM7DASH
#include "device.h"
#endif
#include "fdc.h"
#include "tapelp.h"
#include "tools.h"
#include "mouse.h"
#include "rtc.h"
#include "display.h"
#include "subctrl.h"
#include "jsubsys.h"
#include "bubble.h"
#if XM7_VER == 1 && defined(BUBBLE) && defined(XM7DASH)
#include "opn.h"
#endif	/* XM7_VER == 1 && defined(BUBBLE) && defined(XM7DASH) */
#if XM7_VER == 1 && defined(XM7DASH)
#include "mainetc.h"
#endif	/* XM7_VER == 1 && defined(XM7DASH) */
#include "w32.h"
#include "w32_bar.h"
#include "w32_draw.h"
#include "w32_snd.h"
#include "w32_sch.h"
#include "w32_sub.h"
#include "w32_cfg.h"
#include "w32_res.h"
#include "w32_kbd.h"
#include "w32_comm.h"

/*
 *	�O���[�o�� ���[�N
 */
#ifdef XM7DASH
char InitialDir[INITIAL_DIRS][_MAX_DRIVE + _MAX_PATH];
char StatePath[_MAX_PATH];
char QuickPath[_MAX_PATH];
BOOL bResumeState;
BOOL bBackupState;
#ifdef RSTATE
BOOL bStateSave;
#endif
#elif XM7_VER == 1 && defined(BUBBLE)
char InitialDir[6][_MAX_DRIVE + _MAX_PATH];
#else
char InitialDir[5][_MAX_DRIVE + _MAX_PATH];
#endif

/*
 *	�X�^�e�B�b�N ���[�N
 */
#ifndef XM7DASH
static char StatePath[_MAX_PATH];
#endif
static char DiskTitle[16 + 1];
static BOOL DiskMedia;
static BOOL DiskFormat;
#if XM7_VER == 1 && defined(BUBBLE)
static char BubbleTitle[16 + 1];
#ifdef XM7DASH
static BOOL BubbleMedia;
#endif
static BOOL BubbleFormat;
#endif
#ifdef XM7DASH
static double dRatio;
static WORD wMenuID = 0;
#endif

/*
 *	�v���g�^�C�v�錾
 */
static void FASTCALL OnRefresh(HWND hWnd);
extern int _getdrive(void);

/*
 *	�u�[�g�\�t���O�}�N��
 */
#define availableSFDBOOT	(((fm_subtype == FMSUB_FM8) && available_sfdboot8) || \
							 ((fm_subtype == FMSUB_FM77) && available_1mbboot))
#define availableBBLBOOT	(((fm_subtype == FMSUB_FM8) && available_bblboot8) || \
							 ((fm_subtype == FMSUB_FM77) && available_bblboot))

/*-[ �^�C�g�����̓_�C�A���O ]------------------------------------------------*/

/*
 *	�^�C�g�����̓_�C�A���O
 *	�_�C�A���O������
 */
static BOOL FASTCALL TitleDlgInit(HWND hDlg)
{
	HWND hWnd;
	RECT prect;
	RECT drect;

	ASSERT(hDlg);

	/* �e�E�C���h�E�̒����ɐݒ� */
	hWnd = GetParent(hDlg);
	GetWindowRect(hWnd, &prect);
	GetWindowRect(hDlg, &drect);
	drect.right -= drect.left;
	drect.bottom -= drect.top;
	drect.left = (prect.right - prect.left) / 2 + prect.left;
	drect.left -= (drect.right / 2);
	drect.top = (prect.bottom - prect.top) / 2 + prect.top;
	drect.top -= (drect.bottom / 2);
	MoveWindow(hDlg, drect.left, drect.top, drect.right, drect.bottom, FALSE);

	/* �G�f�B�b�g�e�L�X�g���� */
	hWnd = GetDlgItem(hDlg, IDC_TITLEEDIT);
	ASSERT(hWnd);
#ifndef XM7DASH
	strncpy(DiskTitle, "Default", sizeof(DiskTitle));
#endif
	SetWindowText(hWnd, DiskTitle);

#if XM7_VER >= 3
	/* ���f�B�A�^�C�v */
	CheckDlgButton(hDlg, IDC_TITLE2D, BST_CHECKED);
#elif XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	/* ���f�B�A�^�C�v */
	CheckDlgButton(hDlg, IDC_TITLE2D, BST_CHECKED);
#endif

	return TRUE;
}

/*
 *	�^�C�g�����̓_�C�A���O
 *	�_�C�A���OOK
 */
static void FASTCALL TitleDlgOK(HWND hDlg)
{
	HWND hWnd;
	char string[128];

	ASSERT(hDlg);

	/* �G�f�B�b�g�e�L�X�g���� */
	hWnd = GetDlgItem(hDlg, IDC_TITLEEDIT);
	ASSERT(hWnd);

	/* ��������擾�A�R�s�[ */
	GetWindowText(hWnd, string, sizeof(string) - 1);
	memset(DiskTitle, 0, sizeof(DiskTitle));
	string[16] = '\0';
	strncpy(DiskTitle, string, sizeof(DiskTitle));

	/* ���f�B�A�^�C�v�擾 */
#if XM7_VER >= 3
	if (IsDlgButtonChecked(hDlg, IDC_TITLE2DD)) {
		DiskMedia = TRUE;
	}
	else {
		DiskMedia = FALSE;
	}
#elif XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	if (IsDlgButtonChecked(hDlg, IDC_TITLE2HD)) {
		DiskMedia = TRUE;
	}
	else {
		DiskMedia = FALSE;
	}
#else
	/* V2�ł�2D�̂� */
	DiskMedia = FALSE;
#endif

	if (IsDlgButtonChecked(hDlg, IDC_TITLEUSRDISK)) {
		DiskFormat = TRUE;
	}
	else {
		DiskFormat = FALSE;
	}
}

/*
 *	�^�C�g�����̓_�C�A���O
 *	�_�C�A���O�v���V�[�W��
 */
static BOOL CALLBACK TitleDlgProc(HWND hDlg, UINT iMsg,
									WPARAM wParam, LPARAM lParam)
{
	UNUSED(lParam);

	switch (iMsg) {
		/* �_�C�A���O������ */
		case WM_INITDIALOG:
			return TitleDlgInit(hDlg);

		/* �R�}���h���� */
		case WM_COMMAND:
			switch (LOWORD(wParam)) {
				/* OK�E�L�����Z�� */
				case IDOK:
				case IDCANCEL:
					if (LOWORD(wParam) == IDOK) {
						TitleDlgOK(hDlg);
					}
					EndDialog(hDlg, LOWORD(wParam));
					InvalidateRect(hDrawWnd, NULL, FALSE);
					SetMenuExitTimer();
					return TRUE;
			}
			break;
	}

	/* ����ȊO�́AFALSE */
	return FALSE;
}

/*-[ �^�C�g�����̓_�C�A���O(2D/VFD�ϊ��p) ]----------------------------------*/

/*
 *	�^�C�g�����̓_�C�A���O(2D/VFD�ϊ��p)
 *	�_�C�A���O������
 */
static BOOL FASTCALL TitleDlg2DInit(HWND hDlg)
{
	HWND hWnd;
	RECT prect;
	RECT drect;

	ASSERT(hDlg);

	/* �e�E�C���h�E�̒����ɐݒ� */
	hWnd = GetParent(hDlg);
	GetWindowRect(hWnd, &prect);
	GetWindowRect(hDlg, &drect);
	drect.right -= drect.left;
	drect.bottom -= drect.top;
	drect.left = (prect.right - prect.left) / 2 + prect.left;
	drect.left -= (drect.right / 2);
	drect.top = (prect.bottom - prect.top) / 2 + prect.top;
	drect.top -= (drect.bottom / 2);
	MoveWindow(hDlg, drect.left, drect.top, drect.right, drect.bottom, FALSE);

	/* �G�f�B�b�g�e�L�X�g���� */
	hWnd = GetDlgItem(hDlg, IDC_TITLEEDIT2D);
	ASSERT(hWnd);
#ifndef XM7DASH
	strncpy(DiskTitle, "Default", sizeof(DiskTitle));
#endif
	SetWindowText(hWnd, DiskTitle);

	return TRUE;
}

/*
 *	�^�C�g�����̓_�C�A���O(2D/VFD�ϊ��p)
 *	�_�C�A���OOK
 */
static void FASTCALL TitleDlg2DOK(HWND hDlg)
{
	HWND hWnd;
	char string[128];

	ASSERT(hDlg);

	/* �G�f�B�b�g�e�L�X�g���� */
	hWnd = GetDlgItem(hDlg, IDC_TITLEEDIT2D);
	ASSERT(hWnd);

	/* ��������擾�A�R�s�[ */
	GetWindowText(hWnd, string, sizeof(string) - 1);
	memset(DiskTitle, 0, sizeof(DiskTitle));
	string[16] = '\0';
	strncpy(DiskTitle, string, sizeof(DiskTitle));
}

/*
 *	�^�C�g�����̓_�C�A���O(2D/VFD�ϊ��p)
 *	�_�C�A���O�v���V�[�W��
 */
static BOOL CALLBACK TitleDlg2DProc(HWND hDlg, UINT iMsg,
									WPARAM wParam, LPARAM lParam)
{
	UNUSED(lParam);

	switch (iMsg) {
		/* �_�C�A���O������ */
		case WM_INITDIALOG:
			return TitleDlg2DInit(hDlg);

		/* �R�}���h���� */
		case WM_COMMAND:
			switch (LOWORD(wParam)) {
				/* OK�E�L�����Z�� */
				case IDOK:
				case IDCANCEL:
					if (LOWORD(wParam) == IDOK) {
						TitleDlg2DOK(hDlg);
					}
					EndDialog(hDlg, LOWORD(wParam));
					InvalidateRect(hDrawWnd, NULL, FALSE);
					SetMenuExitTimer();
					return TRUE;
			}
			break;
	}

	/* ����ȊO�́AFALSE */
	return FALSE;
}

/*-[ �o�u�����f�B�A�^�C�v�I���_�C�A���O ]------------------------------------*/

#if XM7_VER == 1 && defined(BUBBLE)
/*
 *	�o�u�����f�B�A�^�C�v�I���_�C�A���O
 *	�_�C�A���O������
 */
static BOOL FASTCALL BubbleMediaTypeDlgInit(HWND hDlg)
{
	HWND hWnd;
	RECT prect;
	RECT drect;

	ASSERT(hDlg);

	/* �e�E�C���h�E�̒����ɐݒ� */
	hWnd = GetParent(hDlg);
	GetWindowRect(hWnd, &prect);
	GetWindowRect(hDlg, &drect);
	drect.right -= drect.left;
	drect.bottom -= drect.top;
	drect.left = (prect.right - prect.left) / 2 + prect.left;
	drect.left -= (drect.right / 2);
	drect.top = (prect.bottom - prect.top) / 2 + prect.top;
	drect.top -= (drect.bottom / 2);
	MoveWindow(hDlg, drect.left, drect.top, drect.right, drect.bottom, FALSE);

	/* �G�f�B�b�g�e�L�X�g���� */
	hWnd = GetDlgItem(hDlg, IDC_TITLEEDIT);
	ASSERT(hWnd);
	SetWindowText(hWnd, BubbleTitle);

#ifdef XM7DASH
	/* ���f�B�A�^�C�v */
	CheckDlgButton(hDlg, IDC_MEDIATYPE32KB, BST_CHECKED);
#endif

	/* �t�H�[�}�b�g�^�C�v */
	CheckDlgButton(hDlg, IDC_MEDIAFORMATB77, BST_CHECKED);

	return TRUE;
}

/*
 *	�o�u�����f�B�A�^�C�v�I���_�C�A���O
 *	�_�C�A���OOK
 */
static void FASTCALL BubbleMediaTypeDlgOK(HWND hDlg)
{
	ASSERT(hDlg);

	if (IsDlgButtonChecked(hDlg, IDC_MEDIAFORMATBBL)) {
		BubbleFormat = FALSE;
	}
	else {
		BubbleFormat = TRUE;
	}

#ifdef XM7DASH
	/* ���f�B�A�^�C�v�擾 */
	if (IsDlgButtonChecked(hDlg, IDC_MEDIATYPE128KB)) {
		BubbleMedia = TRUE;
	}
	else {
		BubbleMedia = FALSE;
	}
#endif
}

/*
 *	�o�u�����f�B�A�^�C�v�I���_�C�A���O
 *	�_�C�A���O�v���V�[�W��
 */
static BOOL CALLBACK BubbleMediaTypeDlgProc(HWND hDlg, UINT iMsg,
									WPARAM wParam, LPARAM lParam)
{
	UNUSED(lParam);

	switch (iMsg) {
		/* �_�C�A���O������ */
		case WM_INITDIALOG:
			return BubbleMediaTypeDlgInit(hDlg);

		/* �R�}���h���� */
		case WM_COMMAND:
			switch (LOWORD(wParam)) {
				/* OK�E�L�����Z�� */
				case IDOK:
				case IDCANCEL:
					if (LOWORD(wParam) == IDOK) {
						BubbleMediaTypeDlgOK(hDlg);
					}
					EndDialog(hDlg, LOWORD(wParam));
					InvalidateRect(hDrawWnd, NULL, FALSE);
					SetMenuExitTimer();
					return TRUE;
				case IDC_MEDIAFORMATB77:
					EnableWindow(GetDlgItem(hDlg, IDC_TITLEEDIT), TRUE);
					return TRUE;
				case IDC_MEDIAFORMATBBL:
					EnableWindow(GetDlgItem(hDlg, IDC_TITLEEDIT), FALSE);
					return TRUE;
			}
			break;
	}

	/* ����ȊO�́AFALSE */
	return FALSE;
}
#endif	/* XM7_VER == 1 && defined(BUBBLE) */

/*-[ �t�@�C���I���R�����_�C�A���O ]-----------------------------------------*/

/*
 *	�t�@�C���I���R�����_�C�A���O
 *	������
 */
static void FASTCALL FileDialogInit(HWND hDlg)
{
	RECT drect;
	RECT prect;
	HWND hWnd;

	/* �_�C�A���O�����C���E�C���h�E�̒����Ɋ񂹂� */
	hWnd = GetParent(hDlg);
	GetWindowRect(hMainWnd, &prect);
	GetWindowRect(hWnd, &drect);
	drect.right -= drect.left;
	drect.bottom -= drect.top;
	drect.left = (prect.right - prect.left) / 2 + prect.left;
	drect.left -= (drect.right / 2);
	drect.top = (prect.bottom - prect.top) / 2 + prect.top;
	drect.top -= (drect.bottom / 2);
	MoveWindow(hWnd, drect.left, drect.top, drect.right, drect.bottom, FALSE);
}

/*
 *	�t�@�C���I���R�����_�C�A���O
 *	HOOK�֐�
 */
static UINT CALLBACK FileSelectHook(
						HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	UNUSED(wParam);
	UNUSED(lParam);

	switch (uMsg) {
		case WM_INITDIALOG:
			FileDialogInit(hDlg);
			return 0;
	}

	return 0;
}

/*
 *	�t�@�C���I���R�����_�C�A���O
 */
#ifdef XM7DASH
BOOL FASTCALL FileSelectSub(BOOL bOpen, UINT uFilterID, char *path, char *defext, BYTE IniDirNo)
#else
static BOOL FASTCALL FileSelectSub(BOOL bOpen, UINT uFilterID, char *path, char *defext, BYTE IniDirNo)
#endif
{
	OPENFILENAME ofn;
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME + _MAX_EXT];
	char filter[4096];
	int i, j;

	ASSERT((bOpen == TRUE) || (bOpen == FALSE));
	ASSERT(uFilterID > 0);
	ASSERT(path);

	/* �f�[�^�쐬 */
	memset(&ofn, 0, sizeof(ofn));
	memset(path, 0, _MAX_PATH);
	memset(fname, 0, sizeof(fname));
	ofn.lStructSize = 76;	/* sizeof(ofn)��V5�g�����܂� */
	ofn.hwndOwner = hMainWnd;

	LoadString(hResInstance, uFilterID, filter, sizeof(filter));
	j = strlen(filter);
	for (i=0; i<j; i++) {
		if (filter[i] == '|') {
			filter[i] = '\0';
		}
	}

	ofn.lpstrFilter = filter;
	ofn.lpstrFile = path;
	ofn.nMaxFile = _MAX_PATH;
	ofn.lpstrFileTitle = fname;
	ofn.nMaxFileTitle = sizeof(fname);
	ofn.lpstrDefExt = defext;
	ofn.lpstrInitialDir = InitialDir[IniDirNo];
	ofn.lpfnHook = FileSelectHook;

	/* �R�����_�C�A���O���s */
	if (bOpen) {
		ofn.Flags = OFN_EXPLORER | OFN_HIDEREADONLY |
					OFN_FILEMUSTEXIST | OFN_ENABLEHOOK;
		if (!GetOpenFileName(&ofn)) {
			SetMenuExitTimer();
			return FALSE;
		}
	}
	else {
		ofn.Flags = OFN_EXPLORER | OFN_HIDEREADONLY |
					OFN_OVERWRITEPROMPT | OFN_ENABLEHOOK;
		if (!GetSaveFileName(&ofn)) {
			SetMenuExitTimer();
			return FALSE;
		}
	}

	/* �f�B���N�g����ۑ� */
	_splitpath(path, InitialDir[IniDirNo], dir, NULL, NULL);
	if (dir[strlen(dir)-1] == '\\') {
		/* �Ō�̃p�X��؂�L���͋����I�ɍ�� */
		dir[strlen(dir)-1] = '\0';
	}
#ifdef XM7DASH
	strncat(InitialDir[IniDirNo], dir,
			sizeof(InitialDir[IniDirNo]) - strlen(InitialDir[IniDirNo]) - 1);
#else
	strncat(InitialDir[IniDirNo], dir,
			strlen(dir) - _MAX_DRIVE + _MAX_PATH - 1);
#endif

	SetMenuExitTimer();
	return TRUE;
}

#ifdef XM7DASH
/*-[ �A�X�y�N�g��ݒ�_�C�A���O ]-------------------------------------------*/

/*
 *	�A�X�y�N�g��ݒ�_�C�A���O
 *	�����X�N���[��
 */
static BOOL FASTCALL AspectRatioDlgVScroll(HWND hDlg, WORD wPos, HWND hWnd)
{
	char string[128];
	HWND hSubWnd;

	UNUSED(wPos);

	/* �E�B���h�E�n���h�����`�F�b�N */
	if (hWnd == GetDlgItem(hDlg, IDC_ASPECTSPIN)) {
		/* �A�X�y�N�g�� */
		/* �|�W�V��������A�o�f�B�E�C���h�E�ɒl��ݒ� */
		hSubWnd = GetDlgItem(hDlg, IDC_ASPECTEDIT);
		ASSERT(hSubWnd);
		_snprintf(string, sizeof(string), "%.3f", dRatio);
		SetWindowText(hSubWnd, string);
		return TRUE;
	}
	return FALSE;
}

/*
 *	�A�X�y�N�g��ݒ�_�C�A���O
 *	�_�C�A���O������
 */
static BOOL FASTCALL AspectRatioDlgInit(HWND hDlg)
{
	HWND hWnd;
	RECT prect;
	RECT drect;
	char string[128];

	ASSERT(hDlg);

	/* �e�E�C���h�E�̒����ɐݒ� */
	hWnd = GetParent(hDlg);
	GetWindowRect(hWnd, &prect);
	GetWindowRect(hDlg, &drect);
	drect.right -= drect.left;
	drect.bottom -= drect.top;
	drect.left = (prect.right - prect.left) / 2 + prect.left;
	drect.left -= (drect.right / 2);
	drect.top = (prect.bottom - prect.top) / 2 + prect.top;
	drect.top -= (drect.bottom / 2);
	MoveWindow(hDlg, drect.left, drect.top, drect.right, drect.bottom, FALSE);

	/* �G�f�B�b�g�e�L�X�g���� */
	memset(string, 0, sizeof(string));
	hWnd = GetDlgItem(hDlg, IDC_ASPECTEDIT);
	ASSERT(hWnd);
	_snprintf(string, sizeof(string), "%.3f", dRatio);
	SetWindowText(hWnd, string);

	return TRUE;
}

/*
 *	�A�X�y�N�g��ݒ�_�C�A���O
 *	�_�C�A���OOK
 */
static void FASTCALL AspectRatioDlgOK(HWND hDlg)
{
	HWND hWnd;
	char string[128];

	ASSERT(hDlg);

	/* �G�f�B�b�g�e�L�X�g���� */
	hWnd = GetDlgItem(hDlg, IDC_ASPECTEDIT);
	ASSERT(hWnd);

	/* ��������擾�A�R�s�[ */
	memset(string, 0, sizeof(string));
	GetWindowText(hWnd, string, sizeof(string) - 1);
	dRatio = atof(string);
}

/*
 *	�A�X�y�N�g��ݒ�_�C�A���O
 *	�_�C�A���O�v���V�[�W��
 */
static BOOL CALLBACK AspectRatioDlgProc(HWND hDlg, UINT iMsg,
									WPARAM wParam, LPARAM lParam)
{
	char string[128];
	LPNMUPDOWN lpnmud;
	HWND hWnd;

	switch (iMsg) {
		/* �_�C�A���O������ */
		case WM_INITDIALOG:
			return AspectRatioDlgInit(hDlg);

		/* �R�}���h���� */
		case WM_COMMAND:
			switch (LOWORD(wParam)) {
				/* OK�E�L�����Z�� */
				case IDOK:
				case IDCANCEL:
					if (LOWORD(wParam) == IDOK) {
						AspectRatioDlgOK(hDlg);
					}
					EndDialog(hDlg, LOWORD(wParam));
					InvalidateRect(hDrawWnd, NULL, FALSE);
					SetMenuExitTimer();
					return TRUE;
			}
			break;

		/* �ʒm */
		case WM_NOTIFY:
			if (wParam == (WPARAM)IDC_ASPECTSPIN) {
				lpnmud = (LPNMUPDOWN)lParam;
				if (lpnmud->hdr.code == UDN_DELTAPOS) {
					/* �G�f�B�b�g�e�L�X�g���� */
					hWnd = GetDlgItem(hDlg, IDC_ASPECTEDIT);
					ASSERT(hWnd);
					GetWindowText(hWnd, string, (int)sizeof(string));
					dRatio = (double)atof(string) - (double)lpnmud->iDelta / (double)1000.0;
					if (dRatio < 0.5) {
						dRatio = 0.5;
					}
					else if (dRatio > 2.0) {
						dRatio = 2.0;
					}
				}
				return TRUE;
			}
			break;

		/* �����X�N���[�� */
		case WM_VSCROLL:
			return AspectRatioDlgVScroll(hDlg, HIWORD(wParam), (HWND)lParam);
	}

	/* ����ȊO�́AFALSE */
	return FALSE;
}
#endif

/*-[ �ėp�T�u ]-------------------------------------------------------------*/

/*
 *	���j���[Enable
 */
void FASTCALL EnableMenuSub(HMENU hMenu, UINT uID, BOOL bEnable)
{
	ASSERT(hMenu);
	ASSERT(uID > 0);

	if (bEnable) {
		EnableMenuItem(hMenu, uID, MF_BYCOMMAND | MF_ENABLED);
	}
	else {
		EnableMenuItem(hMenu, uID, MF_BYCOMMAND | MF_GRAYED);
	}
}

/*
 *	���j���[Enable (�ʒu�w��)
 */
#if (XM7_VER == 1 && defined(BUBBLE)) || defined(XM7DASH)
void FASTCALL EnableMenuPos(HMENU hMenu, UINT uPos, BOOL bEnable)
{
	ASSERT(hMenu);
	ASSERT(uPos > 0);

	if (bEnable) {
		EnableMenuItem(hMenu, uPos, MF_BYPOSITION | MF_ENABLED);
	}
	else {
		EnableMenuItem(hMenu, uPos, MF_BYPOSITION | MF_GRAYED);
	}
}
#endif

/*
 *	���j���[Check
 */
void FASTCALL CheckMenuSub(HMENU hMenu, UINT uID, BOOL bCheck)
{
	ASSERT(hMenu);
	ASSERT(uID > 0);

	if (bCheck) {
		CheckMenuItem(hMenu, uID, MF_BYCOMMAND | MF_CHECKED);
	}
	else {
		CheckMenuItem(hMenu, uID, MF_BYCOMMAND | MF_UNCHECKED);
	}
}

/*-[ �t�@�C�����j���[ ]-----------------------------------------------------*/

/*
 *	�X�e�[�g���[�h����
 */
static void FASTCALL StateLoad(char *path)
{
	char string[256];
	int state;

	state = system_load(path);
	if (state == STATELOAD_ERROR) {
		/* �{�̓ǂݍ��ݒ��̃G���[�������̂݃��Z�b�g */
		system_reset();
#ifdef XM7DASH
		StatePath[0] = '\0';
		SetAllMRUFile();
#endif
	}
	if (state != STATELOAD_SUCCESS) {
		LoadString(hResInstance, IDS_STATEERROR, string, sizeof(string));
		MessageBox(hMainWnd, string, "XM7", MB_ICONSTOP | MB_OK);
		SetMenuExitTimer();
	}
	else {
#ifdef XM7DASH
		strncpy(StatePath, path, sizeof(StatePath));
		SetAllMRUFile();
#else
		strncpy(StatePath, path, 256);
#endif
		GetCfg();
		SetMachineVersion();
	}
}

#ifdef XM7DASH
/*
 *	�t�@�C���t�����b�Z�[�W�{�b�N�X
 */
static int FASTCALL FileMessageBox(HWND hWnd, UINT uID, char *path, UINT uType)
{
	char string[256];
	char buffer[256];
	char tmp[256];
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];

	memset(&tmp, 0, sizeof(tmp));
	if (path != NULL) {
		if (path[0] != '\0') {
			_splitpath(path, drive, dir, fname, ext);
			if (strlen(dir) > 1) {
				strncpy(dir, "\\...\\", sizeof(dir));
			}
			strncpy(tmp, drive, sizeof(tmp));
			strncat(tmp, dir, sizeof(tmp)-strlen(tmp)-1);
			strncat(tmp, fname, sizeof(tmp)-strlen(tmp)-1);
			strncat(tmp, ext, sizeof(tmp)-strlen(tmp)-1);
		}
	}

	LoadString(hResInstance, uID, buffer, sizeof(buffer));
	_snprintf(string, sizeof(string), buffer, tmp);
	return MessageBox(hWnd, string, "XM7", uType);
}

/*
 *	���j���[���X�g�ǉ�����
 */
static void FASTCALL AddMenuList(HMENU hMenu, UINT uitem, WORD wIDS,
									WORD wID, int type, BOOL bflag)
{
	HMENU hSubMenu;
	MENUITEMINFO mii;
	int	i, j, k;
	char buffer[256+1];
	char string[256+1];
	UINT uitem2;

	ASSERT(hMenu);

	/* �T�u���j���[�n���h�����擾 */
	hSubMenu = GetSubMenu(hMenu, uitem);

	/* �T�u���j���[���ׂč폜 */
	while (GetMenuItemCount(hSubMenu) > 0) {
		DeleteMenu(hSubMenu, 0, MF_BYPOSITION);
	}

	/* ���j���[�\���̏����� */
	memset(&mii, 0, sizeof(mii));
	mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
	mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
	mii.fType = MFT_STRING | MFT_RADIOCHECK;

	/* ���X�g�ǉ� */
	for (i=0; i<=XDL_FILES; i++) {
		char fname[_MAX_FNAME];
		mii.wID = wID + i;
		mii.fState = MFS_ENABLED;

		/* �擾���Ă݂� */
		if (i == 0) {
			LoadString(hResInstance, wIDS, buffer, sizeof(buffer));
		}
		else {
			GetXDLFile(type, i - 1, buffer, sizeof(buffer));
		}
		if (buffer[0] == '\0') {
			break;
		}

		/* ����΃��j���[�ɒǉ� */
		_splitpath(buffer, NULL, NULL, fname, NULL);
		strncpy(buffer, fname, sizeof(buffer));

		/* �v���t�B�b�N�X�����΍� */
		_snprintf(string, sizeof(string), "&%c ", '0' + i);
		k = strlen(string);
		for (j = 0; j < (int)strlen(buffer); j++) {
			if (buffer[j] == '&') {
				string[k++] = '&';
			}
			string[k++] = buffer[j];
		}
		string[k] = '\0';
		mii.dwTypeData = string;
		mii.cch = strlen(string);
		InsertMenuItem(hSubMenu, i, TRUE, &mii);
	}

	/* ���X�g���Ȃ���� */
	if (i <= 1) {
		EnableMenuItem(hMenu, uitem, MF_BYPOSITION | MF_GRAYED);
	}
	else {
		if (bflag) {
			uitem2 = GetXDLSel(type) + 1;
		}
		else {
			uitem2 = 0;
		}
		CheckMenuRadioItem(hSubMenu, wID, wID + i, wID + uitem2, MF_BYCOMMAND);
	}
}

/*
 *	�t�@�C�������X�V����
 */
static UINT FASTCALL AppendMenuHistory(HMENU hMenu, UINT uItem, UINT uID, int type, BOOL enable)
{
	MENUITEMINFO mii;
	char string[256+1];
	char buffer[256+1];
	UINT uitem;
	int	i, j, k;

	ASSERT(hMenu);

	/* ���j���[�\���̏����� */
	memset(&mii, 0, sizeof(mii));
	mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
	mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
	mii.fType = MFT_STRING;
	if (enable) {
		mii.fState = MFS_ENABLED;
	}
	else {
		mii.fState = MFS_GRAYED;
	}
	uitem = uItem;

	/* ����������� */
	if (GetMRUNum(type) != 0) {
		/* �Z�p���[�^�}�� */
		mii.fType = MFT_SEPARATOR;
		InsertMenuItem(hMenu, uitem++, TRUE, &mii);
		mii.fType = MFT_STRING;

		/* �������� */
		for (i=0; i<MRU_FILES; i++) {
			char drive[_MAX_DRIVE];
			char dir[_MAX_DIR];
			char fname[_MAX_FNAME];
			char ext[_MAX_EXT];

			/* �擾���Ă݂� */
			GetMRUFile(type, i, buffer, sizeof(buffer));
			if (buffer[0] == '\0') {
				break;
			}

			/* ����΃��j���[�ɒǉ� */
			_splitpath(buffer, drive, dir, fname, ext);
			if (strlen(dir) > 1) {
				strncpy(dir, "\\...\\", sizeof(dir));
			}
			strncpy(buffer, drive, sizeof(buffer));
			strncat(buffer, dir, sizeof(buffer)-strlen(buffer)-1);
			strncat(buffer, fname, sizeof(buffer)-strlen(buffer)-1);
			strncat(buffer, ext, sizeof(buffer)-strlen(buffer)-1);

			mii.wID = uID + i;
			/* �v���t�B�b�N�X�����΍� */
			_snprintf(string, sizeof(string), "&%d ", i + 1);
			k = strlen(string);
			for (j = 0; j < (int)strlen(buffer); j++) {
				if (buffer[j] == '&') {
					string[k++] = '&';
				}
				string[k++] = buffer[j];
			}
			string[k] = '\0';
			mii.dwTypeData = string;
			mii.cch = strlen(string);
			InsertMenuItem(hMenu, uitem++, TRUE, &mii);
		}
	}

	return uitem;
}

/*
 *	�R���e�L�X�g���j���[�o�͏���
 */
static void FASTCALL OnContextualSubMenu(HWND hWnd, HMENU hMenu, WORD wID, int x, int y)
{
	POINT point;
	HMENU hSubMenu;
	WORD wRet;

	/* �T�u���j���[�\���������\�[�XID��ۑ� */
	wMenuID = wID;

	/* �R���e�L�X�g���j���[�����s */
	point.x = x;
	point.y = y;
	hSubMenu = GetSubMenu(hMenu, 0);
	wRet = TrackPopupMenu(hSubMenu, TPM_RECURSE|TPM_RETURNCMD, point.x, point.y, 0, hWnd, NULL);
	if (wRet != 0) {
		EnterMenu(hWnd);
		OnCommand(hWnd, wRet);
		ExitMenu();
		OnExitMenuLoop();
		SetMenuExitTimer();
		bMenuLoop = FALSE;
	}
}

/*
 *	�q�X�g���폜����
 */
static void FASTCALL DeleteHistory(HWND hWnd, WORD wID)
{
	char string[256 + 1];
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	int type;
	int index;
	int nret;

	/* ���X�g����Z�b�g */
	if ((wID >= IDM_STATE_FILE0) && (wID <= IDM_STATE_FILE9)) {
		type = MRU_STATE;
		index = wID - IDM_STATE_FILE0;
	}
#if XM7_VER == 1 && defined(SFDC)
	if (((wID >= IDM_D7_FILE0) && (wID <= IDM_D7_FILE9))) {
		type = MRU_SFD3;
		index = wID - IDM_D7_FILE0;
	}
	if (((wID >= IDM_D6_FILE0) && (wID <= IDM_D6_FILE9))) {
		type = MRU_SFD2;
		index = wID - IDM_D6_FILE0;
	}
	if (((wID >= IDM_D5_FILE0) && (wID <= IDM_D5_FILE9))) {
		type = MRU_SFD1;
		index = wID - IDM_D5_FILE0;
	}
	if (((wID >= IDM_D4_FILE0) && (wID <= IDM_D4_FILE9))) {
		type = MRU_SFD0;
		index = wID - IDM_D4_FILE0;
	}
#endif	/* XM7_VER == 1 && defined(SFDC) */
	if ((wID >= IDM_D3_FILE0) && (wID <= IDM_D3_FILE9)) {
		type = MRU_MFD3;
		index = wID - IDM_D3_FILE0;
	}
	if ((wID >= IDM_D2_FILE0) && (wID <= IDM_D2_FILE9)) {
		type = MRU_MFD2;
		index = wID - IDM_D2_FILE0;
	}
	if ((wID >= IDM_D1_FILE0) && (wID <= IDM_D1_FILE9)) {
		type = MRU_MFD1;
		index = wID - IDM_D1_FILE0;
	}
	if ((wID >= IDM_D0_FILE0) && (wID <= IDM_D0_FILE9)) {
		type = MRU_MFD0;
		index = wID - IDM_D0_FILE0;
	}
	if ((wID >= IDM_T_FILE0) && (wID <= IDM_T_FILE9)) {
		type = MRU_TAPE;
		index = wID - IDM_T_FILE0;
	}
#if XM7_VER == 1 && defined(BUBBLE)
	if ((wID >= IDM_B3_FILE0) && (wID <= IDM_B3_FILE9)) {
		type = MRU_BBL128_1;
		index = wID - IDM_B3_FILE0;
	}
	if ((wID >= IDM_B2_FILE0) && (wID <= IDM_B2_FILE9)) {
		type = MRU_BBL128_0;
		index = wID - IDM_B2_FILE0;
	}
	if ((wID >= IDM_B1_FILE0) && (wID <= IDM_B1_FILE9)) {
		type = MRU_BBL1;
		index = wID - IDM_B1_FILE0;
	}
	if ((wID >= IDM_B0_FILE0) && (wID <= IDM_B0_FILE9)) {
		type = MRU_BBL0;
		index = wID - IDM_B0_FILE0;
	}
#endif

	/* �擾���Ă݂� */
	GetMRUFile(type, index, string, sizeof(string));
	nret = FileMessageBox(hWnd, IDS_HISTORY_DELETE, string, MB_ICONQUESTION | MB_YESNO);
	/* �m�F���ʂɂ�� */
	switch (nret) {
		/* YES */
		case IDYES:
			/* �X�e�[�g�Z�[�u */
			LockVM();
			StopSnd();
			DelMRUFile(type, index);
			PlaySnd();
			UnlockVM();
			break;

		/* NO */
		case IDNO:
			break;
	}
}

#ifdef FILTERDLL
/*
 *	�A�X�y�N�g��ݒ菈��
 */
static void FASTCALL AspectSetting(HWND hWnd, WORD wID)
{
	int nret;

	ASSERT(hWnd);
	UNUSED(wID);

	/* �A�X�y�N�g����� */
	dRatio = dAspectRatio;
	nret = DialogBox(hResInstance, MAKEINTRESOURCE(IDD_ASPECTRATIODLG),
						hWnd, AspectRatioDlgProc);
	if (nret != IDOK) {
		SetMenuExitTimer();
		return;
	}

	/* �쐬 */
	LockVM();
	StopSnd();

	/* �A�X�y�N�g���ύX */
	dAspectRatio = dRatio;

	/* �A�X�y�N�g�䒲���t���O��ύX */
	bAspectRatio = TRUE;

	/* �\�����e���X�V */
	OnSize(hWnd, 640, 400);
	InvalidateRect(hDrawWnd, NULL, FALSE);

	PlaySnd();
	ResetSch();
	UnlockVM();

	SetMenuExitTimer();
}
#endif
#endif

/*-[ �t�@�C�����j���[ ]-----------------------------------------------------*/

/*
 *	�J��(O)
 */
static void FASTCALL OnOpen(HWND hWnd)
{
	char path[_MAX_PATH];

	ASSERT(hWnd);

	/* �t�@�C���I���T�u */
	if (!FileSelectSub(TRUE, IDS_STATEFILTER, path, NULL, 2)) {
		return;
	}

	/* �X�e�[�g���[�h */
	LockVM();
	StopSnd();
	StateLoad(path);
	PlaySnd();
	ResetSch();
	UnlockVM();

	/* ��ʍĕ`�� */
	OnRefresh(hWnd);

#ifdef XM7DASH
	/* �\�����e���X�V */
	OnSize(hWnd, 640, 400);
#endif
}

/*
 *	���O��t���ĕۑ�(A)
 */
static void FASTCALL OnSaveAs(HWND hWnd)
{
	char path[_MAX_PATH];

	ASSERT(hWnd);

	/* �t�@�C���I���T�u */
	if (!FileSelectSub(FALSE, IDS_STATEFILTER, path, "XM7", 2)) {
		return;
	}

	/* �X�e�[�g�Z�[�u */
	LockVM();
	StopSnd();
#ifdef XM7DASH
	if (bBackupState) {
		/* �X�e�[�g�̑Ҕ� */
		file_rename(path);
	}
#endif
	if (!system_save(path)) {
		LoadString(hResInstance, IDS_STATEERROR, path, sizeof(path));
		MessageBox(hWnd, path, "XM7", MB_ICONSTOP | MB_OK);
		SetMenuExitTimer();
	}
	else {
		strncpy(StatePath, path, sizeof(StatePath));
#ifdef XM7DASH
		SetMRUFile(MRU_STATE, StatePath);
#endif
	}
	PlaySnd();
	ResetSch();
	UnlockVM();
}

/*
 *	�㏑���ۑ�(S)
 */
static void FASTCALL OnSave(HWND hWnd)
{
	char string[128];

	/* �܂��ۑ�����Ă��Ȃ���΁A���O������ */
#ifdef XM7DASH
	if ((StatePath[0] == '\0') ||
		(!strncmp(StatePath, QuickPath, _MAX_PATH))) {
#else
	if (StatePath[0] == '\0') {
#endif
		OnSaveAs(hWnd);
		return;
	}

	/* �X�e�[�g�Z�[�u */
	LockVM();
	StopSnd();
#ifdef XM7DASH
	if (bBackupState) {
		/* �X�e�[�g�̑Ҕ� */
		file_rename(StatePath);
	}
#endif
	if (!system_save(StatePath)) {
		LoadString(hResInstance, IDS_STATEERROR, string, sizeof(string));
		MessageBox(hWnd, string, "XM7", MB_ICONSTOP | MB_OK);
		SetMenuExitTimer();
	}
#ifdef XM7DASH
	else {
		SetMRUFile(MRU_STATE, StatePath);
	}
#endif
	PlaySnd();
	ResetSch();
	UnlockVM();
}

#ifdef LPRINT
/*
 *	���(P)
 */
static void FASTCALL OnPrint(void)
{
#ifdef XM7DASH
	if (lp_use) {
		lp_printfile();
	}
#else
	LockVM();
	lp_print();
	UnlockVM();
#endif
}
#endif

/*
 *	���Z�b�g(R)
 */
static void FASTCALL OnReset(HWND hWnd)
{
	LockVM();
	system_reset();
#ifdef XM7DASH
	StatePath[0] = '\0';
	SetAllMRUFile();
#endif
	ResetSch();
	UnlockVM();

	/* �ĕ`�� */
	OnRefresh(hWnd);
}

/*
 *	�z�b�g���Z�b�g(H)
 */
static void FASTCALL OnHotReset(HWND hWnd)
{
	LockVM();
	system_hotreset();
	UnlockVM();

	/* �ĕ`�� */
	OnRefresh(hWnd);
}

/*
 *	BASIC���[�h(B)
 */
static void FASTCALL OnBasic(void)
{
	LockVM();
	boot_mode = BOOT_BASIC;
	GetCfg();
#if XM7_VER >= 2
#if XM7_VER >= 3 && defined(XM7DASH)
	if (fm_subtype < FMSUB_FM77AV) {
#else
	if (fm7_ver < 2) {
#endif
		mainmem_transfer_boot();
	}
#else
#ifdef XM7DASH
	if (fm_subtype == FMSUB_FM8 && !banksel_en) {
#else
	if (fm_subtype == FMSUB_FM8) {
#endif
		basicrom_en = TRUE;
	}
#endif
	UnlockVM();
}

/*
 *	DOS���[�h(D)
 */
static void FASTCALL OnDos(void)
{
	LockVM();
	boot_mode = BOOT_DOS;
	GetCfg();
#if XM7_VER >= 2
#if XM7_VER >= 3 && defined(XM7DASH)
	if (fm_subtype < FMSUB_FM77AV) {
#else
	if (fm7_ver < 2) {
#endif
		mainmem_transfer_boot();
	}
#else
#ifdef XM7DASH
	if (fm_subtype == FMSUB_FM8 && !banksel_en) {
#else
	if (fm_subtype == FMSUB_FM8) {
#endif
		basicrom_en = FALSE;
	}
#endif
	UnlockVM();
}

#if XM7_VER == 1 && defined(XM7DASH)
/*
 *	1MB(SFD) DOS���[�h(1)
 */
static void FASTCALL OnDosSfd(void)
{
	LockVM();
	boot_mode = BOOT_DOS_SFD;
	GetCfg();
	if (fm_subtype == FMSUB_FM8 && !banksel_en) {
		basicrom_en = FALSE;
	}
	UnlockVM();
}

/*
 *	BASIC(��RAM/DEBUG)���[�h(R)
 */
static void FASTCALL OnBasicRam(void)
{
	LockVM();
	boot_mode = BOOT_BASIC_RAM;
	GetCfg();
	if (fm_subtype == FMSUB_FM8 && !banksel_en) {
		basicrom_en = FALSE;
	}
	UnlockVM();
}

/*
 *	�o�u�����[�h(U)
 */
static void FASTCALL OnBubble32(void)
{
	LockVM();
	boot_mode = BOOT_BUBBLE;
	GetCfg();
	mainmem_bubblemode_boot();
	if (fm_subtype == FMSUB_FM8 && !banksel_en) {
		basicrom_en = FALSE;
	}
	UnlockVM();
}

/*
 *	128KB�o�u�����[�h(L)
 */
static void FASTCALL OnBubble128(void)
{
	LockVM();
	boot_mode = BOOT_BUBBLE128;
	GetCfg();
	mainmem_bubblemode_boot();
	if (fm_subtype == FMSUB_FM8 && !banksel_en) {
		basicrom_en = FALSE;
	}
	UnlockVM();
}
#else
/*
 *	�o�u�����[�h(U)
 */
#if XM7_VER == 1 && defined(BUBBLE)
static void FASTCALL OnBubble(void)
{
	LockVM();
	boot_mode = BOOT_BUBBLE;
	GetCfg();
	if (fm_subtype == FMSUB_FM8) {
		basicrom_en = FALSE;
	}
	UnlockVM();
}
#endif
#endif	/* XM7_VER == 1 && defined(XM7DASH) */

#ifdef XM7DASH
/*
 *	�N�C�b�N���[�h(K)
 */
static void FASTCALL OnQuickLoad(HWND hWnd)
{
	ASSERT(hWnd);

	/* �X�e�[�g���[�h */
	LockVM();
	StopSnd();
	StateLoad(QuickPath);
	PlaySnd();
	ResetSch();
	UnlockVM();

	/* ��ʍĕ`�� */
	OnRefresh(hWnd);

	/* �\�����e���X�V */
	OnSize(hWnd, 640, 400);
}

/*
 *	�N�C�b�N�Z�[�u(Q)
 */
static void FASTCALL OnQuickSave(HWND hWnd)
{
	char string[128];

	/* �X�e�[�g�Z�[�u */
	LockVM();
	StopSnd();
	if (bBackupState) {
		/* �X�e�[�g�̑Ҕ� */
		file_rename(QuickPath);
	}
	if (!system_save(QuickPath)) {
		LoadString(hResInstance, IDS_STATEERROR, string, sizeof(string));
		MessageBox(hWnd, string, "XM7", MB_ICONSTOP | MB_OK);
		SetMenuExitTimer();
	}
	PlaySnd();
	ResetSch();
	UnlockVM();
}
#endif	/* XM7DASH */

/*
 *	�I��(X)
 */
static void FASTCALL OnExit(HWND hWnd)
{
	/* �E�C���h�E�N���[�Y */
	PostMessage(hWnd, WM_CLOSE, 0, 0);
}

/*
 *	�t�@�C��(F)���j���[
 */
static BOOL OnFile(HWND hWnd, WORD wID)
{
	ASSERT(hWnd);

	switch (wID) {
		/* �I�[�v�� */
		case IDM_OPEN:
			OnOpen(hWnd);
			return TRUE;

		/* �㏑���ۑ� */
		case IDM_SAVE:
			OnSave(hWnd);
			return TRUE;

		/* ���O�����ĕۑ� */
		case IDM_SAVEAS:
			OnSaveAs(hWnd);
			return TRUE;

#ifdef LPRINT
		/* ��� */
		case IDM_PRINT:
			OnPrint();
			return TRUE;
#endif

		/* ���Z�b�g */
		case IDM_RESET:
			OnReset(hWnd);
			return TRUE;

		/* �z�b�g���Z�b�g */
		case IDM_HOTRESET:
			OnHotReset(hWnd);
			return TRUE;

		/* BASIC���[�h */
		case IDM_BASIC:
			OnBasic();
			return TRUE;

		/* DOS���[�h */
		case IDM_DOS:
			OnDos();
			return TRUE;

#if XM7_VER == 1 && defined(XM7DASH)
		/* 1MB DOS���[�h */
		case IDM_DOS_SFD:
			OnDosSfd();
			return TRUE;

		/* BASIC(��RAM)���[�h/BASIC(DEBUG)���[�h */
		case IDM_BASIC_RAM:
		case IDM_BASIC_DBG:
			OnBasicRam();
			return TRUE;

		/* BUBBLE���[�h */
		case IDM_BUBBLE:
			OnBubble32();
			return TRUE;

		/* 128KB BUBBLE���[�h */
		case IDM_BUBBLE128:
			OnBubble128();
			return TRUE;
#else
#if XM7_VER == 1 && defined(BUBBLE)
		/* �o�u�����[�h */
		case IDM_BUBBLE:
			OnBubble();
			return TRUE;
#endif
#endif	/* XM7_VER == 1 && defined(XM7DASH) */

#ifdef XM7DASH
		/* �N�C�b�N���[�h */
		case IDM_QLOAD:
			OnQuickLoad(hWnd);
			return TRUE;

		/* �N�C�b�N�Z�[�u */
		case IDM_QSAVE:
			OnQuickSave(hWnd);
			return TRUE;
#endif	/* XM7DASH */

		/* �I�� */
		case IDM_EXIT:
			OnExit(hWnd);
			return TRUE;
	}

#ifdef XM7DASH
	/* ���X�g����Z�b�g */
	if ((wID >= IDM_STATE_FILE0) && (wID <= IDM_STATE_FILE9)) {
		char string[256 + 1];
		GetMRUFile(MRU_STATE, wID - IDM_STATE_FILE0, string, sizeof(string));

		LockVM();
		StopSnd();
		StateLoad(string);
		PlaySnd();
		ResetSch();
		UnlockVM();

		/* ��ʍĕ`�� */
		OnRefresh(hWnd);

		/* �\�����e���X�V */
		OnSize(hWnd, 640, 400);

		return TRUE;
	}
#endif	/* XM7DASH */

	return FALSE;
}

/*
 *	�t�@�C��(F)���j���[�X�V
 */
static void FASTCALL OnFilePopup(HMENU hMenu)
{
#ifdef XM7DASH
	MENUITEMINFO mii;
	char string[128];
	UINT uitem;
#endif
	UINT id;

	ASSERT(hMenu);

#ifdef XM7DASH
#if XM7_VER == 1
	uitem = 9;
 #ifdef SFDC
	uitem += 1;
 #endif

	/* ���j���[���ڂ��炢������폜 */
	DeleteMenu(hMenu, uitem, MF_BYPOSITION);

	/* ���߂č��ڂ�˂����� */
	memset(&mii, 0, sizeof(mii));
	mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
	mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
	mii.fType = MFT_STRING;
	mii.fState = MFS_ENABLED;
	if ((fm_subtype == FMSUB_FM8)) {
		mii.wID = IDM_BASIC_DBG;
		LoadString(hResInstance, IDS_BASIC_DBG, string, sizeof(string));
	}
	else {
		mii.wID = IDM_BASIC_RAM;
		LoadString(hResInstance, IDS_BASIC_RAM, string, sizeof(string));
	}
	mii.dwTypeData = string;
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, uitem, TRUE, &mii);
#endif

	/* ���j���[�\���̏����� */
	memset(&mii, 0, sizeof(mii));
	mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
	mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
	mii.fType = MFT_STRING;
	mii.fState = MFS_ENABLED;
	uitem = 12;
#if XM7_VER == 1
	uitem += 1;
 #ifdef SFDC
	uitem += 1;
 #endif
 #ifdef BUBBLE
	uitem += 2;
 #endif
#endif	/* XM7_VER == 1 */
#ifdef LPRINT
	uitem += 2;
#endif

	/* �Z�p���[�^�������āA����ȍ~�̃��j���[�͂��ׂč폜 */
	while (GetMenuItemCount(hMenu) > (int)uitem) {
		DeleteMenu(hMenu, uitem, MF_BYPOSITION);
	}

	/* ����}�� */
	uitem = AppendMenuHistory(hMenu, uitem, IDM_STATE_FILE0, MRU_STATE, TRUE);

	/* �Z�p���[�^�}�� */
	mii.fType = MFT_SEPARATOR;
	InsertMenuItem(hMenu, uitem++, TRUE, &mii);
	mii.fType = MFT_STRING;

	/* �I�����j���[��ǉ� */
	mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
	mii.wID = IDM_EXIT;
	LoadString(hResInstance, IDS_EXIT, string, sizeof(string));
	mii.dwTypeData = string;
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, uitem++, TRUE, &mii);
#endif

#if defined(RSTATE) && defined(XM7DASH)
	/* �X�e�[�g�ۑ��@�\���� */
	EnableMenuSub(hMenu, IDM_SAVE, bStateSave);
	EnableMenuSub(hMenu, IDM_SAVEAS, bStateSave);
	EnableMenuSub(hMenu, IDM_QLOAD, bStateSave);
	EnableMenuSub(hMenu, IDM_QSAVE, bStateSave);
#endif	/* defined(RSTATE) && defined(XM7DASH) */

#if XM7_VER == 1 && defined(XM7DASH)
#ifdef SFDC
	EnableMenuSub(hMenu, IDM_DOS_SFD, availableSFDBOOT);
#endif
	if ((fm_subtype == FMSUB_FM8)) {
		EnableMenuSub(hMenu, IDM_BASIC_DBG, available_dbgboot8);
	}
	else {
		EnableMenuSub(hMenu, IDM_BASIC_RAM, (fm_subtype == FMSUB_FM77));
	}
#ifdef BUBBLE
	EnableMenuSub(hMenu, IDM_BUBBLE, availableBBLBOOT);
	EnableMenuSub(hMenu, IDM_BUBBLE128, availableBBLBOOT);
#endif
#endif	/* XM7_VER == 1 && defined(XM7DASH) */

	switch (boot_mode) {
		case BOOT_BASIC:
			id = IDM_BASIC;
			break;
		case BOOT_DOS:
			id = IDM_DOS;
			break;
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		case BOOT_DOS_SFD:
			id = IDM_DOS_SFD;
			break;
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
#if XM7_VER == 1 && defined(XM7DASH)
		case BOOT_BASIC_RAM:
			if ((fm_subtype == FMSUB_FM8)) {
				id = IDM_BASIC_DBG;
			}
			else {
				id = IDM_BASIC_RAM;
			}
			break;
#endif	/* XM7_VER == 1 && defined(XM7DASH) */
#if XM7_VER == 1 && defined(BUBBLE)
		case BOOT_BUBBLE:
			id = IDM_BUBBLE;
			break;
#ifdef XM7DASH
		case BOOT_BUBBLE128:
			id = IDM_BUBBLE128;
			break;
#endif
#endif
		default:
			ASSERT(FALSE);
			break;
	}

#if XM7_VER == 1 && defined(XM7DASH)
	CheckMenuRadioItem(hMenu, IDM_BASIC, IDM_BASIC_DBG, id, MF_BYCOMMAND);
#elif XM7_VER == 1 && defined(BUBBLE)
	CheckMenuRadioItem(hMenu, IDM_BASIC, IDM_BUBBLE, id, MF_BYCOMMAND);
	EnableMenuSub(hMenu, IDM_BUBBLE, (fm_subtype == FMSUB_FM8) && bubble_available);
#else
	CheckMenuRadioItem(hMenu, IDM_BASIC, IDM_DOS, id, MF_BYCOMMAND);
#endif

#ifdef LPRINT
	EnableMenuSub(hMenu, IDM_PRINT, lp_use);
#endif
}

#ifdef XM7DASH
/*
 *	�t�@�C��(F)�R���e�L�X�g���j���[
 */
static BOOL FASTCALL OnFileContextualMenu(HWND hWnd, WORD wID, int x, int y)
{
	ASSERT(hWnd);

	/* �q�X�g�� */
	if ((wID >= IDM_STATE_FILE0) && (wID <= IDM_STATE_FILE9)) {
		OnContextualSubMenu(hWnd, hHistoryMenu, wID, x, y);
		return TRUE;
	}

	return FALSE;
}
#endif

/*-[ �f�B�X�N���j���[ ]-----------------------------------------------------*/

/*
 *	�h���C�u���J��
 */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
static void FASTCALL OnDiskOpen(int Type, int Drive)
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
static void FASTCALL OnDiskOpen(int Drive)
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
{
	char path[_MAX_PATH];

#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	ASSERT((Type == FDC_M) || (Type == FDC_S));
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
#ifdef XM7DASH
	ASSERT((Drive >= 0) || (Drive <= 3));
#else
	ASSERT((Drive == 0) || (Drive == 1));
#endif

	/* �t�@�C���I�� */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	if (Type == FDC_M) {
		if (!FileSelectSub(TRUE, IDS_DISKFILTER, path, NULL, 0)) {
			return;
		}
	}
	else {
		if (!FileSelectSub(TRUE, IDS_DISKFILTER_SFD, path, NULL, 0)) {
			return;
		}
	}
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	if (!FileSelectSub(TRUE, IDS_DISKFILTER, path, NULL, 0)) {
		return;
	}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */

	/* �Z�b�g */
	LockVM();
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	fdc_setdisk(Type, Drive, path);
	if (fdc_ready[Type][Drive] != FDC_TYPE_NOTREADY) {
		SetMRUFile(MRU_MFD0 + Drive + Type * 4, fdc_fname[Type][Drive]);
	}
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	fdc_setdisk(Drive, path);
 #ifdef XM7DASH
	if (fdc_ready[Drive] != FDC_TYPE_NOTREADY) {
		SetMRUFile(MRU_MFD0 + Drive, fdc_fname[Drive]);
	}
 #endif
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	ResetSch();
	UnlockVM();

#ifdef XM7DASH
	/* �\�����e���X�V */
	if (hMainWnd) {
		OnSize(hMainWnd, 640, 400);
	}
#endif
}

/*
 *	���h���C�u���J��
 */
#ifdef XM7DASH
#if XM7_VER == 1 && defined(SFDC)
static void FASTCALL OnDiskBoth(int Type, int Drive)
#else	/* XM7_VER == 1 && defined(SFDC) */
static void FASTCALL OnDiskBoth(int Drive)
#endif	/* XM7_VER == 1 && defined(SFDC) */
#else	/* XM7DASH */
static void FASTCALL OnDiskBoth(void)
#endif	/* XM7DASH */
{
	char path[_MAX_PATH];

	/* �t�@�C���I�� */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	if (Type == FDC_M) {
		if (!FileSelectSub(TRUE, IDS_DISKFILTER, path, NULL, 0)) {
			return;
		}
	}
	else {
		if (!FileSelectSub(TRUE, IDS_DISKFILTER_SFD, path, NULL, 0)) {
			return;
		}
	}
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	if (!FileSelectSub(TRUE, IDS_DISKFILTER, path, NULL, 0)) {
		return;
	}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */

	/* �Z�b�g */
	LockVM();
#ifdef XM7DASH
#if XM7_VER == 1 && defined(SFDC)
	fdc_setdisk(Type, Drive + 0, path);
	fdc_setdisk(Type, Drive + 1, NULL);
	if (fdc_ready[Type][Drive] != FDC_TYPE_NOTREADY) {
		SetMRUFile(MRU_MFD0 + Drive + Type * 4, fdc_fname[Type][Drive]);
	}
	if ((fdc_ready[Type][Drive + 0] != FDC_TYPE_NOTREADY) && (fdc_medias[Type][Drive + 0] >= 2)) {
		fdc_setdisk(Type, Drive + 1, path);
		fdc_setmedia(Type, Drive + 1, 1);
		if (fdc_ready[Type][Drive + 1] != FDC_TYPE_NOTREADY) {
			SetMRUFile(MRU_MFD0 + Drive + 1 + Type * 4, fdc_fname[Type][Drive + 1]);
			SetMRUMedia(MRU_MFD0 + Drive + 1 + Type * 4, fdc_media[Type][Drive + 1]);
		}
	}
#else	/* XM7_VER == 1 && defined(SFDC) */
	fdc_setdisk(Drive + 0, path);
	fdc_setdisk(Drive + 1, NULL);
	if (fdc_ready[Drive] != FDC_TYPE_NOTREADY) {
		SetMRUFile(MRU_MFD0 + Drive, fdc_fname[Drive]);
	}
	if ((fdc_ready[Drive + 0] != FDC_TYPE_NOTREADY) && (fdc_medias[Drive + 0] >= 2)) {
		fdc_setdisk(Drive + 1, path);
		fdc_setmedia(Drive + 1, 1);
		if (fdc_ready[Drive + 1] != FDC_TYPE_NOTREADY) {
			SetMRUFile(MRU_MFD0 + Drive + 1, fdc_fname[Drive + 1]);
			SetMRUMedia(MRU_MFD0 + Drive + 1, fdc_media[Drive + 1]);
		}
	}
#endif	/* XM7_VER == 1 && defined(SFDC) */
#else	/* XM7DASH */
	fdc_setdisk(0, path);
	fdc_setdisk(1, NULL);
	if ((fdc_ready[0] != FDC_TYPE_NOTREADY) && (fdc_medias[0] >= 2)) {
		fdc_setdisk(1, path);
		fdc_setmedia(1, 1);
	}
#endif	/* XM7DASH */
	ResetSch();
	UnlockVM();

#ifdef XM7DASH
	/* �\�����e���X�V */
	if (hMainWnd) {
		OnSize(hMainWnd, 640, 400);
	}
#endif
}

#ifdef XM7DASH
/*
 *	���h���C�u����������
 */
#if XM7_VER == 1 && defined(SFDC)
static void FASTCALL OnDiskReplace(int Type, int Drive)
#else	/* XM7_VER == 1 && defined(SFDC) */
static void FASTCALL OnDiskReplace(int Drive)
#endif	/* XM7_VER == 1 && defined(SFDC) */
{
	char cfname[256+1];	/* �t�@�C���� */
	BYTE nmedia;		/* ���f�B�A�Z���N�g��� */

#if XM7_VER == 1 && defined(SFDC)
	ASSERT((Type == FDC_M) || (Type == FDC_S));
#endif	/* XM7_VER == 1 && defined(SFDC) */
	ASSERT((Drive >= 0) || (Drive <= 3));

	/* �Z�b�g */
	LockVM();
#if XM7_VER == 1 && defined(SFDC)
	if (fdc_ready[Type][Drive + 0] == FDC_TYPE_NOTREADY) {
		memset(cfname, 0, sizeof(cfname));
	}
	else {
		strncpy(cfname, fdc_fname[Type][Drive + 0], sizeof(cfname));
	}
	nmedia = fdc_media[Type][Drive + 0];
	if (fdc_ready[Type][Drive + 1] == FDC_TYPE_NOTREADY) {
		fdc_setdisk(Type, Drive + 0, NULL);
	}
	else {
		fdc_setdisk(Type, Drive + 0, fdc_fname[Type][Drive + 1]);
		fdc_setmedia(Type, Drive + 0, fdc_media[Type][Drive + 1]);
		if (fdc_ready[Type][Drive + 0] != FDC_TYPE_NOTREADY) {
			SetMRUFile(MRU_MFD0 + Drive + 0 + Type * 4, fdc_fname[Type][Drive + 0]);
			SetMRUMedia(MRU_MFD0 + Drive + 0 + Type * 4, fdc_media[Type][Drive + 0]);
		}
	}
	if (strlen(cfname) == 0) {
		fdc_setdisk(Type, Drive + 1, NULL);
	}
	else {
		fdc_setdisk(Type, Drive + 1, cfname);
		fdc_setmedia(Type, Drive + 1, nmedia);
		if (fdc_ready[Type][Drive + 1] != FDC_TYPE_NOTREADY) {
			SetMRUFile(MRU_MFD0 + Drive + 1 + Type * 4, fdc_fname[Type][Drive + 1]);
			SetMRUMedia(MRU_MFD0 + Drive + 1 + Type * 4, fdc_media[Type][Drive + 1]);
		}
	}
#else	/* XM7_VER == 1 && defined(SFDC) */
	if (fdc_ready[Drive + 0] == FDC_TYPE_NOTREADY) {
		memset(cfname, 0, sizeof(cfname));
	}
	else {
		strncpy(cfname, fdc_fname[Drive + 0], sizeof(cfname));
	}
	nmedia = fdc_media[Drive + 0];
	if (fdc_ready[Drive + 1] == FDC_TYPE_NOTREADY) {
		fdc_setdisk(Drive + 0, NULL);
	}
	else {
		fdc_setdisk(Drive + 0, fdc_fname[Drive + 1]);
		fdc_setmedia(Drive + 0, fdc_media[Drive + 1]);
		if (fdc_ready[Drive + 0] != FDC_TYPE_NOTREADY) {
			SetMRUFile(MRU_MFD0 + Drive + 0, fdc_fname[Drive + 0]);
			SetMRUMedia(MRU_MFD0 + Drive + 0, fdc_media[Drive + 0]);
		}
	}
	if (strlen(cfname) == 0) {
		fdc_setdisk(Drive + 1, NULL);
	}
	else {
		fdc_setdisk(Drive + 1, cfname);
		fdc_setmedia(Drive + 1, nmedia);
		if (fdc_ready[Drive + 1] != FDC_TYPE_NOTREADY) {
			SetMRUFile(MRU_MFD0 + Drive + 1, fdc_fname[Drive + 1]);
			SetMRUMedia(MRU_MFD0 + Drive + 1, fdc_media[Drive + 1]);
		}
	}
#endif	/* XM7_VER == 1 && defined(SFDC) */
	ResetSch();
	UnlockVM();

	/* �\�����e���X�V */
	if (hMainWnd) {
		OnSize(hMainWnd, 640, 400);
	}
}
#endif

/*
 *	�f�B�X�N�C�W�F�N�g
 */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
static void FASTCALL OnDiskEject(int Type, int Drive)
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
static void FASTCALL OnDiskEject(int Drive)
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
{
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	ASSERT((Type == FDC_M) || (Type == FDC_S));
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
#ifdef XM7DASH
	ASSERT((Drive >= 0) || (Drive <= 3));
#else
	ASSERT((Drive == 0) || (Drive == 1));
#endif

	/* �C�W�F�N�g */
	LockVM();
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	fdc_setdisk(Type, Drive, NULL);
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	fdc_setdisk(Drive, NULL);
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	UnlockVM();

#ifdef XM7DASH
	/* �\�����e���X�V */
	if (hMainWnd) {
		OnSize(hMainWnd, 640, 400);
	}
#endif
}

/*
 *	�f�B�X�N�ꎞ���o��
 */
#ifndef XM7DASH
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
static void FASTCALL OnDiskTemp(int Type, int Drive)
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
static void FASTCALL OnDiskTemp(int Drive)
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
{
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	ASSERT((Type == FDC_M) || (Type == FDC_S));
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
#ifdef XM7DASH
	ASSERT((Drive >= 0) || (Drive <= 3));
#else
	ASSERT((Drive == 0) || (Drive == 1));
#endif

	/* �������݋֎~�؂�ւ� */
	LockVM();
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	if (fdc_teject[Type][Drive]) {
		fdc_teject[Type][Drive] = FALSE;
	}
	else {
		fdc_teject[Type][Drive] = TRUE;
	}
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	if (fdc_teject[Drive]) {
		fdc_teject[Drive] = FALSE;
	}
	else {
		fdc_teject[Drive] = TRUE;
	}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	UnlockVM();
}
#endif

/*
 *	�f�B�X�N�������݋֎~
 */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
static void FASTCALL OnDiskProtect(int Type, int Drive)
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
static void FASTCALL OnDiskProtect(int Drive)
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
{
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	ASSERT((Type == FDC_M) || (Type == FDC_S));
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
#ifdef XM7DASH
	ASSERT((Drive >= 0) || (Drive <= 3));
#else
	ASSERT((Drive == 0) || (Drive == 1));
#endif

	/* �������݋֎~�؂�ւ� */
	LockVM();
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	if (fdc_writep[Type][Drive]) {
		fdc_setwritep(Type, Drive, FALSE);
	}
	else {
		fdc_setwritep(Type, Drive, TRUE);
	}
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	if (fdc_writep[Drive]) {
		fdc_setwritep(Drive, FALSE);
	}
	else {
		fdc_setwritep(Drive, TRUE);
	}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	ResetSch();
	UnlockVM();
}

#ifdef XM7DASH
/*
 *	�S�f�B�X�N�C�W�F�N�g
 */
#if XM7_VER == 1 && defined(SFDC)
static void FASTCALL OnDiskDriveEject(int Type)
#else	/* XM7_VER == 1 && defined(SFDC) */
static void FASTCALL OnDiskDriveEject(void)
#endif	/* XM7_VER == 1 && defined(SFDC) */
{
	int	i;

#if XM7_VER == 1 && defined(SFDC)
	ASSERT((Type == FDC_M) || (Type == FDC_S));
#endif	/* XM7_VER == 1 && defined(SFDC) */

	/* �C�W�F�N�g */
	LockVM();
	for (i=0; i<4; i++) {
#if XM7_VER == 1 && defined(SFDC)
		fdc_setdisk(Type, i, NULL);
#else	/* XM7_VER == 1 && defined(SFDC) */
		fdc_setdisk(i, NULL);
#endif	/* XM7_VER == 1 && defined(SFDC) */
	}
	UnlockVM();

	/* �\�����e���X�V */
	if (hMainWnd) {
		OnSize(hMainWnd, 640, 400);
	}
}
#endif	/* XM7DASH */

/*
 *	�f�B�X�N(1)(0)���j���[
 */
static BOOL FASTCALL OnDisk(WORD wID)
{
	switch (wID) {
		/* �J�� */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		case IDM_D0OPEN:
			OnDiskOpen(FDC_M, 0);
			break;
		case IDM_D1OPEN:
			OnDiskOpen(FDC_M, 1);
			break;
		case IDM_D2OPEN:
			OnDiskOpen(FDC_M, 2);
			break;
		case IDM_D3OPEN:
			OnDiskOpen(FDC_M, 3);
			break;
		case IDM_D4OPEN:
			OnDiskOpen(FDC_S, 0);
			break;
		case IDM_D5OPEN:
			OnDiskOpen(FDC_S, 1);
			break;
		case IDM_D6OPEN:
			OnDiskOpen(FDC_S, 2);
			break;
		case IDM_D7OPEN:
			OnDiskOpen(FDC_S, 3);
			break;
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		case IDM_D0OPEN:
			OnDiskOpen(0);
			break;
		case IDM_D1OPEN:
			OnDiskOpen(1);
			break;
#ifdef XM7DASH
		case IDM_D2OPEN:
			OnDiskOpen(2);
			break;
		case IDM_D3OPEN:
			OnDiskOpen(3);
			break;
#endif
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */

		/* ���h���C�u�ŊJ�� */
#ifdef XM7DASH
 #if XM7_VER == 1 && defined(SFDC)
		case IDM_DBOPEN:
			OnDiskBoth(FDC_M, 0);
			break;
		case IDM_DB23OPEN:
			OnDiskBoth(FDC_M, 2);
			break;
 #else	/* XM7_VER == 1 && defined(SFDC) */
		case IDM_DBOPEN:
			OnDiskBoth(0);
			break;
		case IDM_DB23OPEN:
			OnDiskBoth(2);
			break;
 #endif	/* XM7_VER == 1 && defined(SFDC) */
#else	/* XM7DASH */
		case IDM_DBOPEN:
			OnDiskBoth();
			break;
#endif	/* XM7DASH */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		case IDM_DB45OPEN:
			OnDiskBoth(FDC_S, 0);
			break;
		case IDM_DB67OPEN:
			OnDiskBoth(FDC_S, 2);
			break;
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */

#ifdef XM7DASH
		/* ���h���C�u���������� */
 #if XM7_VER == 1 && defined(SFDC)
		case IDM_DBREPLACE:
			OnDiskReplace(FDC_M, 0);
			break;
		case IDM_DB23REPLACE:
			OnDiskReplace(FDC_M, 2);
			break;
 #else	/* XM7_VER == 1 && defined(SFDC) */
		case IDM_DBREPLACE:
			OnDiskReplace(0);
			break;
		case IDM_DB23REPLACE:
			OnDiskReplace(2);
			break;
 #endif	/* XM7_VER == 1 && defined(SFDC) */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		case IDM_DB45REPLACE:
			OnDiskReplace(FDC_S, 0);
			break;
		case IDM_DB67REPLACE:
			OnDiskReplace(FDC_S, 2);
			break;
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
#endif	/* XM7DASH */

		/* ���O�� */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		case IDM_D0EJECT:
			OnDiskEject(FDC_M, 0);
			break;
		case IDM_D1EJECT:
			OnDiskEject(FDC_M, 1);
			break;
		case IDM_D2EJECT:
			OnDiskEject(FDC_M, 2);
			break;
		case IDM_D3EJECT:
			OnDiskEject(FDC_M, 3);
			break;
		case IDM_MFD_EJECT:
			OnDiskDriveEject(FDC_M);
			break;
		case IDM_D4EJECT:
		case IDM_D4FORCE:
			OnDiskEject(FDC_S, 0);
			break;
		case IDM_D5EJECT:
		case IDM_D5FORCE:
			OnDiskEject(FDC_S, 1);
			break;
		case IDM_D6EJECT:
		case IDM_D6FORCE:
			OnDiskEject(FDC_S, 2);
			break;
		case IDM_D7EJECT:
		case IDM_D7FORCE:
			OnDiskEject(FDC_S, 3);
			break;
		case IDM_SFD_EJECT:
			OnDiskDriveEject(FDC_S);
			break;
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		case IDM_D0EJECT:
			OnDiskEject(0);
			break;
		case IDM_D1EJECT:
			OnDiskEject(1);
			break;
#ifdef XM7DASH
		case IDM_D2EJECT:
			OnDiskEject(2);
			break;
		case IDM_D3EJECT:
			OnDiskEject(3);
			break;
		case IDM_MFD_EJECT:
			OnDiskDriveEject();
			break;
#endif
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */

		/* �ꎞ�C�W�F�N�g */
#ifndef XM7DASH
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		case IDM_D0TEMP:
			OnDiskTemp(FDC_M, 0);
			break;
		case IDM_D1TEMP:
			OnDiskTemp(FDC_M, 1);
			break;
		case IDM_D2TEMP:
			OnDiskTemp(FDC_M, 2);
			break;
		case IDM_D3TEMP:
			OnDiskTemp(FDC_M, 3);
			break;
		case IDM_D4TEMP:
			OnDiskTemp(FDC_S, 0);
			break;
		case IDM_D5TEMP:
			OnDiskTemp(FDC_S, 1);
			break;
		case IDM_D6TEMP:
			OnDiskTemp(FDC_S, 2);
			break;
		case IDM_D7TEMP:
			OnDiskTemp(FDC_S, 3);
			break;
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		case IDM_D0TEMP:
			OnDiskTemp(0);
			break;
		case IDM_D1TEMP:
			OnDiskTemp(1);
			break;
#ifdef XM7DASH
		case IDM_D2TEMP:
			OnDiskTemp(2);
			break;
		case IDM_D3TEMP:
			OnDiskTemp(3);
			break;
#endif
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
#endif

		/* �������݋֎~ */
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		case IDM_D0WRITE:
			OnDiskProtect(FDC_M, 0);
			break;
		case IDM_D1WRITE:
			OnDiskProtect(FDC_M, 1);
			break;
		case IDM_D2WRITE:
			OnDiskProtect(FDC_M, 2);
			break;
		case IDM_D3WRITE:
			OnDiskProtect(FDC_M, 3);
			break;
		case IDM_D4WRITE:
			OnDiskProtect(FDC_S, 0);
			break;
		case IDM_D5WRITE:
			OnDiskProtect(FDC_S, 1);
			break;
		case IDM_D6WRITE:
			OnDiskProtect(FDC_S, 2);
			break;
		case IDM_D7WRITE:
			OnDiskProtect(FDC_S, 3);
			break;
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		case IDM_D0WRITE:
			OnDiskProtect(0);
			break;
		case IDM_D1WRITE:
			OnDiskProtect(1);
			break;
#ifdef XM7DASH
		case IDM_D2WRITE:
			OnDiskProtect(2);
			break;
		case IDM_D3WRITE:
			OnDiskProtect(3);
			break;
#endif
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	}

	/* ���f�B�A���� */
	if ((wID >= IDM_D0MEDIA00) && (wID <= IDM_D0MEDIA15)) {
		LockVM();
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		fdc_setmedia(FDC_M, 0, wID - IDM_D0MEDIA00);
		SetMRUMedia(MRU_MFD0, fdc_media[FDC_M][0]);
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		fdc_setmedia(0, wID - IDM_D0MEDIA00);
#ifdef XM7DASH
		SetMRUMedia(MRU_MFD0, fdc_media[0]);
#endif
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		ResetSch();
		UnlockVM();
	}
	if ((wID >= IDM_D1MEDIA00) && (wID <= IDM_D1MEDIA15)) {
		LockVM();
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		fdc_setmedia(FDC_M, 1, wID - IDM_D1MEDIA00);
		SetMRUMedia(MRU_MFD1, fdc_media[FDC_M][1]);
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		fdc_setmedia(1, wID - IDM_D1MEDIA00);
#ifdef XM7DASH
		SetMRUMedia(MRU_MFD1, fdc_media[1]);
#endif
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		ResetSch();
		UnlockVM();
	}
#ifdef XM7DASH
	if ((wID >= IDM_D2MEDIA00) && (wID <= IDM_D2MEDIA15)) {
		LockVM();
#if XM7_VER == 1 && defined(SFDC)
		fdc_setmedia(FDC_M, 2, wID - IDM_D2MEDIA00);
		SetMRUMedia(MRU_MFD2, fdc_media[FDC_M][2]);
#else	/* XM7_VER == 1 && defined(SFDC) */
		fdc_setmedia(2, wID - IDM_D2MEDIA00);
#ifdef XM7DASH
		SetMRUMedia(MRU_MFD2, fdc_media[2]);
#endif
#endif	/* XM7_VER == 1 && defined(SFDC) */
		ResetSch();
		UnlockVM();
	}
	if ((wID >= IDM_D3MEDIA00) && (wID <= IDM_D3MEDIA15)) {
		LockVM();
#if XM7_VER == 1 && defined(SFDC)
		fdc_setmedia(FDC_M, 3, wID - IDM_D3MEDIA00);
		SetMRUMedia(MRU_MFD3, fdc_media[FDC_M][3]);
#else	/* XM7_VER == 1 && defined(SFDC) */
		fdc_setmedia(3, wID - IDM_D3MEDIA00);
#ifdef XM7DASH
		SetMRUMedia(MRU_MFD3, fdc_media[3]);
#endif
#endif	/* XM7_VER == 1 && defined(SFDC) */
		ResetSch();
		UnlockVM();
	}
#endif
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	if ((wID >= IDM_D4MEDIA00) && (wID <= IDM_D4MEDIA15)) {
		LockVM();
		fdc_setmedia(FDC_S, 0, wID - IDM_D4MEDIA00);
		SetMRUMedia(MRU_SFD0, fdc_media[FDC_S][0]);
		ResetSch();
		UnlockVM();
	}
	if ((wID >= IDM_D5MEDIA00) && (wID <= IDM_D5MEDIA15)) {
		LockVM();
		fdc_setmedia(FDC_S, 1, wID - IDM_D5MEDIA00);
		SetMRUMedia(MRU_SFD1, fdc_media[FDC_S][1]);
		ResetSch();
		UnlockVM();
	}
	if ((wID >= IDM_D6MEDIA00) && (wID <= IDM_D6MEDIA15)) {
		LockVM();
		fdc_setmedia(FDC_S, 2, wID - IDM_D6MEDIA00);
		SetMRUMedia(MRU_SFD2, fdc_media[FDC_S][2]);
		ResetSch();
		UnlockVM();
	}
	if ((wID >= IDM_D7MEDIA00) && (wID <= IDM_D7MEDIA15)) {
		LockVM();
		fdc_setmedia(FDC_S, 3, wID - IDM_D7MEDIA00);
		SetMRUMedia(MRU_SFD3, fdc_media[FDC_S][3]);
		ResetSch();
		UnlockVM();
	}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */

#ifdef XM7DASH
	/* ���X�g����Z�b�g */
#if XM7_VER == 1 && defined(SFDC)
	if (((wID >= IDM_D3_FILE0) && (wID <= IDM_D0_FILE9)) ||
		((wID >= IDM_D7_FILE0) && (wID <= IDM_D4_FILE9))) {
#else	/* XM7_VER == 1 && defined(SFDC) */
	if ((wID >= IDM_D3_FILE0) && (wID <= IDM_D0_FILE9)) {
#endif	/* XM7_VER == 1 && defined(SFDC) */
		char path[256 + 1];
#if XM7_VER == 1 && defined(SFDC)
		int type;
#endif	/* XM7_VER == 1 && defined(SFDC) */
		int drive;
		int mrutype;
		int index;
		int media;

		if ((wID >= IDM_D0_FILE0) && (wID <= IDM_D0_FILE9)) {
#if XM7_VER == 1 && defined(SFDC)
			type	= FDC_M;
#endif	/* XM7_VER == 1 && defined(SFDC) */
			drive	= 0;
			mrutype	= MRU_MFD0;
			index	= wID - IDM_D0_FILE0;
		}
		if ((wID >= IDM_D1_FILE0) && (wID <= IDM_D1_FILE9)) {
#if XM7_VER == 1 && defined(SFDC)
			type	= FDC_M;
#endif	/* XM7_VER == 1 && defined(SFDC) */
			drive	= 1;
			mrutype	= MRU_MFD1;
			index	= wID - IDM_D1_FILE0;
		}
		if ((wID >= IDM_D2_FILE0) && (wID <= IDM_D2_FILE9)) {
#if XM7_VER == 1 && defined(SFDC)
			type	= FDC_M;
#endif	/* XM7_VER == 1 && defined(SFDC) */
			drive	= 2;
			mrutype	= MRU_MFD2;
			index	= wID - IDM_D2_FILE0;
		}
		if ((wID >= IDM_D3_FILE0) && (wID <= IDM_D3_FILE9)) {
#if XM7_VER == 1 && defined(SFDC)
			type	= FDC_M;
#endif	/* XM7_VER == 1 && defined(SFDC) */
			drive	= 3;
			mrutype	= MRU_MFD3;
			index	= wID - IDM_D3_FILE0;
		}
#if XM7_VER == 1 && defined(SFDC)
		if ((wID >= IDM_D4_FILE0) && (wID <= IDM_D4_FILE9)) {
			type	= FDC_S;
			drive	= 0;
			mrutype	= MRU_SFD0;
			index	= wID - IDM_D4_FILE0;
		}
		if ((wID >= IDM_D5_FILE0) && (wID <= IDM_D5_FILE9)) {
			type	= FDC_S;
			drive	= 1;
			mrutype	= MRU_SFD1;
			index	= wID - IDM_D5_FILE0;
		}
		if ((wID >= IDM_D6_FILE0) && (wID <= IDM_D6_FILE9)) {
			type	= FDC_S;
			drive	= 2;
			mrutype	= MRU_SFD2;
			index	= wID - IDM_D6_FILE0;
		}
		if ((wID >= IDM_D7_FILE0) && (wID <= IDM_D7_FILE9)) {
			type	= FDC_S;
			drive	= 3;
			mrutype	= MRU_SFD3;
			index	= wID - IDM_D7_FILE0;
		}
#endif	/* XM7_VER == 1 && defined(SFDC) */

		GetMRUFile(mrutype, index, path, sizeof(path));
		media = GetMRUMedia(mrutype, index);

		LockVM();
#if XM7_VER == 1 && defined(SFDC)
		fdc_setdisk(type, drive, path);
		if (fdc_ready[type][drive] != FDC_TYPE_NOTREADY) {
			SetMRUFile(mrutype, fdc_fname[type][drive]);
			if (fdc_ready[type][drive] == FDC_TYPE_D77) {
				if (media >= 0) {
					fdc_setmedia(type, drive, media);
				}
				SetMRUMedia(mrutype, fdc_media[type][drive]);
			}
		}
#else	/* XM7_VER == 1 && defined(SFDC) */
		fdc_setdisk(drive, path);
		if (fdc_ready[drive] != FDC_TYPE_NOTREADY) {
			SetMRUFile(mrutype, fdc_fname[drive]);
			if (fdc_ready[drive] == FDC_TYPE_D77) {
				if (media >= 0) {
					fdc_setmedia(drive, media);
				}
				SetMRUMedia(mrutype, fdc_media[drive]);
			}
		}
#endif	/* XM7_VER == 1 && defined(SFDC) */
		else {
			FileMessageBox(hMainWnd, IDS_FILE_NOT_FOUND, path, MB_ICONSTOP | MB_OK);
			SetMenuExitTimer();
		}
		ResetSch();
		UnlockVM();

		/* �\�����e���X�V */
		if (hMainWnd) {
			OnSize(hMainWnd, 640, 400);
		}
	}
#endif	/* XM7DASH */

	return FALSE;
}

/*
 *	�f�B�X�N(1)(0)���j���[�X�V
 */
#ifdef XM7DASH
 #if XM7_VER == 1 && defined(SFDC)
static void FASTCALL OnDiskPopup(HMENU hMenu, int Type)
 #else	/* XM7_VER == 1 && defined(SFDC) */
static void FASTCALL OnDiskPopup(HMENU hMenu)
 #endif	/* XM7_VER == 1 && defined(SFDC) */
#else
static void FASTCALL OnDiskPopup(HMENU hMenu, int Drive)
#endif
{
#ifdef XM7DASH
	HMENU hSubMenu;
	MENUITEMINFO mii;
	char string[256];
	char buffer[256];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	UINT uitem;
	int drive;
	int offset;
	int i;
	int j;
	int k;
	BOOL enable = TRUE;

	ASSERT(hMenu);
#if XM7_VER == 1 && defined(SFDC)
	ASSERT((Type == FDC_M) || (Type == FDC_S));
#endif	/* XM7_VER == 1 && defined(SFDC) */

#if 0
	/* ���j���[���ׂč폜 */
	while (GetMenuItemCount(hMenu) > 0) {
		DeleteMenu(hMenu, 0, MF_BYPOSITION);
	}
#endif

	/* �I�t�Z�b�g�m�� */
#if XM7_VER == 1 && defined(SFDC)
	if (Type == FDC_S) {
		enable = sfdc_enable;
	}
#endif	/* XM7_VER == 1 && defined(SFDC) */

	/* ���j���[�\���̏����� */
	memset(&mii, 0, sizeof(mii));
	mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
	mii.fType = MFT_STRING;
	if (enable) {
		mii.fState = MFS_ENABLED;
	}
	else {
		mii.fState = MFS_GRAYED;
	}

	for(drive = 0; drive < 4; drive ++) {

#if 0
		/* �I�t�Z�b�g�m�� */
		offset = (IDM_D1OPEN - IDM_D0OPEN) * drive;
#if XM7_VER == 1 && defined(SFDC)
		if (Type != FDC_M) {
			offset += IDM_D4OPEN - IDM_D0OPEN;
		}
#endif	/* XM7_VER == 1 && defined(SFDC) */
#endif

		/* �h���C�un */
#if 0
		if (!enable ||
#if XM7_VER == 1 && defined(SFDC)
			fdc_ready[Type][drive] == FDC_TYPE_NOTREADY) {
#else	/* XM7_VER == 1 && defined(SFDC) */
			fdc_ready[drive] == FDC_TYPE_NOTREADY) {
#endif	/* XM7_VER == 1 && defined(SFDC) */
			mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
			mii.wID = IDM_D0OPEN + offset;
			LoadString(hResInstance, IDS_DISK0OPEN + drive, string, sizeof(string));
		}
		else
#endif
		{
#if 0
			if (!enable) {
				mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
			}
			else
#endif
			{
				mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID | MIIM_SUBMENU;
			}
			mii.wID = 0;
			//mii.hSubMenu = CreatePopupMenu();
			mii.hSubMenu = GetSubMenu(hMenu, drive);
#ifdef XM7DASH
			LoadString(hResInstance, IDS_DISK0 + drive, buffer, sizeof(buffer));
			if ((enable) &&
 #if XM7_VER == 1 && defined(SFDC)
				(fdc_ready[Type][drive] != FDC_TYPE_NOTREADY)) {
				_splitpath(fdc_fname[Type][drive], NULL, NULL, fname, ext);
 #else	/* XM7_VER == 1 && defined(SFDC) */
				(fdc_ready[drive] != FDC_TYPE_NOTREADY)) {
				_splitpath(fdc_fname[drive], NULL, NULL, fname, ext);
 #endif	/* XM7_VER == 1 && defined(SFDC) */
				_snprintf(string, sizeof(string), "%s - %s%s", buffer, fname,
						  ext);
			}
			else {
				strncpy(string, buffer, sizeof(string));
			}
#else
			LoadString(hResInstance, IDS_DISK0 + drive, string, sizeof(string));
#endif
		}
		mii.dwTypeData = string;
		mii.cch = strlen(string);
		RemoveMenu(hMenu, drive, MF_BYPOSITION);
		InsertMenuItem(hMenu, drive, TRUE, &mii);
	}

#if 0
	/* �Z�p���[�^�}�� */
	mii.fType = MFT_SEPARATOR;
	InsertMenuItem(hMenu, 4, TRUE, &mii);
	mii.fType = MFT_STRING;

	/* ���I�[�v�� */
	mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
#if XM7_VER == 1 && defined(SFDC)
	if (Type == FDC_M) {
		mii.wID = IDM_DBOPEN;
	}
	else {
		mii.wID = IDM_DB45OPEN;
	}
#else	/* XM7_VER == 1 && defined(SFDC) */
	mii.wID = IDM_DBOPEN;
#endif	/* XM7_VER == 1 && defined(SFDC) */
	LoadString(hResInstance, IDS_DISKBOTH, string, sizeof(string));
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, 5, TRUE, &mii);

	/* 2,3�I�[�v�� */
#if XM7_VER == 1 && defined(SFDC)
	if (Type == FDC_M) {
		mii.wID = IDM_DB23OPEN;
	}
	else {
		mii.wID = IDM_DB67OPEN;
	}
#else	/* XM7_VER == 1 && defined(SFDC) */
	mii.wID = IDM_DB23OPEN;
#endif	/* XM7_VER == 1 && defined(SFDC) */
	LoadString(hResInstance, IDS_DISKBOTH23, string, sizeof(string));
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, 6, TRUE, &mii);

	/* �����C�W�F�N�g */
#if XM7_VER == 1 && defined(SFDC)
	if (Type == FDC_M) {
		mii.wID = IDM_MFD_EJECT;
		LoadString(hResInstance, IDS_MFD_EJECT, string, sizeof(string));
	}
	else {
		mii.wID = IDM_SFD_EJECT;
		LoadString(hResInstance, IDS_SFD_EJECT, string, sizeof(string));
	}
#else	/* XM7_VER == 1 && defined(SFDC) */
	mii.wID = IDM_MFD_EJECT;
	LoadString(hResInstance, IDS_MFD_EJECT, string, sizeof(string));
#endif	/* XM7_VER == 1 && defined(SFDC) */
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, 7, TRUE, &mii);
#endif

	/* �T�u���j���[ */
	for(drive = 0; drive < 4; drive ++) {

#if 0
#if 0
		/* �f�B�X�N���}������Ă��Ȃ���΁A�����܂� */
#if XM7_VER == 1 && defined(SFDC)
		if (fdc_ready[Type][drive] == FDC_TYPE_NOTREADY || !enable) {
#else	/* XM7_VER == 1 && defined(SFDC) */
		if (fdc_ready[drive] == FDC_TYPE_NOTREADY || !enable) {
#endif	/* XM7_VER == 1 && defined(SFDC) */
#else
		if (!enable) {
#endif
			continue;
		}
#endif

		hSubMenu = GetSubMenu(hMenu, drive);

		/* ���j���[���ׂč폜 */
		while (GetMenuItemCount(hSubMenu) > 0) {
			DeleteMenu(hSubMenu, 0, MF_BYPOSITION);
		}

		/* �I�t�Z�b�g�m�� */
		offset = (IDM_D1OPEN - IDM_D0OPEN) * drive;
#if XM7_VER == 1 && defined(SFDC)
		if (Type != FDC_M) {
			offset += IDM_D4OPEN - IDM_D0OPEN;
		}
#endif	/* XM7_VER == 1 && defined(SFDC) */
		uitem = 0;

		/* ���j���[�\���̏����� */
		memset(&mii, 0, sizeof(mii));
		mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
		mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
		mii.fType = MFT_STRING;

		/* �I�[�v�� */
		mii.wID = IDM_D0OPEN + offset;
		LoadString(hResInstance, IDS_DISKOPEN, string, sizeof(string));
		mii.dwTypeData = string;
#if XM7_VER == 1 && defined(SFDC)
		if ((Type == FDC_S) && (fdc_doorlock[drive])) {
			mii.fState = MFS_GRAYED;
		}
		else {
			mii.fState = MFS_ENABLED;
		}
#else	/* XM7_VER == 1 && defined(SFDC) */
		mii.fState = MFS_ENABLED;
#endif	/* XM7_VER == 1 && defined(SFDC) */
		mii.cch = strlen(string);
		InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

		/* �C�W�F�N�g */
		mii.wID = IDM_D0EJECT + offset;
#if XM7_VER == 1 && defined(SFDC)
		if ((fdc_ready[Type][drive] == FDC_TYPE_NOTREADY) ||
			((Type == FDC_S) && (fdc_doorlock[drive]))) {
#else	/* XM7_VER == 1 && defined(SFDC) */
		if (fdc_ready[drive] == FDC_TYPE_NOTREADY) {
#endif	/* XM7_VER == 1 && defined(SFDC) */
			mii.fState = MFS_GRAYED;
		}
		else {
			mii.fState = MFS_ENABLED;
		}
		LoadString(hResInstance, IDS_DISKEJECT, string, sizeof(string));
		mii.cch = strlen(string);
		InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

#if 0
		/* �Z�p���[�^�}�� */
		mii.fType = MFT_SEPARATOR;
		InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

		/* �ꎞ���o�� */
		mii.wID = IDM_D0TEMP + offset;
		LoadString(hResInstance, IDS_DISKTEMP, string, sizeof(string));
#if XM7_VER == 1 && defined(SFDC)
		if ((fdc_ready[Type][drive] == FDC_TYPE_NOTREADY) ||
			((Type == FDC_S) && (fdc_doorlock[drive]))) {
			mii.fState = MFS_GRAYED;
		}
		else if (fdc_teject[Type][drive]) {
			mii.fState = MFS_CHECKED | MFS_ENABLED;
		}
#else	/* XM7_VER == 1 && defined(SFDC) */
		if (fdc_ready[drive] == FDC_TYPE_NOTREADY) {
			mii.fState = MFS_GRAYED;
		}
		else if (fdc_teject[drive]) {
			mii.fState = MFS_CHECKED | MFS_ENABLED;
		}
#endif	/* XM7_VER == 1 && defined(SFDC) */
		else {
			mii.fState = MFS_ENABLED;
		}
		mii.fType = MFT_STRING;
		mii.cch = strlen(string);
		InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);
#endif

		/* ���C�g�v���e�N�g */
		mii.wID = IDM_D0WRITE + offset;
		LoadString(hResInstance, IDS_DISKPROTECT, string, sizeof(string));
#if XM7_VER == 1 && defined(SFDC)
		if (fdc_ready[Type][drive] == FDC_TYPE_NOTREADY) {
#else	/* XM7_VER == 1 && defined(SFDC) */
		if (fdc_ready[drive] == FDC_TYPE_NOTREADY) {
#endif	/* XM7_VER == 1 && defined(SFDC) */
			mii.fState = MFS_GRAYED;
		}
		else {
#if XM7_VER == 1 && defined(SFDC)
			if (((Type == FDC_S) && (fdc_doorlock[drive])) ||
				(fdc_fwritep[Type][drive])) {
#else	/* XM7_VER == 1 && defined(SFDC) */
			if (fdc_fwritep[drive]) {
#endif	/* XM7_VER == 1 && defined(SFDC) */
				mii.fState = MFS_GRAYED;
			}
			else {
				mii.fState = MFS_ENABLED;
			}
#if XM7_VER == 1 && defined(SFDC)
			if ((fdc_fwritep[Type][drive]) || (fdc_writep[Type][drive])) {
#else	/* XM7_VER == 1 && defined(SFDC) */
			if ((fdc_fwritep[drive]) || (fdc_writep[drive])) {
#endif	/* XM7_VER == 1 && defined(SFDC) */
				mii.fState |= MFS_CHECKED;
			}
		}
		mii.fType = MFT_STRING;
		mii.cch = strlen(string);
		InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

#if XM7_VER == 1 && defined(SFDC)
		if (Type == FDC_S) {
			/* �Z�p���[�^�}�� */
			mii.fType = MFT_SEPARATOR;
			InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

			/* �����C�W�F�N�g */
			mii.wID = IDM_D0FORCE + offset;
			LoadString(hResInstance, IDS_DISKFORCE, string, sizeof(string));
			if ((fdc_ready[Type][drive] == FDC_TYPE_NOTREADY) ||
				(!fdc_doorlock[drive])) {
				mii.fState = MFS_GRAYED;
			}
			else {
				mii.fState = MFS_ENABLED;
			}
			mii.fType = MFT_STRING;
			mii.cch = strlen(string);
			InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);
		}
#endif	/* XM7_VER == 1 && defined(SFDC) */

#if 0	/* 2D/2DD/2HD/VFD�t�@�C�����͏�w�ɕ\�������̂ō폜 */
		/* 2D/2DD/2HD/VFD�Ȃ���ꏈ�� */
#if XM7_VER == 1 && defined(SFDC)
		if ((fdc_ready[Type][drive] == FDC_TYPE_2D) ||
			(fdc_ready[Type][drive] == FDC_TYPE_2HD) ||
			(fdc_ready[Type][drive] == FDC_TYPE_VFD)) {
#else	/* XM7_VER == 1 && defined(SFDC) */
		if ((fdc_ready[drive] == FDC_TYPE_2D) ||
#if XM7_VER >= 3
			(fdc_ready[drive] == FDC_TYPE_2DD) ||
#endif
			(fdc_ready[drive] == FDC_TYPE_VFD)) {
#endif	/* XM7_VER == 1 && defined(SFDC) */

			/* �Z�p���[�^�}�� */
			mii.fType = MFT_SEPARATOR;
			InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

			mii.wID = IDM_D0MEDIA00 + offset;
			mii.fState = MFS_CHECKED | MFS_ENABLED;
			mii.fType = MFT_STRING | MFT_RADIOCHECK;
#if XM7_VER == 1 && defined(SFDC)
			if (fdc_ready[Type][drive] == FDC_TYPE_2D) {
#else	/* XM7_VER == 1 && defined(SFDC) */
			if (fdc_ready[drive] == FDC_TYPE_2D) {
#endif	/* XM7_VER == 1 && defined(SFDC) */
				LoadString(hResInstance, IDS_DISK2D, string, sizeof(string));
			}
#if XM7_VER == 1 && defined(SFDC)
			else if (fdc_ready[Type][drive] == FDC_TYPE_2HD) {
				LoadString(hResInstance, IDS_DISK2HD, string, sizeof(string));
			}
#endif	/* XM7_VER == 1 && defined(SFDC) */
#if XM7_VER >= 3
			else if (fdc_ready[drive] == FDC_TYPE_2DD) {
				LoadString(hResInstance, IDS_DISK2DD, string, sizeof(string));
			}
#endif
			else {
				LoadString(hResInstance, IDS_DISKVFD, string, sizeof(string));
			}
			mii.cch = strlen(string);
			InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);
		}
#endif

		/* D77�Ȃ烁�f�B�A���� */
#if XM7_VER == 1 && defined(SFDC)
		if (fdc_ready[Type][drive] == FDC_TYPE_D77) {
#else	/* XM7_VER == 1 && defined(SFDC) */
		if (fdc_ready[drive] == FDC_TYPE_D77) {
#endif	/* XM7_VER == 1 && defined(SFDC) */

			/* �Z�p���[�^�}�� */
			mii.fType = MFT_SEPARATOR;
			InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

#if XM7_VER == 1 && defined(SFDC)
			for (i=0; i<fdc_medias[Type][drive]; i++) {
#else	/* XM7_VER == 1 && defined(SFDC) */
			for (i=0; i<fdc_medias[drive]; i++) {
#endif	/* XM7_VER == 1 && defined(SFDC) */
				mii.wID = IDM_D0MEDIA00 + offset + i;
#if XM7_VER == 1 && defined(SFDC)
				if ((Type == FDC_S) && fdc_doorlock[drive]) {
					mii.fState = MFS_GRAYED;
				}
				else {
					mii.fState = MFS_ENABLED;
				}
				if (fdc_media[Type][drive] == i) {
					mii.fState |= MFS_CHECKED;
				}
#else	/* XM7_VER == 1 && defined(SFDC) */
				mii.fState = MFS_ENABLED;
				if (fdc_media[drive] == i) {
					mii.fState |= MFS_CHECKED;
				}
#endif	/* XM7_VER == 1 && defined(SFDC) */
				mii.fType = MFT_STRING | MFT_RADIOCHECK;
#if XM7_VER == 1 && defined(SFDC)
				if (strlen(fdc_name[Type][drive][i]) == 0) {
#else	/* XM7_VER == 1 && defined(SFDC) */
				if (strlen(fdc_name[drive][i]) == 0) {
#endif	/* XM7_VER == 1 && defined(SFDC) */
					LoadString(hResInstance, IDS_MEDIA_NAME, buffer, sizeof(buffer));
					_snprintf(string, sizeof(string), buffer, i + 1);
				}
				else {
					/* �v���t�B�b�N�X�����΍� */
					k = 0;
#if XM7_VER == 1 && defined(SFDC)
					for (j=0; j<(int)strlen(fdc_name[Type][drive][i]); j++) {
						if (fdc_name[Type][drive][i][j] == '&') {
							string[k++] = '&';
						}
						string[k++] = fdc_name[Type][drive][i][j];
					}
#else	/* XM7_VER == 1 && defined(SFDC) */
					for (j=0; j<(int)strlen(fdc_name[drive][i]); j++) {
						if (fdc_name[drive][i][j] == '&') {
							string[k++] = '&';
						}
						string[k++] = fdc_name[drive][i][j];
					}
#endif	/* XM7_VER == 1 && defined(SFDC) */
					string[k] = '\0';
				}
				mii.cch = strlen(string);
				InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);
			}
		}

		/* ����}�� */
		{
			UINT uID = IDM_D0_FILE0 - drive * 10;
			int type = MRU_MFD0 + drive;
			BOOL enable2 = enable;
#if XM7_VER == 1 && defined(SFDC)
			if (Type == FDC_S) {
				uID = IDM_D4_FILE0 - drive * 10;
				type = MRU_SFD0 + drive;
				if (fdc_doorlock[drive]) {
					enable2 = FALSE;
				}
			}
#endif	/* XM7_VER == 1 && defined(SFDC) */
			AppendMenuHistory(hSubMenu, uitem, uID, type, enable2);
		}
	}
#else
	MENUITEMINFO mii;
	char string[128];
	char buffer[128];
	int offset;
	int i;
	int j;
	int k;

	ASSERT(hMenu);
	ASSERT((Drive == 0) || (Drive == 1));

	/* ���j���[���ׂč폜 */
	while (GetMenuItemCount(hMenu) > 0) {
		DeleteMenu(hMenu, 0, MF_BYPOSITION);
	}

	/* �I�t�Z�b�g�m�� */
	if (Drive == 0) {
		offset = 0;
	}
	else {
		offset = IDM_D1OPEN - IDM_D0OPEN;
	}

	/* ���j���[�\���̏����� */
	memset(&mii, 0, sizeof(mii));
	mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
	mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
	mii.fType = MFT_STRING;
	mii.fState = MFS_ENABLED;

	/* �I�[�v���ƁA���I�[�v�� */
	mii.wID = IDM_D0OPEN + offset;
	LoadString(hResInstance, IDS_DISKOPEN, string, sizeof(string));
	mii.dwTypeData = string;
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, 0, TRUE, &mii);
	mii.wID = IDM_DBOPEN;
	LoadString(hResInstance, IDS_DISKBOTH, string, sizeof(string));
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, 1, TRUE, &mii);

	/* �f�B�X�N���}������Ă��Ȃ���΁A�����܂� */
	if (fdc_ready[Drive] == FDC_TYPE_NOTREADY) {
		return;
	}

	/* �C�W�F�N�g */
	mii.wID = IDM_D0EJECT + offset;
	LoadString(hResInstance, IDS_DISKEJECT, string, sizeof(string));
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, 2, TRUE, &mii);

	/* �Z�p���[�^�}�� */
	mii.fType = MFT_SEPARATOR;
	InsertMenuItem(hMenu, 3, TRUE, &mii);

	/* �ꎞ���o�� */
	mii.wID = IDM_D0TEMP + offset;
	LoadString(hResInstance, IDS_DISKTEMP, string, sizeof(string));
	if (fdc_teject[Drive]) {
		mii.fState = MFS_CHECKED | MFS_ENABLED;
	}
	else {
		mii.fState = MFS_ENABLED;
	}
	mii.fType = MFT_STRING;
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, 4, TRUE, &mii);

	/* ���C�g�v���e�N�g */
	mii.wID = IDM_D0WRITE + offset;
	LoadString(hResInstance, IDS_DISKPROTECT, string, sizeof(string));
	if (fdc_fwritep[Drive]) {
		mii.fState = MFS_GRAYED;
	}
	else {
		if (fdc_writep[Drive]) {
			mii.fState = MFS_CHECKED | MFS_ENABLED;
		}
		else {
			mii.fState = MFS_ENABLED;
		}
	}
	mii.fType = MFT_STRING;
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, 5, TRUE, &mii);

	/* �Z�p���[�^�}�� */
	mii.fType = MFT_SEPARATOR;
	InsertMenuItem(hMenu, 6, TRUE, &mii);

	/* 2D/2DD/VFD�Ȃ���ꏈ�� */
	if ((fdc_ready[Drive] == FDC_TYPE_2D) ||
#if XM7_VER >= 3
		(fdc_ready[Drive] == FDC_TYPE_2DD) ||
#endif
		(fdc_ready[Drive] == FDC_TYPE_VFD)) {
		mii.wID = IDM_D0MEDIA00 + offset;
		mii.fState = MFS_CHECKED | MFS_ENABLED;
		mii.fType = MFT_STRING | MFT_RADIOCHECK;
		if (fdc_ready[Drive] == FDC_TYPE_2D) {
			LoadString(hResInstance, IDS_DISK2D, string, sizeof(string));
		}
#if XM7_VER >= 3
		else if (fdc_ready[Drive] == FDC_TYPE_2DD) {
			LoadString(hResInstance, IDS_DISK2DD, string, sizeof(string));
		}
#endif
		else {
			LoadString(hResInstance, IDS_DISKVFD, string, sizeof(string));
		}
		mii.cch = strlen(string);
		InsertMenuItem(hMenu, 7, TRUE, &mii);
		return;
	}

	/* ���f�B�A���� */
	for (i=0; i<fdc_medias[Drive]; i++) {
		mii.wID = IDM_D0MEDIA00 + offset + i;
		if (fdc_media[Drive] == i) {
			mii.fState = MFS_CHECKED | MFS_ENABLED;
		}
		else {
			mii.fState = MFS_ENABLED;
		}
		mii.fType = MFT_STRING | MFT_RADIOCHECK;
		if (strlen(fdc_name[Drive][i]) == 0) {
			LoadString(hResInstance, IDS_MEDIA_NAME, buffer, sizeof(buffer));
			/* 128�o�C�g�𒴂��Ȃ��Ƃ͎v���̂����c */
			_snprintf(string, 128, buffer, i + 1);
		}
		else {
			/* �v���t�B�b�N�X�����΍� */
			k = 0;
			for (j=0; j<(int)strlen(fdc_name[Drive][i]); j++) {
				if (fdc_name[Drive][i][j] == '&') {
					string[k++] = '&';
				}
				string[k++] = fdc_name[Drive][i][j];
			}
			string[k] = '\0';
		}
		mii.cch = strlen(string);
		InsertMenuItem(hMenu, 7 + i, TRUE, &mii);
	}
#endif
}

#ifdef XM7DASH
/*
 *	�f�B�X�N(1)(0)�R���e�L�X�g���j���[
 */
static BOOL FASTCALL OnDiskContextualMenu(HWND hWnd, WORD wID, int x, int y)
{
	ASSERT(hWnd);

	/* �f�B�X�N�E�N���b�N���j���[���� */
	if ((wID >= IDM_D0MEDIA00) && (wID <= IDM_D0MEDIA15)) {
		OnContextualSubMenu(hWnd, hMediaMenu, wID, x, y);
		return TRUE;
	}
	if ((wID >= IDM_D1MEDIA00) && (wID <= IDM_D1MEDIA15)) {
		OnContextualSubMenu(hWnd, hMediaMenu, wID, x, y);
		return TRUE;
	}
	if ((wID >= IDM_D2MEDIA00) && (wID <= IDM_D2MEDIA15)) {
		OnContextualSubMenu(hWnd, hMediaMenu, wID, x, y);
		return TRUE;
	}
	if ((wID >= IDM_D3MEDIA00) && (wID <= IDM_D3MEDIA15)) {
		OnContextualSubMenu(hWnd, hMediaMenu, wID, x, y);
		return TRUE;
	}
#if XM7_VER == 1 && defined(SFDC)
	if ((wID >= IDM_D4MEDIA00) && (wID <= IDM_D4MEDIA15)) {
		OnContextualSubMenu(hWnd, hMediaMenu, wID, x, y);
		return TRUE;
	}
	if ((wID >= IDM_D5MEDIA00) && (wID <= IDM_D5MEDIA15)) {
		OnContextualSubMenu(hWnd, hMediaMenu, wID, x, y);
		return TRUE;
	}
	if ((wID >= IDM_D6MEDIA00) && (wID <= IDM_D6MEDIA15)) {
		OnContextualSubMenu(hWnd, hMediaMenu, wID, x, y);
		return TRUE;
	}
	if ((wID >= IDM_D7MEDIA00) && (wID <= IDM_D7MEDIA15)) {
		OnContextualSubMenu(hWnd, hMediaMenu, wID, x, y);
		return TRUE;
	}
#endif	/* XM7_VER == 1 && defined(SFDC) */

	/* �q�X�g�� */
	if ((wID >= IDM_D3_FILE0) && (wID <= IDM_D0_FILE9)) {
		OnContextualSubMenu(hWnd, hHistoryMenu, wID, x, y);
		return TRUE;
	}
#if XM7_VER == 1 && defined(SFDC)
	if ((wID >= IDM_D7_FILE0) && (wID <= IDM_D4_FILE9)) {
		OnContextualSubMenu(hWnd, hHistoryMenu, wID, x, y);
		return TRUE;
	}
#endif	/* XM7_VER == 1 && defined(SFDC) */

	return FALSE;
}
#endif

/*-[ �e�[�v���j���[ ]-------------------------------------------------------*/

/*
 *  �e�[�v�I�[�v��
 */
static void FASTCALL OnTapeOpen(void)
{
	char path[_MAX_PATH];

	/* �t�@�C���I�� */
	if (!FileSelectSub(TRUE, IDS_TAPEFILTER, path, NULL, 1)) {
		return;
	}

	/* �Z�b�g */
	LockVM();
	tape_setfile(path);
#ifdef XM7DASH
	if (tape_fileh != -1) {
		SetMRUFile(MRU_TAPE, tape_fname);
	}
#endif	/* XM7DASH */
	ResetSch();
	UnlockVM();
}

/*
 *	�e�[�v�C�W�F�N�g
 */
static void FASTCALL OnTapeEject(void)
{
	/* �C�W�F�N�g */
	LockVM();
	tape_setfile(NULL);
	UnlockVM();
}

/*
 *	�����߂�
 */
static void FASTCALL OnRew(void)
{
	HCURSOR hCursor;

	/* �����߂� */
	hCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));
	LockVM();
	StopSnd();

	tape_rew();

	PlaySnd();
	ResetSch();
	UnlockVM();
	SetCursor(hCursor);
}

/*
 *	������
 */
static void FASTCALL OnFF(void)
{
	HCURSOR hCursor;

	/* �����߂� */
	hCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));
	LockVM();
	StopSnd();

	tape_ff();

	PlaySnd();
	ResetSch();
	UnlockVM();
	SetCursor(hCursor);
}

/*
 *	�^��
 */
static void FASTCALL OnRec(void)
{
	/* �^�� */
	LockVM();
	if (tape_rec) {
		tape_setrec(FALSE);
	}
	else {
		tape_setrec(TRUE);
	}
	UnlockVM();
}

#if XM7_VER == 1 && defined(BUBBLE)
#ifdef XM7DASH
/*-[ �o�u�����j���[ ]-------------------------------------------------------*/

/*
 *  �o�u���I�[�v��
 */
static void FASTCALL OnBubbleOpen(int Type, int Unit)
{
	char path[_MAX_PATH];

	ASSERT((Type == BMC_32) || (Type == BMC_128));
	ASSERT((Unit == 0) || (Unit == 1));

	/* �t�@�C���I�� */
	if (!FileSelectSub(TRUE, IDS_BUBBLEFILTER, path, NULL, 5)) {
		return;
	}

	/* �Z�b�g */
	LockVM();
	bmc_setfile(Type, Unit, path);
	if (bmc_ready[Type][Unit] != BMC_TYPE_NOTREADY) {
		SetMRUFile(MRU_BBL0 + Unit + Type * 2, bmc_fname[Type][Unit]);
	}
	ResetSch();
	UnlockVM();
}

/*
 *  �����j�b�g�ŊJ��
 */
static void FASTCALL OnBubbleBoth(int Type, int Unit)
{
	char path[_MAX_PATH];

	ASSERT((Type == BMC_32) || (Type == BMC_128));
	ASSERT((Unit == 0) || (Unit == 1));

	/* �t�@�C���I�� */
	if (!FileSelectSub(TRUE, IDS_BUBBLEFILTER, path, NULL, 5)) {
		return;
	}

	/* �Z�b�g */
	LockVM();
	bmc_setfile(Type, Unit + 0, path);
	bmc_setfile(Type, Unit + 1, NULL);
	if (bmc_ready[Type][Unit] != BMC_TYPE_NOTREADY) {
		SetMRUFile(MRU_BBL0 + Unit + Type * 2, bmc_fname[Type][Unit]);
	}
	if ((bmc_ready[Type][Unit + 0] != BMC_TYPE_NOTREADY) && (bmc_medias[Type][Unit + 0] >= 2)) {
		bmc_setfile(Type, Unit + 1, path);
		bmc_setmedia(Type, Unit + 1, 1);
		if (bmc_ready[Type][Unit + 1] != BMC_TYPE_NOTREADY) {
			SetMRUFile(MRU_BBL0 + Unit + 1 + Type * 2, bmc_fname[Type][Unit + 1]);
			SetMRUMedia(MRU_BBL0 + Unit + 1 + Type * 2, bmc_media[Type][Unit + 1]);
		}
	}
	ResetSch();
	UnlockVM();
}

/*
 *	�����j�b�g����������
 */
static void FASTCALL OnBubbleReplace(int Type, int Unit)
{
	char cfname[256+1];	/* �t�@�C���� */
	BYTE nmedia;		/* ���f�B�A�Z���N�g��� */

	ASSERT((Type == BMC_32) || (Type == BMC_128));
	ASSERT((Unit == 0) || (Unit == 1));

	/* �Z�b�g */
	LockVM();
	if (bmc_ready[Type][Unit + 0] == BMC_TYPE_NOTREADY) {
		memset(cfname, 0, sizeof(cfname));
	}
	else {
		strncpy(cfname, bmc_fname[Type][Unit + 0], sizeof(cfname));
	}
	nmedia = bmc_media[Type][Unit + 0];
	if (bmc_ready[Type][Unit + 1] == BMC_TYPE_NOTREADY) {
		bmc_setfile(Type, Unit + 0, NULL);
	}
	else {
		bmc_setfile(Type, Unit + 0, bmc_fname[Type][Unit + 1]);
		bmc_setmedia(Type, Unit + 0, bmc_media[Type][Unit + 1]);
		if (bmc_ready[Type][Unit + 0] != BMC_TYPE_NOTREADY) {
			SetMRUFile(MRU_BBL0 + Unit + 0 + Type * 2, bmc_fname[Type][Unit + 0]);
			SetMRUMedia(MRU_BBL0 + Unit + 0 + Type * 2, bmc_media[Type][Unit + 0]);
		}
	}
	if (strlen(cfname) == 0) {
		bmc_setfile(Type, Unit + 1, NULL);
	}
	else {
		bmc_setfile(Type, Unit + 1, cfname);
		bmc_setmedia(Type, Unit + 1, nmedia);
		if (bmc_ready[Type][Unit + 1] != BMC_TYPE_NOTREADY) {
			SetMRUFile(MRU_BBL0 + Unit + 1 + Type * 2, bmc_fname[Type][Unit + 1]);
			SetMRUMedia(MRU_BBL0 + Unit + 1 + Type * 2, bmc_media[Type][Unit + 1]);
		}
	}
	ResetSch();
	UnlockVM();

	/* �\�����e���X�V */
	if (hMainWnd) {
		OnSize(hMainWnd, 640, 400);
	}
}

/*
 *	�o�u���C�W�F�N�g
 */
static void FASTCALL OnBubbleEject(int Type, int Unit)
{
	ASSERT((Type == BMC_32) || (Type == BMC_128));
	ASSERT((Unit == 0) || (Unit == 1));

	/* �C�W�F�N�g */
	LockVM();
	bmc_setfile(Type, Unit, NULL);
	UnlockVM();
}

#if 0
/*
 *	�o�u���ꎞ���o��
 */
static void FASTCALL OnBubbleTemp(int Type, int Unit)
{
	ASSERT((Type == BMC_32) || (Type == BMC_128));
	ASSERT((Unit == 0) || (Unit == 1));

	/* �������݋֎~�؂�ւ� */
	LockVM();
	if (bmc_teject[Type][Unit]) {
		bmc_teject[Type][Unit] = FALSE;
	}
	else {
		bmc_teject[Type][Unit] = TRUE;
	}
	UnlockVM();
}
#endif

/*
 *	�o�u���������݋֎~
 */
static void FASTCALL OnBubbleProtect(int Type, int Unit)
{
	ASSERT((Type == BMC_32) || (Type == BMC_128));
	ASSERT((Unit == 0) || (Unit == 1));

	/* �������݋֎~�؂�ւ� */
	LockVM();
	if (bmc_writep[Type][Unit]) {
		bmc_setwritep(Type, Unit, FALSE);
	}
	else {
		bmc_setwritep(Type, Unit, TRUE);
	}
	ResetSch();
	UnlockVM();
}
#else
/*
 *  �o�u���I�[�v��
 */
static void FASTCALL OnBubbleOpen(int unit)
{
	char path[_MAX_PATH];

	ASSERT ((unit == 0) || (unit == 1));

	/* �t�@�C���I�� */
	if (!FileSelectSub(TRUE, IDS_BUBBLEFILTER, path, NULL, 5)) {
		return;
	}

	/* �Z�b�g */
	LockVM();
	bmc_setfile(unit, path);
	bmc_setmedia(unit, 0);
	ResetSch();
	UnlockVM();
}


/*
 *  �����j�b�g�ŊJ��
 */
static void FASTCALL OnBubbleBoth(int unit)
{
	char path[_MAX_PATH];

	ASSERT((unit == 0) || (unit == 1));

	/* �t�@�C���I�� */
	if (!FileSelectSub(TRUE, IDS_BUBBLEFILTER, path, NULL, 5)) {
		return;
	}

	/* �Z�b�g */
	LockVM();
	bmc_setfile(unit + 0, path);
	bmc_setfile(unit + 1, NULL);
	bmc_setmedia(unit + 0, 0);
	if ((bmc_ready[unit] != BMC_TYPE_NOTREADY) && (bmc_medias[unit] >= 2)) {
		bmc_setfile(unit + 1, path);
		bmc_setmedia(unit + 1, 1);
	}
	ResetSch();
	UnlockVM();
}

/*
 *	�o�u���C�W�F�N�g
 */
static void FASTCALL OnBubbleEject(int unit)
{
	ASSERT((unit == 0) || (unit == 1));

	/* �C�W�F�N�g */
	LockVM();
	bmc_setfile(unit, NULL);
	UnlockVM();
}

/*
 *	�o�u���ꎞ���o��
 */
static void FASTCALL OnBubbleTemp(int unit)
{
	ASSERT((unit == 0) || (unit == 1));

	/* �������݋֎~�؂�ւ� */
	LockVM();
	if (bmc_teject[unit]) {
		bmc_teject[unit] = FALSE;
	}
	else {
		bmc_teject[unit] = TRUE;
	}
	UnlockVM();
}

/*
 *	�o�u���������݋֎~
 */
static void FASTCALL OnBubbleProtect(int unit)
{
	ASSERT((unit == 0) || (unit == 1));

	/* �������݋֎~�؂�ւ� */
	LockVM();
	if (bmc_writep[unit]) {
		bmc_setwritep(unit, FALSE);
	}
	else {
		bmc_setwritep(unit, TRUE);
	}
	ResetSch();
	UnlockVM();
}
#endif
#endif

#if XM7_VER == 1 && defined(BUBBLE) && defined(XM7DASH)
/*
 *	�S�C�W�F�N�g
 */
static void FASTCALL OnCasetteEject(void)
{
	int	i;

	/* �C�W�F�N�g */
	LockVM();
	tape_setfile(NULL);
	for (i=0; i<2; i++) {
		bmc_setfile(BMC_32, i, NULL);
		bmc_setfile(BMC_128, i, NULL);
	}
	UnlockVM();
}
#endif	/* XM7_VER == 1 && defined(BUBBLE) && defined(XM7DASH) */

/*
 *	�e�[�v(A)���j���[
 */
static BOOL FASTCALL OnTape(WORD wID)
{
	switch (wID) {
		/* �J�� */
		case IDM_TOPEN:
			OnTapeOpen();
			return TRUE;

		/* ���O�� */
		case IDM_TEJECT:
			OnTapeEject();
			return TRUE;

		/* �����߂� */
		case IDM_REW:
			OnRew();
			return TRUE;

		/* ������ */
		case IDM_FF:
			OnFF();
			return TRUE;

		/* �^�� */
		case IDM_REC:
			OnRec();
			return TRUE;

#if XM7_VER == 1 && defined(BUBBLE)
		/* �J�� */
#ifdef XM7DASH
		case IDM_B0OPEN:
			OnBubbleOpen(BMC_32, 0);
			return TRUE;
		case IDM_B1OPEN:
			OnBubbleOpen(BMC_32, 1);
			return TRUE;
		case IDM_B2OPEN:
			OnBubbleOpen(BMC_128, 0);
			return TRUE;
		case IDM_B3OPEN:
			OnBubbleOpen(BMC_128, 1);
			return TRUE;
#else
		case IDM_B0OPEN:
			OnBubbleOpen(0);
			return TRUE;
		case IDM_B1OPEN:
			OnBubbleOpen(1);
			return TRUE;
#endif

		/* �����j�b�g�ŊJ�� */
		case IDM_BBOPEN:
#ifdef XM7DASH
			OnBubbleBoth(BMC_32, 0);
#else
			OnBubbleBoth(0);
#endif
			break;
#ifdef XM7DASH
		case IDM_BB23OPEN:
			OnBubbleBoth(BMC_128, 0);
			break;
#endif

#ifdef XM7DASH
		/* �����j�b�g���������� */
		case IDM_BBREPLACE:
			OnBubbleReplace(BMC_32, 0);
			break;
		case IDM_BB23REPLACE:
			OnBubbleReplace(BMC_128, 0);
			break;
#endif	/* XM7DASH */

		/* ���O�� */
#ifdef XM7DASH
		case IDM_B0EJECT:
			OnBubbleEject(BMC_32, 0);
			return TRUE;
		case IDM_B1EJECT:
			OnBubbleEject(BMC_32, 1);
			return TRUE;
		case IDM_B2EJECT:
			OnBubbleEject(BMC_128, 0);
			return TRUE;
		case IDM_B3EJECT:
			OnBubbleEject(BMC_128, 1);
			return TRUE;
#else
		case IDM_B0EJECT:
			OnBubbleEject(0);
			return TRUE;
		case IDM_B1EJECT:
			OnBubbleEject(1);
			return TRUE;
#endif

		/* �ꎞ�C�W�F�N�g */
#ifdef XM7DASH
#if 0
		case IDM_B0TEMP:
			OnBubbleTemp(BMC_32, 0);
			return TRUE;
		case IDM_B1TEMP:
			OnBubbleTemp(BMC_32, 1);
			return TRUE;
		case IDM_B2TEMP:
			OnBubbleTemp(BMC_128, 0);
			return TRUE;
		case IDM_B3TEMP:
			OnBubbleTemp(BMC_128, 1);
			return TRUE;
#endif
#else
		case IDM_B0TEMP:
			OnBubbleTemp(0);
			return TRUE;
		case IDM_B1TEMP:
			OnBubbleTemp(1);
			return TRUE;
#endif

		/* �������݋֎~ */
#ifdef XM7DASH
		case IDM_B0WRITE:
			OnBubbleProtect(BMC_32, 0);
			return TRUE;
		case IDM_B1WRITE:
			OnBubbleProtect(BMC_32, 1);
			return TRUE;
		case IDM_B2WRITE:
			OnBubbleProtect(BMC_128, 0);
			return TRUE;
		case IDM_B3WRITE:
			OnBubbleProtect(BMC_128, 1);
			return TRUE;
#else
		case IDM_B0WRITE:
			OnBubbleProtect(0);
			return TRUE;
		case IDM_B1WRITE:
			OnBubbleProtect(1);
			return TRUE;
#endif

#ifdef XM7DASH
		/* �S�C�W�F�N�g */
		case IDM_CAS_EJECT:
			OnCasetteEject();
			break;
#endif
#endif
	}

#ifdef XM7DASH
	/* ���X�g����Z�b�g�i�e�[�v�j */
	if ((wID >= IDM_T_FILE0) && (wID <= IDM_T_FILE9)) {
		char path[256 + 1];

		GetMRUFile(MRU_TAPE, wID - IDM_T_FILE0, path, sizeof(path));

		LockVM();
		tape_setfile(path);
		if (tape_fileh != -1) {
			SetMRUFile(MRU_TAPE, tape_fname);
		}
		else {
			FileMessageBox(hMainWnd, IDS_FILE_NOT_FOUND, path, MB_ICONSTOP | MB_OK);
			SetMenuExitTimer();
		}
		ResetSch();
		UnlockVM();
	}
#endif

#if XM7_VER == 1 && defined(BUBBLE)
	/* ���f�B�A�����i�o�u���J�Z�b�g�j */
	if ((wID >= IDM_B0MEDIA00) && (wID <= IDM_B0MEDIA15)) {
		LockVM();
#ifdef XM7DASH
		bmc_setmedia(BMC_32, 0, wID - IDM_B0MEDIA00);
		SetMRUMedia(MRU_BBL0, bmc_media[BMC_32][0]);
#else
		bmc_setmedia(0, wID - IDM_B0MEDIA00);
#endif
		ResetSch();
		UnlockVM();
		return TRUE;
	}
	if ((wID >= IDM_B1MEDIA00) && (wID <= IDM_B1MEDIA15)) {
		LockVM();
#ifdef XM7DASH
		bmc_setmedia(BMC_32, 1, wID - IDM_B1MEDIA00);
		SetMRUMedia(MRU_BBL1, bmc_media[BMC_32][1]);
#else
		bmc_setmedia(1, wID - IDM_B1MEDIA00);
#endif
		ResetSch();
		UnlockVM();
		return TRUE;
	}
#ifdef XM7DASH
	if ((wID >= IDM_B2MEDIA00) && (wID <= IDM_B2MEDIA15)) {
		LockVM();
		bmc_setmedia(BMC_128, 0, wID - IDM_B2MEDIA00);
		SetMRUMedia(MRU_BBL128_0, bmc_media[BMC_128][0]);
		ResetSch();
		UnlockVM();
	}
	if ((wID >= IDM_B3MEDIA00) && (wID <= IDM_B3MEDIA15)) {
		LockVM();
		bmc_setmedia(BMC_128, 1, wID - IDM_B3MEDIA00);
		SetMRUMedia(MRU_BBL128_1, bmc_media[BMC_128][1]);
		ResetSch();
		UnlockVM();
	}
#endif

#ifdef XM7DASH
	/* ���X�g����Z�b�g�i�o�u���J�Z�b�g�j */
	if ((wID >= IDM_B3_FILE0) && (wID <= IDM_B0_FILE9)) {
		char path[256 + 1];
		int type;
		int unit;
		int mrutype;
		int index;
		int media;

		if ((wID >= IDM_B0_FILE0) && (wID <= IDM_B0_FILE9)) {
			type	= BMC_32;
			unit	= 0;
			mrutype	= MRU_BBL0;
			index	= wID - IDM_B0_FILE0;
		}
		if ((wID >= IDM_B1_FILE0) && (wID <= IDM_B1_FILE9)) {
			type	= BMC_32;
			unit	= 1;
			mrutype	= MRU_BBL1;
			index	= wID - IDM_B1_FILE0;
		}
		if ((wID >= IDM_B2_FILE0) && (wID <= IDM_B2_FILE9)) {
			type	= BMC_128;
			unit	= 0;
			mrutype	= MRU_BBL128_0;
			index	= wID - IDM_B2_FILE0;
		}
		if ((wID >= IDM_B3_FILE0) && (wID <= IDM_B3_FILE9)) {
			type	= BMC_128;
			unit	= 1;
			mrutype	= MRU_BBL128_1;
			index	= wID - IDM_B3_FILE0;
		}

		GetMRUFile(mrutype, index, path, sizeof(path));
		media = GetMRUMedia(mrutype, index);

		LockVM();
		bmc_setfile(type, unit, path);
		if (bmc_ready[type][unit] != BMC_TYPE_NOTREADY) {
			SetMRUFile(mrutype, bmc_fname[type][unit]);
			if (bmc_ready[type][unit] == BMC_TYPE_B77) {
				if (media >= 0) {
					bmc_setmedia(type, unit, media);
				}
				SetMRUMedia(mrutype, bmc_media[type][unit]);
			}
		}
		else {
			FileMessageBox(hMainWnd, IDS_FILE_NOT_FOUND, path, MB_ICONSTOP | MB_OK);
			SetMenuExitTimer();
		}
		ResetSch();
		UnlockVM();
	}
#endif
#endif

	return FALSE;
}

/*
 *	�e�[�v(A)���j���[�X�V
 */
static void FASTCALL OnTapePopup(HMENU hMenu)
{
#if XM7_VER == 1 && defined(BUBBLE) && !defined(XM7DASH)
	HMENU hSubMenu;
	MENUITEMINFO mii;
	char string[128];
	char buffer[256];
	UINT offset;
	UINT uitem;
	int unit;
	int i;
	int j;
	int k;

	ASSERT(hMenu);

	/* �J�Z�b�g���j���[��1�Ԗڂ̃T�u���j���[�n���h�����擾 */
	hSubMenu = GetSubMenu(hMenu, 0);

	/* ���j���[���ׂč폜 */
	while (GetMenuItemCount(hSubMenu) > 0) {
		DeleteMenu(hSubMenu, 0, MF_BYPOSITION);
	}

	/* ���j���[�\���̏����� */
	memset(&mii, 0, sizeof(mii));
	mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
	mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
	mii.fType = MFT_STRING;
	mii.fState = MFS_ENABLED;

	/* �J�� */
	mii.wID = IDM_TOPEN;
	LoadString(hResInstance, IDS_TAPEOPEN, string, sizeof(string));
	mii.dwTypeData = string;
	mii.cch = strlen(string);
	InsertMenuItem(hSubMenu, 0, TRUE, &mii);

	/* �e�[�v���Z�b�g����Ă��Ȃ���΁A�����܂� */
	if (tape_fileh != -1) {
		/* ���o�� */
		mii.wID = IDM_TEJECT;
		LoadString(hResInstance, IDS_TAPEEJECT, string, sizeof(string));
		mii.cch = strlen(string);
		InsertMenuItem(hSubMenu, 1, TRUE, &mii);

		/* �Z�p���[�^�}�� */
		mii.fType = MFT_SEPARATOR;
		InsertMenuItem(hSubMenu, 2, TRUE, &mii);
		mii.fType = MFT_STRING;

		/* �����߂� */
		mii.wID = IDM_REW;
		LoadString(hResInstance, IDS_TAPEREW, string, sizeof(string));
		mii.cch = strlen(string);
		InsertMenuItem(hSubMenu, 3, TRUE, &mii);

		/* ������ */
		mii.wID = IDM_FF;
		LoadString(hResInstance, IDS_TAPEFF, string, sizeof(string));
		mii.cch = strlen(string);
		InsertMenuItem(hSubMenu, 4, TRUE, &mii);

		/* �Z�p���[�^�}�� */
		mii.fType = MFT_SEPARATOR;
		InsertMenuItem(hSubMenu, 5, TRUE, &mii);
		mii.fType = MFT_STRING;

		/* �^�� */
		mii.wID = IDM_REC;
		LoadString(hResInstance, IDS_TAPEREC, string, sizeof(string));
		mii.cch = strlen(string);
		if (tape_writep) {
			mii.fState = MFS_GRAYED;
		}
		else {
			if (tape_rec) {
				mii.fState = MFS_CHECKED | MFS_ENABLED;
			}
			else {
				mii.fState = MFS_ENABLED;
			}
		}
		InsertMenuItem(hSubMenu, 6, TRUE, &mii);
	}

	/* �o�u�������� �T�u���j���[ */
	for (unit = 0; unit < 2; unit ++) 
	{
		hSubMenu = GetSubMenu(hMenu, unit + 1);

		/* ���j���[���ׂč폜 */
		while (GetMenuItemCount(hSubMenu) > 0) {
			DeleteMenu(hSubMenu, 0, MF_BYPOSITION);
		}

		/* �I�t�Z�b�g�m�� */
		if (unit == 0) {
			offset = 0;
		}
		else {
			offset = IDM_B1OPEN - IDM_B0OPEN;
		}

		/* ���j���[�\���̏����� */
		memset(&mii, 0, sizeof(mii));
		mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
		mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
		mii.fType = MFT_STRING;

		/* �J�� */
		mii.wID = IDM_B0OPEN + offset;
		LoadString(hResInstance, IDS_BUBBLEOPEN, string, sizeof(string));
		mii.dwTypeData = string;
		mii.fState = MFS_ENABLED;
		mii.cch = strlen(string);
		if (!bmc_enable || (fm_subtype != FMSUB_FM8)) {
			mii.fState = MFS_GRAYED;
		}
		else {
			mii.fState = MFS_ENABLED;
		}
		InsertMenuItem(hSubMenu, 0, TRUE, &mii);

		uitem = 0;

		if (bmc_enable) {
			/* ���I�[�v�� */
			mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
			mii.wID = IDM_BBOPEN;
			LoadString(hResInstance, IDS_BBOPEN, string, sizeof(string));
			mii.cch = strlen(string);
			InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

			if (bmc_ready[unit] != BMC_TYPE_NOTREADY) {
				/* ���o�� */
				mii.wID = IDM_B0EJECT + offset;
				LoadString(hResInstance, IDS_BUBBLEEJECT, string, sizeof(string));
				mii.cch = strlen(string);
				InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

				/* �Z�p���[�^�}�� */
				mii.fType = MFT_SEPARATOR;
				InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

				/* �ꎞ���o�� */
				mii.wID = IDM_B0TEMP + offset;
				LoadString(hResInstance, IDS_BUBBLETEMP, string, sizeof(string));
				if ((bmc_ready[unit] == BMC_TYPE_NOTREADY) || (fm_subtype != FMSUB_FM8)) {
					mii.fState = MFS_GRAYED;
				}
				else if (bmc_teject[unit]) {
					mii.fState = MFS_CHECKED | MFS_ENABLED;
				}
				else {
					mii.fState = MFS_ENABLED;
				}
				mii.fType = MFT_STRING;
				mii.cch = strlen(string);
				InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

				/* �������݋֎~ */
				mii.wID = IDM_B0WRITE + offset;
				LoadString(hResInstance, IDS_BUBBLEPROTECT, string, sizeof(string));
				if ((bmc_ready[unit] == BMC_TYPE_NOTREADY) || (fm_subtype != FMSUB_FM8)) {
					mii.fState = MFS_GRAYED;
				}
				else {
					if (bmc_fwritep[unit]) {
						mii.fState = MFS_GRAYED;
					}
					else {
						mii.fState = MFS_ENABLED;
					}
					if ((bmc_fwritep[unit]) || (bmc_writep[unit])) {
						mii.fState |= MFS_CHECKED;
					}
				}
				mii.fType = MFT_STRING;
				mii.cch = strlen(string);
				InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

				/* �Z�p���[�^�}�� */
				mii.fType = MFT_SEPARATOR;
				InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

				/* B77�Ȃ烁�f�B�A���� */
				if (bmc_ready[unit] == BMC_TYPE_B77) {
					for (i=0; i<bmc_medias[unit]; i++) {
						if (unit == 0) {
							mii.wID = IDM_B0MEDIA00 + i;
						}
						else {
							mii.wID = IDM_B1MEDIA00 + i;
						}
						mii.fState = MFS_ENABLED;
						if (bmc_media[unit] == i) {
							mii.fState |= MFS_CHECKED;
						}
						mii.fType = MFT_STRING | MFT_RADIOCHECK;
						if (strlen(bmc_name[unit][i]) == 0) {
							LoadString(hResInstance, IDS_MEDIA_NAME, buffer, sizeof(buffer));
							_snprintf(string, sizeof(string), buffer, i + 1);
						}
						else {
							/* �v���t�B�b�N�X�����΍� */
							k = 0;
							for (j=0; j<(int)strlen(bmc_name[unit][i]); j++) {
								if (bmc_name[unit][i][j] == '&') {
									string[k++] = '&';
								}
								string[k++] = bmc_name[unit][i][j];
							}
							string[k] = '\0';
						}
						mii.cch = strlen(string);
						InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);
					}
				}
				else {
					/* BBL�t�@�C���Ȃ�_�~�[���ڔ��� */
					if (unit == 0) {
						mii.wID = IDM_B0MEDIA00;
					}
					else {
						mii.wID = IDM_B1MEDIA00;
					}
					mii.fState = MFS_ENABLED | MFS_CHECKED;
					mii.fType = MFT_STRING | MFT_RADIOCHECK;
					LoadString(hResInstance, IDS_BBLFILE, string, sizeof(string));
					mii.cch = strlen(string);
					InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);
				}
			}
		}
	}

	EnableMenuPos(hMenu, 1, (fm_subtype == FMSUB_FM8));
	EnableMenuPos(hMenu, 2, (fm_subtype == FMSUB_FM8));
#else
	MENUITEMINFO mii;
	char string[128];
#ifdef XM7DASH
	UINT uitem;
#endif

	ASSERT(hMenu);

	/* ���j���[���ׂč폜 */
	while (GetMenuItemCount(hMenu) > 0) {
		DeleteMenu(hMenu, 0, MF_BYPOSITION);
	}

	/* ���j���[�\���̏����� */
	memset(&mii, 0, sizeof(mii));
	mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
	mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
	mii.fType = MFT_STRING;
	mii.fState = MFS_ENABLED;

	/* �I�[�v�� */
	mii.wID = IDM_TOPEN;
	LoadString(hResInstance, IDS_TAPEOPEN, string, sizeof(string));
	mii.dwTypeData = string;
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, 0, TRUE, &mii);

#ifdef XM7DASH
	if (tape_fileh == -1) {
		mii.fState = MFS_GRAYED;
	}
#else
	/* �e�[�v���Z�b�g����Ă��Ȃ���΁A�����܂� */
	if (tape_fileh == -1) {
		return;
	}
#endif

	/* �C�W�F�N�g */
	mii.wID = IDM_TEJECT;
	LoadString(hResInstance, IDS_TAPEEJECT, string, sizeof(string));
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, 1, TRUE, &mii);

	/* �Z�p���[�^�}�� */
	mii.fType = MFT_SEPARATOR;
	InsertMenuItem(hMenu, 2, TRUE, &mii);
	mii.fType = MFT_STRING;

	/* �����߂� */
	mii.wID = IDM_REW;
	LoadString(hResInstance, IDS_TAPEREW, string, sizeof(string));
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, 3, TRUE, &mii);

	/* ������ */
	mii.wID = IDM_FF;
	LoadString(hResInstance, IDS_TAPEFF, string, sizeof(string));
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, 4, TRUE, &mii);

	/* �Z�p���[�^�}�� */
	mii.fType = MFT_SEPARATOR;
	InsertMenuItem(hMenu, 5, TRUE, &mii);
	mii.fType = MFT_STRING;

	/* �^�� */
	mii.wID = IDM_REC;
	LoadString(hResInstance, IDS_TAPEREC, string, sizeof(string));
	mii.cch = strlen(string);
#ifdef XM7DASH
	if (tape_writep || tape_fileh == -1) {
#else
	if (tape_writep) {
#endif
		mii.fState = MFS_GRAYED;
	}
	else {
		if (tape_rec) {
			mii.fState = MFS_CHECKED | MFS_ENABLED;
		}
		else {
			mii.fState = MFS_ENABLED;
		}
	}
	InsertMenuItem(hMenu, 6, TRUE, &mii);

#ifdef XM7DASH
	uitem = 7;

#if !defined(BUBBLE)
	if ((!bMountFileName) && (tape_fileh != -1)) {
		char buffer[256];
		char tmp[256];
		char fname[_MAX_FNAME];
		char ext[_MAX_EXT];
		int i,j;

		/* �Z�p���[�^�}�� */
		mii.fType = MFT_SEPARATOR;
		InsertMenuItem(hMenu, uitem++, TRUE, &mii);
		mii.fType = MFT_STRING;

		/* ���f�B�A�t�@�C���� */
		mii.wID = IDM_TMEDIA;
		mii.fState = MFS_CHECKED | MFS_ENABLED;
		mii.fType = MFT_STRING | MFT_RADIOCHECK;

		/* �t�@�C���l�[���{�g���q�̂ݎ��o�� */
		_splitpath(tape_fname, NULL, NULL, fname, ext);
		_snprintf(tmp, sizeof(tmp), "%s%s", fname, ext);

		/* �v���t�B�b�N�X�����΍� */
		j = 0;
		for (i=0; i<(int)strlen(tmp); i++) {
			if (tmp[i] == '&') {
				buffer[j++] = '&';
			}
			buffer[j++] = tmp[i];
		}
		buffer[j] = '\0';
		mii.dwTypeData = buffer;
		mii.cch = strlen(buffer);
		InsertMenuItem(hMenu, uitem++, TRUE, &mii);
	}
#endif

	/* ����}�� */
	AppendMenuHistory(hMenu, uitem, IDM_T_FILE0, MRU_TAPE, TRUE);
#endif
#endif
}

#if XM7_VER == 1 && defined(BUBBLE) && defined(XM7DASH)
/*
 *	�J�Z�b�g(C)���j���[�X�V
 */
static void FASTCALL OnCassettePopup(HMENU hMenu)
{
	HMENU hSubMenu;
	MENUITEMINFO mii;
	char string[256];
	char buffer[256];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	UINT uitem, utape, ububble[2][2], uid;
	int type;
	int unit;
	int offset;
	int shift;
	int i,j,k;

	ASSERT(hMenu);

#if 0
	/* ���j���[���ׂč폜 */
	while (GetMenuItemCount(hMenu) > 0) {
		DeleteMenu(hMenu, 0, MF_BYPOSITION);
	}
#endif

	/* ���j���[�\���̏����� */
	memset(&mii, 0, sizeof(mii));
	mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
	mii.fType = MFT_STRING;
	mii.fState = MFS_ENABLED;
	uitem = 0;

	/* �e�[�v */
	utape = uitem++;
#if 0
	if (tape_fileh == -1) {
		mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
		mii.wID = IDM_TOPEN;
		LoadString(hResInstance, IDS_TAPE0OPEN, string, sizeof(string));
		mii.dwTypeData = string;
		mii.cch = strlen(string);
		InsertMenuItem(hMenu, utape, TRUE, &mii);
	}
	else
#endif
	{
		mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID | MIIM_SUBMENU;
		mii.wID = IDM_TOPEN;
		//mii.hSubMenu = CreatePopupMenu();
		mii.hSubMenu = GetSubMenu(hMenu, utape);
#ifdef XM7DASH
		LoadString(hResInstance, IDS_TAPE, buffer, sizeof(buffer));
		if (tape_fileh != -1) {
			_splitpath(tape_fname, NULL, NULL, fname, ext);
			_snprintf(string, sizeof(string), "%s - %s%s", buffer, fname,
					  ext);
		}
		else {
			strncpy(string, buffer, sizeof(string));
		}
#else
		LoadString(hResInstance, IDS_TAPE, string, sizeof(string));
#endif
		mii.dwTypeData = string;
		mii.cch = strlen(string);
		RemoveMenu(hMenu, utape, MF_BYPOSITION);
		InsertMenuItem(hMenu, utape, TRUE, &mii);
	}

	for(type = 0; type < 2; type ++) {
#if 0
		/* �Z�p���[�^�}�� */
		mii.fType = MFT_SEPARATOR;
		InsertMenuItem(hMenu, uitem++, TRUE, &mii);

		/* "�o�u���z���_���j�b�g" */
		mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
		mii.fType = MFT_STRING;
		mii.fState = MFS_GRAYED;
		mii.wID = 0;
		LoadString(hResInstance, IDS_BUBBLE + type, string, sizeof(string));
		InsertMenuItem(hMenu, uitem++, TRUE, &mii);
#else
		uitem++;

		/* "�o�u���z���_���j�b�g" */
		EnableMenuItem(hMenu, uitem, MF_BYPOSITION | MF_GRAYED);
		uitem++;
#endif

		mii.fType = MFT_STRING;
		if (bmc_enable[type]) {
			mii.fState = MFS_ENABLED;
		}
		else {
			mii.fState = MFS_GRAYED;
		}

		for(unit = 0; unit < 2; unit ++) {

			/* �I�t�Z�b�g�m�� */
			shift = unit + type * 2;
#if 0
			if (!type && !unit) {
				offset = 0;
			}
			else if (!type && unit) {
				offset = IDM_B1OPEN - IDM_B0OPEN;
			}
			else if (type && !unit) {
				offset = IDM_B2OPEN - IDM_B0OPEN;
			}
			else {
				offset = IDM_B3OPEN - IDM_B0OPEN;
			}
#endif

			/* �o�u���z���_���j�b�gn */
			ububble[type][unit] = uitem;
#if 0
			if ((!bmc_enable[type]) ||
				(bmc_ready[type][unit] == BMC_TYPE_NOTREADY)) {
				mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
				mii.wID = IDM_B0OPEN + offset;
				LoadString(hResInstance, IDS_BUBBLE0OPEN + shift, string, sizeof(string));
			}
			else
#endif
			{
#if 0
				if (!bmc_enable[type]) {
					mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
				}
				else
#endif
				{
					mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID | MIIM_SUBMENU;
				}
				mii.wID = 0;
				//mii.hSubMenu = CreatePopupMenu();
				mii.hSubMenu = GetSubMenu(hMenu, uitem);
#ifdef XM7DASH
				LoadString(hResInstance, IDS_BUBBLE0 + shift, buffer, sizeof(buffer));
				if ((bmc_enable[type]) &&
					(bmc_ready[type][unit] != BMC_TYPE_NOTREADY)) {
					_splitpath(bmc_fname[type][unit], NULL, NULL, fname, ext);
					_snprintf(string, sizeof(string), "%s - %s%s", buffer,
							  fname, ext);
				}
				else {
					strncpy(string, buffer, sizeof(string));
				}
#else
				LoadString(hResInstance, IDS_BUBBLE0 + shift, string, sizeof(string));
#endif
			}
			mii.dwTypeData = string;
			mii.cch = strlen(string);
			RemoveMenu(hMenu, uitem, MF_BYPOSITION);
			InsertMenuItem(hMenu, uitem++, TRUE, &mii);
		}

#if 0
		/* ���I�[�v�� */
		mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
		if (!type) {
			mii.wID = IDM_BBOPEN;
			uid = IDS_BUBBLEBOTH;
		}
		else {
			mii.wID = IDM_BB23OPEN;
			uid = IDS_BUBBLEBOTHX;
		}
		LoadString(hResInstance, uid, string, sizeof(string));
		mii.cch = strlen(string);
		InsertMenuItem(hMenu, uitem++, TRUE, &mii);
#else
		EnableMenuItem(hMenu, uitem++, MF_BYPOSITION | mii.fState);
		EnableMenuItem(hMenu, uitem++, MF_BYPOSITION | mii.fState);
#endif
	}

#if 0
	/* �Z�p���[�^�}�� */
	mii.fType = MFT_SEPARATOR;
	InsertMenuItem(hMenu, uitem++, TRUE, &mii);
	mii.fType = MFT_STRING;

	/* �����C�W�F�N�g */
	mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
	mii.wID = IDM_CAS_EJECT;
	mii.fState = MFS_ENABLED;
	LoadString(hResInstance, IDS_CAS_EJECT, string, sizeof(string));
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, uitem++, TRUE, &mii);
#endif

	/* �e�[�v�E�T�u���j���[ */
#if 0
	if (tape_fileh != -1) {
#else
	{
#endif
		hSubMenu = GetSubMenu(hMenu, utape);
		OnTapePopup(hSubMenu);
	}

	/* �o�u���J�Z�b�g�E�T�u���j���[ */
	for(type = 0; type < 2; type ++) {
		for(unit = 0; unit < 2; unit ++) {
#if 0
			/* �o�u���J�Z�b�g���Z�b�g����Ă��Ȃ���΁A�����܂� */
			if (bmc_ready[type][unit] == BMC_TYPE_NOTREADY || !bmc_enable[type]) {
#else
			if (!bmc_enable[type]) {
#endif
				continue;
			}

			hSubMenu = GetSubMenu(hMenu, ububble[type][unit]);

			/* ���j���[���ׂč폜 */
			while (GetMenuItemCount(hSubMenu) > 0) {
				DeleteMenu(hSubMenu, 0, MF_BYPOSITION);
			}

			/* �I�t�Z�b�g�m�� */
			shift = unit + type * 2;
			if (!type && !unit) {
				offset = 0;
			}
			else if (!type && unit) {
				offset = IDM_B1OPEN - IDM_B0OPEN;
			}
			else if (type && !unit) {
				offset = IDM_B2OPEN - IDM_B0OPEN;
			}
			else {
				offset = IDM_B3OPEN - IDM_B0OPEN;
			}
			uitem = 0;

			/* ���j���[�\���̏����� */
			memset(&mii, 0, sizeof(mii));
			mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
			mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
			mii.fType = MFT_STRING;

			/* �I�[�v�� */
			mii.wID = IDM_B0OPEN + offset;
			LoadString(hResInstance, IDS_BUBBLEOPEN, string, sizeof(string));
			mii.dwTypeData = string;
			mii.fState = MFS_ENABLED;
			mii.cch = strlen(string);
			InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

			/* �C�W�F�N�g */
			mii.wID = IDM_B0EJECT + offset;
			if (bmc_ready[type][unit] == BMC_TYPE_NOTREADY) {
				mii.fState = MFS_GRAYED;
			}
			else {
				mii.fState = MFS_ENABLED;
			}
			LoadString(hResInstance, IDS_BUBBLEEJECT, string, sizeof(string));
			mii.cch = strlen(string);
			InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

#if 0
			/* �Z�p���[�^�}�� */
			mii.fType = MFT_SEPARATOR;
			InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

			/* �ꎞ���o�� */
			mii.wID = IDM_B0TEMP + offset;
			LoadString(hResInstance, IDS_BUBBLETEMP, string, sizeof(string));
			if (bmc_ready[type][unit] == BMC_TYPE_NOTREADY) {
				mii.fState = MFS_GRAYED;
			}
			else if (bmc_teject[type][unit]) {
				mii.fState = MFS_CHECKED | MFS_ENABLED;
			}
			else {
				mii.fState = MFS_ENABLED;
			}
			mii.fType = MFT_STRING;
			mii.cch = strlen(string);
			InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);
#endif

			/* ���C�g�v���e�N�g */
			mii.wID = IDM_B0WRITE + offset;
			LoadString(hResInstance, IDS_BUBBLEPROTECT, string, sizeof(string));
			if (bmc_ready[type][unit] == BMC_TYPE_NOTREADY) {
				mii.fState = MFS_GRAYED;
			}
			else {
				if (bmc_fwritep[type][unit]) {
					mii.fState = MFS_GRAYED;
				}
				else {
					mii.fState = MFS_ENABLED;
				}
				if ((bmc_fwritep[type][unit]) || (bmc_writep[type][unit])) {
					mii.fState |= MFS_CHECKED;
				}
			}
			mii.fType = MFT_STRING;
			mii.cch = strlen(string);
			InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

#if 0	/* �t�@�C�����͏�w�ɕ\�������̂ō폜 */
			/* �Z�p���[�^�}�� */
			mii.fType = MFT_SEPARATOR;
			InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

			/* ���f�B�A�t�@�C���� */
			mii.wID = IDM_B0MEDIA00 + offset;
			mii.fState = MFS_CHECKED | MFS_ENABLED;
			mii.fType = MFT_STRING | MFT_RADIOCHECK;

			/* �t�@�C���l�[���{�g���q�̂ݎ��o�� */
			_splitpath(bmc_fname[type][unit], NULL, NULL, fname, ext);
			_snprintf(buffer, sizeof(buffer), "%s%s", fname, ext);

			/* �v���t�B�b�N�X�����΍� */
			j = 0;
			for (i=0; i<(int)strlen(buffer); i++) {
				if (buffer[i] == '&') {
					string[j++] = '&';
				}
				string[j++] = buffer[i];
			}
			string[j] = '\0';
			mii.cch = strlen(string);
			InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);
#endif

			/* B77�Ȃ烁�f�B�A���� */
			if (bmc_ready[type][unit] == BMC_TYPE_B77) {

				/* �Z�p���[�^�}�� */
				mii.fType = MFT_SEPARATOR;
				InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);

				for (i=0; i<bmc_medias[type][unit]; i++) {
					mii.wID = IDM_B0MEDIA00 + offset + i;
					mii.fState = MFS_ENABLED;
					if (bmc_media[type][unit] == i) {
						mii.fState |= MFS_CHECKED;
					}
					mii.fType = MFT_STRING | MFT_RADIOCHECK;
					if (strlen(bmc_name[type][unit][i]) == 0) {
						LoadString(hResInstance, IDS_MEDIA_NAME, buffer, sizeof(buffer));
						_snprintf(string, sizeof(string), buffer, i + 1);
					}
					else {
						/* �v���t�B�b�N�X�����΍� */
						k = 0;
						for (j=0; j<(int)strlen(bmc_name[type][unit][i]); j++) {
							if (bmc_name[type][unit][i][j] == '&') {
								string[k++] = '&';
							}
							string[k++] = bmc_name[type][unit][i][j];
						}
						string[k] = '\0';
					}
					mii.cch = strlen(string);
					InsertMenuItem(hSubMenu, uitem++, TRUE, &mii);
				}
			}

			/* ����}�� */
			AppendMenuHistory(hSubMenu, uitem++, IDM_B0_FILE0 - shift * 10, MRU_BBL0 + shift, bmc_enable[type]);
		}
	}
}
#endif	/* XM7_VER == 1 && defined(BUBBLE) && defined(XM7DASH) */

#ifdef XM7DASH
/*
 *	�e�[�v(A)�R���e�L�X�g���j���[
 */
static BOOL FASTCALL OnTapeContextualMenu(HWND hWnd, WORD wID, int x, int y)
{
	ASSERT(hWnd);

#if XM7_VER == 1 && defined(BUBBLE)
	/* �o�u���J�Z�b�g�E�N���b�N���j���[���� */
	if ((wID >= IDM_B0MEDIA00) && (wID <= IDM_B0MEDIA15)) {
		OnContextualSubMenu(hWnd, hMediaMenu, wID, x, y);
		return TRUE;
	}
	if ((wID >= IDM_B1MEDIA00) && (wID <= IDM_B1MEDIA15)) {
		OnContextualSubMenu(hWnd, hMediaMenu, wID, x, y);
		return TRUE;
	}
	if ((wID >= IDM_B2MEDIA00) && (wID <= IDM_B2MEDIA15)) {
		OnContextualSubMenu(hWnd, hMediaMenu, wID, x, y);
		return TRUE;
	}
	if ((wID >= IDM_B3MEDIA00) && (wID <= IDM_B3MEDIA15)) {
		OnContextualSubMenu(hWnd, hMediaMenu, wID, x, y);
		return TRUE;
	}
#endif	/* XM7_VER == 1 && defined(BUBBLE) */

	/* �q�X�g�� */
	if ((wID >= IDM_T_FILE0) && (wID <= IDM_T_FILE9)) {
		OnContextualSubMenu(hWnd, hHistoryMenu, wID, x, y);
		return TRUE;
	}
#if XM7_VER == 1 && defined(BUBBLE)
	if ((wID >= IDM_B3_FILE0) && (wID <= IDM_B0_FILE9)) {
		OnContextualSubMenu(hWnd, hHistoryMenu, wID, x, y);
		return TRUE;
	}
#endif	/* XM7_VER == 1 && defined(BUBBLE) */

	return FALSE;
}
#endif

/*-[ �\�����j���[ ]---------------------------------------------------------*/

/*
 *	�t���b�s�[�f�B�X�N�R���g���[��(F)
 */
static void FASTCALL OnFDC(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_FDC]) {
		PostMessage(hSubWnd[SWND_FDC], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_FDC] = CreateFDC(hDrawWnd, SWND_FDC);
}

/*
 *	�o�u���������R���g���[��(B)
 */
#if XM7_VER == 1 && defined(BUBBLE)
static void FASTCALL OnBMC(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_BMC]) {
		PostMessage(hSubWnd[SWND_BMC], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_BMC] = CreateBMC(hDrawWnd, SWND_BMC);
}
#endif

/*
 *	FM�������W�X�^(O)
 */
static void FASTCALL OnOPNReg(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_OPNREG]) {
		PostMessage(hSubWnd[SWND_OPNREG], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_OPNREG] = CreateOPNReg(hDrawWnd, SWND_OPNREG);
}

/*
 *	FM�����f�B�X�v���C(D)
 */
static void FASTCALL OnOPNDisp(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_OPNDISP]) {
		PostMessage(hSubWnd[SWND_OPNDISP], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_OPNDISP] = CreateOPNDisp(hDrawWnd, SWND_OPNDISP);
}

/*
 *	�T�uCPU�R���g���[��(C)
 */
static void FASTCALL OnSubCtrl(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_SUBCTRL]) {
		PostMessage(hSubWnd[SWND_SUBCTRL], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_SUBCTRL] = CreateSubCtrl(hDrawWnd, SWND_SUBCTRL);
}

/*
 *	�L�[�{�[�h(K)
 */
static void FASTCALL OnKeyboard(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_KEYBOARD]) {
		PostMessage(hSubWnd[SWND_KEYBOARD], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_KEYBOARD] = CreateKeyboard(hDrawWnd, SWND_KEYBOARD);
}

/*
 *	�_�����Z/�������(L)
 */
#if XM7_VER >= 2
static void FASTCALL OnALULine(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_ALULINE]) {
		PostMessage(hSubWnd[SWND_ALULINE], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_ALULINE] = CreateALULine(hDrawWnd, SWND_ALULINE);
}
#endif

/*
 *	�������Ǘ�(M)
 */
static void FASTCALL OnMMR(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_MMR]) {
		PostMessage(hSubWnd[SWND_MMR], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_MMR] = CreateMMR(hDrawWnd, SWND_MMR);
}

#if XM7_VER >= 3 || (XM7_VER == 1 && defined(SFDC) && defined(XM7DASH))
/*
 *	DMA�R���g���[��(A)
 */
static void FASTCALL OnDMAC(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_DMAC]) {
		PostMessage(hSubWnd[SWND_DMAC], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_DMAC] = CreateDMAC(hDrawWnd, SWND_DMAC);
}
#endif

#ifdef XM7DASH
/*
 *	����ROM(N)
 */
static void FASTCALL OnKanji(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_KANJI]) {
		PostMessage(hSubWnd[SWND_KANJI], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_KANJI] = CreateKanji(hDrawWnd, SWND_KANJI);
}

/*
 *	�J�Z�b�g�e�[�v(T)
 */
static void FASTCALL OnTapeWnd(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_TAPE]) {
		PostMessage(hSubWnd[SWND_TAPE], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_TAPE] = CreateTape(hDrawWnd, SWND_TAPE);
}

/*
 *	���C���v�����^(P)
 */
static void FASTCALL OnLP(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_LP]) {
		PostMessage(hSubWnd[SWND_LP], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_LP] = CreateLP(hDrawWnd, SWND_LP);
}
#endif

/*
 *	�X�e�[�^�X�o�[(S)
 */
static void FASTCALL OnStatus(void)
{
	/* �X�e�[�^�X�o�[���L���łȂ���΁A�������Ȃ� */
	if (!hStatusBar) {
		return;
	}

	if (IsWindowVisible(hStatusBar)) {
		/* ���� */
		ShowWindow(hStatusBar, SW_HIDE);
#ifndef XM7DASH
		bHideStatus = TRUE;
#endif
	}
	else {
		/* �\�� */
		ShowWindow(hStatusBar, SW_SHOW);
#ifndef XM7DASH
		bHideStatus = FALSE;
#endif
	}

#ifndef XM7DASH
	/* �ݒ胏�[�N�ɔ��f */
	GetCfg();
#endif

	/* �t���[���E�C���h�E�̃T�C�Y��␳ */
	OnSize(hMainWnd, 640, 400);
}

/*
 *	�ŐV�̏��ɍX�V(R)
 */
static void FASTCALL OnRefresh(HWND hWnd)
{
	int i;

	ASSERT(hWnd);
	ASSERT(hDrawWnd);

	/* �t�A�Z���u���E�C���h�E�@�A�h���X�X�V */
#ifdef XM7DASH
	if (bSyncDisasm[0] && nAddrModeDisAsm == 0) {
#else
	if ((hSubWnd[SWND_DISASM_MAIN]) && (bSyncDisasm[0])) {
#endif
		AddrDisAsm(MAINCPU, maincpu.pc);
	}
#ifdef XM7DASH
	if (bSyncDisasm[1]) {
#else
	if ((hSubWnd[SWND_DISASM_SUB]) && (bSyncDisasm[1])) {
#endif
		AddrDisAsm(SUBCPU, subcpu.pc);
	}
#ifdef JSUB
#ifdef XM7DASH
	if (bSyncDisasm[2]) {
#else
	if ((hSubWnd[SWND_DISASM_JSUB]) && (bSyncDisasm[2])) {
#endif
		AddrDisAsm(JSUBCPU, jsubcpu.pc);
	}
#endif

	/* ���C���E�C���h�E */
	InvalidateRect(hWnd, NULL, FALSE);
	InvalidateRect(hDrawWnd, NULL, FALSE);

	/* �T�u�E�C���h�E */
	for (i=0; i<SWND_MAXNUM; i++) {
		if (hSubWnd[i]) {
			InvalidateRect(hSubWnd[i], NULL, FALSE);
		}
	}
}

/*
 *	���s�ɓ���(Y)
 */
static void FASTCALL OnSync(void)
{
	bSync = (!bSync);
}

/*
 *	�t���X�N���[��(U)
 */
static void FASTCALL OnFullScreen(HWND hWnd)
{
	BOOL bRun;
	int i;

	ASSERT(hWnd);

	/* VM�����b�N�A�X�g�b�v */
	LockVM();
	bRun = run_flag;
	run_flag = FALSE;
	StopSnd();

	/* ���[�h�؂�ւ� */
	if (bFullScreen) {
		ModeDraw(hWnd, FALSE);

		if (!bFullScreen) {
			/* ���ׂẴT�u�E�B���h�E���t���X�N���[�����O�̏�Ԃɖ߂� */
			for (i=0; i<SWND_MAXNUM; i++) {
				if (hSubWnd[i]) {
					if (bShowSubWindow[i]) {
						ShowWindow(hSubWnd[i], SW_RESTORE);
					}
				}
			}
#ifdef XM7DASH
			if (bPopupSwnd) {
				SetForegroundWindow(hWnd);
			}
#endif
		}
	}
	else {
		ModeDraw(hWnd, TRUE);

		if (bFullScreen) {
			/* ���ׂẴT�u�E�B���h�E���B�� */
			for (i=0; i<SWND_MAXNUM; i++) {
				bShowSubWindow[i] = FALSE;
				if (hSubWnd[i]) {
					if (ShowWindow(hSubWnd[i], SW_HIDE)) {
						bShowSubWindow[i] = TRUE;
					}
				}
			}
		}
	}

	/* VM���A�����b�N */
	GetCfg();
	run_flag = bRun;
	ResetSch();
	UnlockVM();
	PlaySnd();
}

#if defined(XM7DASH) && defined(FILTERDLL)
/*
 *	�f�B�X�v���C�T�C�Y(Z)
 */
static void FASTCALL OnScalingSize(HWND hWnd, int nSize)
{
	ASSERT((nSize >= 0) || (nSize <= 5));

	/* �f�B�X�v���C�T�C�Y��ύX */
	nScalingSize = nSize;
	bDoubleSize = (BOOL)(nSize == 2);

	/* �\�����e���X�V */
	OnSize(hWnd, 640, 400);
	InvalidateRect(hDrawWnd, NULL, FALSE);
}

/*
 *	�A�X�y�N�g�䒲��(&E)
 */
static void FASTCALL OnAspectRatio(HWND hWnd)
{
	/* �A�X�y�N�g�䒲���t���O��ύX */
	bAspectRatio = !bAspectRatio;

	/* �\�����e���X�V */
	OnSize(hWnd, 640, 400);
	InvalidateRect(hDrawWnd, NULL, FALSE);
}
#endif

/*
 *	�\��(V)���j���[
 */
static BOOL FASTCALL OnView(HWND hWnd, WORD wID)
{
	ASSERT(hWnd);

	switch (wID) {
		/* FDC */
		case IDM_FDC:
			OnFDC();
			return TRUE;

		/* �o�u���������R���g���[�� */
#if XM7_VER == 1 && defined(BUBBLE)
		case IDM_BMC:
			OnBMC();
			return TRUE;
#endif

		/* OPN���W�X�^ */
		case IDM_OPNREG:
			OnOPNReg();
			return TRUE;

		/* OPN�f�B�X�v���C */
		case IDM_OPNDISP:
			OnOPNDisp();
			return TRUE;

		/* �T�uCPU�R���g���[�� */
		case IDM_SUBCTRL:
			OnSubCtrl();
			return TRUE;

		/* �L�[�{�[�h */
		case IDM_KEYBOARD:
			OnKeyboard();
			return TRUE;

#if XM7_VER >= 2
		/* �_�����Z/������� */
		case IDM_ALULINE:
			OnALULine();
			return TRUE;
#endif

		/* �������Ǘ� */
		case IDM_MMR:
			OnMMR();
			return TRUE;

#if XM7_VER >= 3 || (XM7_VER == 1 && defined(SFDC) && defined(XM7DASH))
		/* DMA�R���g���[�� */
		case IDM_DMAC:
			OnDMAC();
			return TRUE;
#endif

#ifdef XM7DASH
		/* ����ROM */
		case IDM_KANJI:
			OnKanji();
			return TRUE;

		/* �J�Z�b�g�e�[�v */
		case IDM_TAPE:
			OnTapeWnd();
			return TRUE;

		/* ���C���v�����^ */
		case IDM_LP:
			OnLP();
			return TRUE;
#endif

		/* �X�e�[�^�X�o�[ */
		case IDM_STATUS:
			OnStatus();
			return TRUE;

		/* �ŐV�̏��ɍX�V */
		case IDM_REFRESH:
			OnRefresh(hWnd);
			return TRUE;

		/* ���s�ɓ��� */
		case IDM_SYNC:
			OnSync();
			return TRUE;

#if defined(XM7DASH) && defined(FILTERDLL)
		/* x0.5 */
		case IDM_DISPLAYSIZEx050:
			OnScalingSize(hWnd, 3);
			return TRUE;

		/* x1.0 */
		case IDM_DISPLAYSIZEx100:
			OnScalingSize(hWnd, 0);
			return TRUE;

		/* x1.2 */
		case IDM_DISPLAYSIZEx120:
			OnScalingSize(hWnd, 5);
			break;

		/* x1.5 */
		case IDM_DISPLAYSIZEx150:
			OnScalingSize(hWnd, 1);
			return TRUE;

		/* x1.8 */
		case IDM_DISPLAYSIZEx180:
			OnScalingSize(hWnd, 4);
			return TRUE;

		/* x2.0 */
		case IDM_DISPLAYSIZEx200:
			OnScalingSize(hWnd, 2);
			return TRUE;

		/* �A�X�y�N�g�䒲�� */
		case IDM_ASPECTRATIO:
			OnAspectRatio(hWnd);
			return TRUE;
#endif

		/* �t���X�N���[�� */
		case IDM_FULLSCREEN:
			OnFullScreen(hWnd);
			return TRUE;
	}

	return FALSE;
}

/*
 *	�\��(V)���j���[�X�V
 */
static void FASTCALL OnViewPopup(HMENU hMenu)
{
#if defined(XM7DASH) && defined(FILTERDLL)
	UINT uitem, id;
#endif

	/* �T�u�E�C���h�E�Q */
	CheckMenuSub(hMenu, IDM_FDC, (BOOL)hSubWnd[SWND_FDC]);
#if XM7_VER == 1 && defined(BUBBLE)
	CheckMenuSub(hMenu, IDM_BMC, (BOOL)hSubWnd[SWND_BMC]);
#endif
	CheckMenuSub(hMenu, IDM_OPNREG, (BOOL)hSubWnd[SWND_OPNREG]);
	CheckMenuSub(hMenu, IDM_OPNDISP, (BOOL)hSubWnd[SWND_OPNDISP]);
	CheckMenuSub(hMenu, IDM_SUBCTRL, (BOOL)hSubWnd[SWND_SUBCTRL]);
#if XM7_VER >= 2
	CheckMenuSub(hMenu, IDM_ALULINE, (BOOL)hSubWnd[SWND_ALULINE]);
#endif
	CheckMenuSub(hMenu, IDM_KEYBOARD, (BOOL)hSubWnd[SWND_KEYBOARD]);
	CheckMenuSub(hMenu, IDM_MMR, (BOOL)hSubWnd[SWND_MMR]);
#if XM7_VER >= 3 || (XM7_VER == 1 && defined(SFDC) && defined(XM7DASH))
	CheckMenuSub(hMenu, IDM_DMAC, (BOOL)hSubWnd[SWND_DMAC]);
#endif
#ifdef XM7DASH
	CheckMenuSub(hMenu, IDM_KANJI, (BOOL)hSubWnd[SWND_KANJI]);
	CheckMenuSub(hMenu, IDM_TAPE, (BOOL)hSubWnd[SWND_TAPE]);
	CheckMenuSub(hMenu, IDM_LP, (BOOL)hSubWnd[SWND_LP]);
#endif

	/* ���̑� */
	if (hStatusBar) {
		CheckMenuSub(hMenu, IDM_STATUS, IsWindowVisible(hStatusBar));
	}
	else {
		CheckMenuSub(hMenu, IDM_STATUS, FALSE);
	}
	CheckMenuSub(hMenu, IDM_SYNC, bSync);
	CheckMenuSub(hMenu, IDM_FULLSCREEN, bFullScreen);

	/* �t���X�N���[�����̃T�u�E�B���h�E���j���[������ */
	EnableMenuSub(hMenu, IDM_FDC, !bFullScreen);
#if XM7_VER == 1 && defined(BUBBLE)
	EnableMenuSub(hMenu, IDM_BMC, !bFullScreen);
#endif
	EnableMenuSub(hMenu, IDM_OPNREG, !bFullScreen);
	EnableMenuSub(hMenu, IDM_OPNDISP, !bFullScreen);
	EnableMenuSub(hMenu, IDM_SUBCTRL, !bFullScreen);
#if XM7_VER >= 2
	EnableMenuSub(hMenu, IDM_ALULINE, !bFullScreen);
#endif
	EnableMenuSub(hMenu, IDM_KEYBOARD, !bFullScreen);
	EnableMenuSub(hMenu, IDM_MMR, !bFullScreen);
#if XM7_VER >= 3 || (XM7_VER == 1 && defined(SFDC) && defined(XM7DASH))
	EnableMenuSub(hMenu, IDM_DMAC, !bFullScreen);
#endif
#ifdef XM7DASH
	EnableMenuSub(hMenu, IDM_KANJI, !bFullScreen);
	EnableMenuSub(hMenu, IDM_TAPE, !bFullScreen);
	EnableMenuSub(hMenu, IDM_LP, !bFullScreen);
#endif

#if defined(XM7DASH) && defined(FILTERDLL)
	uitem = 12;
#if XM7_VER == 1 && defined(BUBBLE)
	uitem += 1;
#endif
#if XM7_VER >= 2
	uitem += 1;
#endif
#if XM7_VER >= 3 || (XM7_VER == 1 && defined(SFDC) && defined(XM7DASH))
	uitem += 1;
#endif
	EnableMenuPos(hMenu, uitem += 1, !bFullScreen);
	switch (nScalingSize) {
		case 0:						/* x1.0(640x400) */
		default:
			id = IDM_DISPLAYSIZEx100;
			break;

		case 1:						/* x1.5(960x600) */
			id = IDM_DISPLAYSIZEx150;
			break;

		case 2:						/* x2.0(1280x800) */
			id = IDM_DISPLAYSIZEx200;
			break;

		case 3:						/* x0.5(320x200) */
			id = IDM_DISPLAYSIZEx050;
			break;

		case 4:						/* x1.8(1152x720) */
			id = IDM_DISPLAYSIZEx180;
			break;

		case 5:						/* x1.2(768x480) */
			id = IDM_DISPLAYSIZEx120;
			break;
	}
	CheckMenuRadioItem(hMenu, IDM_DISPLAYSIZEx100, IDM_DISPLAYSIZEx120, id, MF_BYCOMMAND);
	EnableMenuSub(hMenu, IDM_DISPLAYSIZEx150, (BOOL)(bFilterDll && bUseFilterDll));
	EnableMenuSub(hMenu, IDM_DISPLAYSIZEx050, (BOOL)(bFilterDll && bUseFilterDll));
	EnableMenuSub(hMenu, IDM_DISPLAYSIZEx180, (BOOL)(bFilterDll && bUseFilterDll));
	EnableMenuSub(hMenu, IDM_DISPLAYSIZEx120, (BOOL)(bFilterDll && bUseFilterDll));
	CheckMenuSub(hMenu, IDM_ASPECTRATIO, bAspectRatio);
	EnableMenuSub(hMenu, IDM_ASPECTRATIO, (BOOL)(!bFullScreen && bFilterDll && bUseFilterDll));
#endif
}

#ifdef XM7DASH
/*
 *	�\��(V)�R���e�L�X�g���j���[
 */
static BOOL FASTCALL OnViewContextualMenu(HWND hWnd, WORD wID, int x, int y)
{
	ASSERT(hWnd);

#ifdef FILTERDLL
	/* �A�X�y�N�g�䒲�� */
	if (wID == IDM_ASPECTRATIO) {
		OnContextualSubMenu(hWnd, hAspectMenu, wID, x, y);
		return TRUE;
	}
#endif

	return FALSE;
}
#endif

/*-[ �f�o�b�O���j���[ ]-----------------------------------------------------*/

/*
 *	���s(X)
 */
static void FASTCALL OnExec(void)
{
	/* ���Ɏ��s���Ȃ�A�������Ȃ� */
	if (run_flag) {
		return;
	}

	/* �X�^�[�g */
	LockVM();
	stopreq_flag = FALSE;
	run_flag = TRUE;
	UnlockVM();
}

/*
 *	��~(B)
 */
static void FASTCALL OnBreak(void)
{
	/* ���ɒ�~��ԂȂ�A�������Ȃ� */
	if (!run_flag) {
		return;
	}

	/* ��~ */
	LockVM();
	stopreq_flag = TRUE;
	UnlockVM();
}

/*
 *	�g���[�X(T)
 */
static void FASTCALL OnTrace(HWND hWnd)
{
	ASSERT(hWnd);

	/* ��~��ԂłȂ���΁A���^�[�� */
	if (run_flag) {
		return;
	}

	/* ���s */
	schedule_trace();
#ifdef XM7DASH
	if (bSyncDisasm[0] && nAddrModeDisAsm == 0) {
		AddrDisAsm(MAINCPU, maincpu.pc);
	}
	if (bSyncDisasm[1]) {
		AddrDisAsm(SUBCPU, subcpu.pc);
	}
#ifdef JSUB
	if (bSyncDisasm[2]) {
		AddrDisAsm(JSUBCPU, jsubcpu.pc);
	}
#endif
#else
	AddrDisAsm(MAINCPU, maincpu.pc);
	AddrDisAsm(SUBCPU, subcpu.pc);
#ifdef JSUB
	AddrDisAsm(JSUBCPU, jsubcpu.pc);
#endif
#endif

	/* �\���X�V */
	OnRefresh(hWnd);
}

/*
 *	�u���[�N�|�C���g(B)
 */
static void FASTCALL OnBreakPoint(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_BREAKPOINT]) {
		PostMessage(hSubWnd[SWND_BREAKPOINT], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_BREAKPOINT] = CreateBreakPoint(hDrawWnd, SWND_BREAKPOINT);
}

/*
 *	�X�P�W���[��(S)
 */
static void FASTCALL OnScheduler(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_SCHEDULER]) {
		PostMessage(hSubWnd[SWND_SCHEDULER], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_SCHEDULER] = CreateScheduler(hDrawWnd, SWND_SCHEDULER);
}

/*
 *	CPU���W�X�^(C)
 */
static void FASTCALL OnCPURegister(int nCPU)
{
	int index;

#ifndef JSUB
	ASSERT((nCPU >= MAINCPU) && (nCPU <= SUBCPU));
#else
	ASSERT((nCPU >= MAINCPU) && (nCPU <= JSUBCPU));
#endif
	ASSERT(hDrawWnd);

	/* �C���f�b�N�X���� */
	index = SWND_CPUREG_MAIN + nCPU;

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[index]) {
		PostMessage(hSubWnd[index], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[index] = CreateCPURegister(hDrawWnd, (BYTE)nCPU, index);
}

/*
 *	�t�A�Z���u��(D)
 */
static void FASTCALL OnDisAsm(int nCPU)
{
	int index;

#ifndef JSUB
	ASSERT((nCPU >= MAINCPU) && (nCPU <= SUBCPU));
#else
	ASSERT((nCPU >= MAINCPU) && (nCPU <= JSUBCPU));
#endif
	ASSERT(hDrawWnd);

	/* �C���f�b�N�X���� */
	index = SWND_DISASM_MAIN + nCPU;

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[index]) {
		PostMessage(hSubWnd[index], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[index] = CreateDisAsm(hDrawWnd, (BYTE)nCPU, index);
}

/*
 *	�������_���v(M)
 */
static void FASTCALL OnMemory(int nCPU)
{
	int index;

#ifndef JSUB
	ASSERT((nCPU >= MAINCPU) && (nCPU <= SUBCPU));
#else
	ASSERT((nCPU >= MAINCPU) && (nCPU <= JSUBCPU));
#endif
	ASSERT(hDrawWnd);

	/* �C���f�b�N�X���� */
	index = SWND_MEMORY_MAIN + nCPU;

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[index]) {
		PostMessage(hSubWnd[index], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[index] = CreateMemory(hDrawWnd, (BYTE)nCPU, index);
}

#ifdef XM7DASH
/*
 *	���荞��(I)
 */
static void FASTCALL OnIRQ(int nCPU)
{
	int index;

#ifndef JSUB
	ASSERT((nCPU >= MAINCPU) && (nCPU <= SUBCPU));
#else
	ASSERT((nCPU >= MAINCPU) && (nCPU <= JSUBCPU));
#endif
	ASSERT(hDrawWnd);

	/* �C���f�b�N�X���� */
	index = SWND_IRQ_MAIN + nCPU;

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[index]) {
		PostMessage(hSubWnd[index], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[index] = CreateIRQ(hDrawWnd, (BYTE)nCPU, index);
}
#endif

#if defined(XM7DASH) && defined(DBGLOG)
/*
 *	���O(L)
 */
static void FASTCALL OnLog(void)
{
	ASSERT(hDrawWnd);

	/* �E�C���h�E�����݂���΁A�N���[�Y�w�����o�� */
	if (hSubWnd[SWND_LOG]) {
		PostMessage(hSubWnd[SWND_LOG], WM_CLOSE, 0, 0);
		return;
	}

	/* �E�C���h�E�쐬 */
	hSubWnd[SWND_LOG] = CreateLog(hDrawWnd, SWND_LOG);
}
#endif

/*
 *	�f�o�b�O(D)���j���[
 */
static BOOL FASTCALL OnDebug(HWND hWnd, WORD wID)
{
	ASSERT(hWnd);

	switch (wID) {
		/* ���s */
		case IDM_EXEC:
			OnExec();
			return TRUE;

		/* �u���[�N */
		case IDM_BREAK:
			OnBreak();
			return TRUE;

		/* �g���[�X */
		case IDM_TRACE:
			OnTrace(hWnd);
			return TRUE;

		/* �u���[�N�|�C���g */
		case IDM_BREAKPOINT:
			OnBreakPoint();
			return TRUE;

		/* �X�P�W���[�� */
		case IDM_SCHEDULER:
			OnScheduler();
			return TRUE;

		/* CPU���W�X�^(���C��) */
		case IDM_CPU_MAIN:
			OnCPURegister(MAINCPU);
			return TRUE;

		/* CPU���W�X�^(�T�u) */
		case IDM_CPU_SUB:
			OnCPURegister(SUBCPU);
			return TRUE;

		/* �t�A�Z���u��(���C��) */
		case IDM_DISASM_MAIN:
			OnDisAsm(MAINCPU);
			return TRUE;

		/* �t�A�Z���u��(�T�u) */
		case IDM_DISASM_SUB:
			OnDisAsm(SUBCPU);
			return TRUE;

		/* �������_���v(���C��) */
		case IDM_MEMORY_MAIN:
			OnMemory(MAINCPU);
			return TRUE;

		/* �������_���v(�T�u) */
		case IDM_MEMORY_SUB:
			OnMemory(SUBCPU);
			return TRUE;

#ifdef JSUB
		/* CPU���W�X�^(���{��T�u) */
		case IDM_CPU_JSUB:
			OnCPURegister(JSUBCPU);
			return TRUE;

		/* �t�A�Z���u��(���{��T�u) */
		case IDM_DISASM_JSUB:
			OnDisAsm(JSUBCPU);
			return TRUE;

		/* �������_���v(���{��T�u) */
		case IDM_MEMORY_JSUB:
			OnMemory(JSUBCPU);
			return TRUE;
#endif

#ifdef XM7DASH
		/* ���荞��(���C��) */
		case IDM_IRQ_MAIN:
			OnIRQ(MAINCPU);
			return TRUE;

		/* ���荞��(�T�u) */
		case IDM_IRQ_SUB:
			OnIRQ(SUBCPU);
			return TRUE;
#endif

#if defined(XM7DASH) && defined(DBGLOG)
		/* ���O */
		case IDM_LOG:
			OnLog();
			return TRUE;
#endif
	}

	return FALSE;
}

/*
 *	�f�o�b�O(D)���j���[�X�V
 */
static void FASTCALL OnDebugPopup(HMENU hMenu)
{
	ASSERT(hMenu);

	/* ���s���� */
	EnableMenuSub(hMenu, IDM_EXEC, !run_flag);
	EnableMenuSub(hMenu, IDM_BREAK, run_flag);
	EnableMenuSub(hMenu, IDM_TRACE, !run_flag);

	/* �T�u�E�C���h�E�Q */
	CheckMenuSub(hMenu, IDM_BREAKPOINT, (BOOL)hSubWnd[SWND_BREAKPOINT]);
	CheckMenuSub(hMenu, IDM_SCHEDULER, (BOOL)hSubWnd[SWND_SCHEDULER]);
	CheckMenuSub(hMenu, IDM_CPU_MAIN, (BOOL)hSubWnd[SWND_CPUREG_MAIN]);
	CheckMenuSub(hMenu, IDM_CPU_SUB, (BOOL)hSubWnd[SWND_CPUREG_SUB]);
	CheckMenuSub(hMenu, IDM_DISASM_MAIN, (BOOL)hSubWnd[SWND_DISASM_MAIN]);
	CheckMenuSub(hMenu, IDM_DISASM_SUB, (BOOL)hSubWnd[SWND_DISASM_SUB]);
	CheckMenuSub(hMenu, IDM_MEMORY_MAIN, (BOOL)hSubWnd[SWND_MEMORY_MAIN]);
	CheckMenuSub(hMenu, IDM_MEMORY_SUB, (BOOL)hSubWnd[SWND_MEMORY_SUB]);
#ifdef JSUB
	CheckMenuSub(hMenu, IDM_CPU_JSUB, (BOOL)hSubWnd[SWND_CPUREG_JSUB]);
	CheckMenuSub(hMenu, IDM_DISASM_JSUB, (BOOL)hSubWnd[SWND_DISASM_JSUB]);
	CheckMenuSub(hMenu, IDM_MEMORY_JSUB, (BOOL)hSubWnd[SWND_MEMORY_JSUB]);
#endif
#ifdef XM7DASH
	CheckMenuSub(hMenu, IDM_IRQ_MAIN, (BOOL)hSubWnd[SWND_IRQ_MAIN]);
	CheckMenuSub(hMenu, IDM_IRQ_SUB, (BOOL)hSubWnd[SWND_IRQ_SUB]);
#endif
#if defined(XM7DASH) && defined(DBGLOG)
	CheckMenuSub(hMenu, IDM_LOG, (BOOL)hSubWnd[SWND_LOG]);
#endif

	/* �t���X�N���[�����̃T�u�E�B���h�E���j���[������ */
	EnableMenuSub(hMenu, IDM_BREAKPOINT, !bFullScreen);
	EnableMenuSub(hMenu, IDM_SCHEDULER, !bFullScreen);
	EnableMenuSub(hMenu, IDM_CPU_MAIN, !bFullScreen);
	EnableMenuSub(hMenu, IDM_CPU_SUB, !bFullScreen);
	EnableMenuSub(hMenu, IDM_DISASM_MAIN, !bFullScreen);
	EnableMenuSub(hMenu, IDM_DISASM_SUB, !bFullScreen);
	EnableMenuSub(hMenu, IDM_MEMORY_MAIN, !bFullScreen);
	EnableMenuSub(hMenu, IDM_MEMORY_SUB, !bFullScreen);
#ifdef JSUB
#ifdef XM7DASH
	EnableMenuSub(hMenu, IDM_CPU_JSUB, !bFullScreen);
	EnableMenuSub(hMenu, IDM_DISASM_JSUB, !bFullScreen);
	EnableMenuSub(hMenu, IDM_MEMORY_JSUB, !bFullScreen);
#elif XM7_VER >= 3
	EnableMenuSub(hMenu, IDM_CPU_JSUB,
		!bFullScreen && jsub_available && jsub_enable &&
		(fm7_ver < 3));
	EnableMenuSub(hMenu, IDM_DISASM_JSUB,
		!bFullScreen && jsub_available && jsub_enable &&
		(fm7_ver < 3));
	EnableMenuSub(hMenu, IDM_MEMORY_JSUB,
		!bFullScreen && jsub_available && jsub_enable &&
		(fm7_ver < 3));
#else
	EnableMenuSub(hMenu, IDM_CPU_JSUB,
		!bFullScreen && jsub_available && jsub_enable);
	EnableMenuSub(hMenu, IDM_DISASM_JSUB,
		!bFullScreen && jsub_available && jsub_enable);
	EnableMenuSub(hMenu, IDM_MEMORY_JSUB,
		!bFullScreen && jsub_available && jsub_enable);
#endif
#endif
#ifdef XM7DASH
	EnableMenuSub(hMenu, IDM_IRQ_MAIN, !bFullScreen);
	EnableMenuSub(hMenu, IDM_IRQ_SUB, !bFullScreen);
#endif
#if defined(XM7DASH) && defined(DBGLOG)
	EnableMenuSub(hMenu, IDM_LOG, !bFullScreen);
#endif
}

/*-[ �c�[�����j���[ ]-------------------------------------------------------*/

/*
 *	�}�E�X���[�h�؂芷��
 */
#ifdef MOUSE
void FASTCALL MouseModeChange(BOOL flag)
{
	/* ���[�h�ω����Ȃ���΋A�� */
	if (mos_capture == flag) {
		return;
	}

	/* �}�E�X�L���v�`���t���O��ݒ� */
	mos_capture = flag;

	/* �X�e�[�^�X�o�[�ɏ�ԕ\�� */
	if (flag) {
		SetStatusMessage(IDS_MOUSE_ENABLE);
	}
	else {
		SetStatusMessage(IDS_MOUSE_DISABLE);
	}
}
#endif

/*
 *	�����A�W���X�g
 */
#if XM7_VER >= 2
static void FASTCALL OnTimeAdjust(void)
{
	/* �������Đݒ肷�� */
	rtc_time_adjust();

	/* �O�̂��߃X�P�W���[���������� */
	rtc_reset();
}
#endif

/*
 *	�}�E�X���[�h�؂芷��(M)
 */
#ifdef MOUSE
static void FASTCALL OnMouseMode(void)
{
	/* �}�E�X�L���v�`���t���O�𔽓]�����ă��[�h�؂�ւ� */
	MouseModeChange(!mos_capture);
}
#endif

/*
 *	��ʃL���v�`��(C)
 */
static void FASTCALL OnGrpCapture(void)
{
	char path[_MAX_PATH];
#if XM7_VER >= 2 && defined(XM7DASH)
	BOOL bmode = FALSE;

#if XM7_VER >= 3
	if (fm_subtype < FMSUB_FM77AV) {
#else
	if (fm7_ver == 1) {
#endif
		bmode = bGreenMonitor;
	}
#if XM7_VER >= 3
	else if (fm_subtype == FMSUB_FM77AV) {
		if (screen_mode == SCR_4096) {
#else
	else if (fm7_ver == 2) {
		if (mode320) {
#endif
			bmode = bTTLMonitor;
		}
	}
#endif

	/* �t�@�C���I�� */
	if (!FileSelectSub(FALSE, IDS_GRPCAPFILTER, path, "BMP", 3)) {
		return;
	}

	/* �L���v�`�� */
	LockVM();
	StopSnd();
#if XM7_VER == 1
	capture_to_bmp(path, bFullScan, bGreenMonitor);
#elif XM7_VER >= 2 && defined(XM7DASH)
	capture_to_bmp(path, bFullScan, bmode);
#elif XM7_VER == 2
	capture_to_bmp(path, bFullScan, bTTLMonitor);
#else
	capture_to_bmp(path, bFullScan, FALSE);
#endif
	PlaySnd();
	ResetSch();
	UnlockVM();
}

/*
 *	��ʃL���v�`��2
 */
static void FASTCALL OnGrpCapture2(void)
{
	char path[_MAX_PATH];
#if XM7_VER >= 2 && defined(XM7DASH)
	BOOL bmode = FALSE;

#if XM7_VER >= 3
	if (fm_subtype < FMSUB_FM77AV) {
#else
	if (fm7_ver == 1) {
#endif
		bmode = bGreenMonitor;
	}
#if XM7_VER >= 3
	else if (fm_subtype == FMSUB_FM77AV) {
		if (screen_mode == SCR_4096) {
#else
	else if (fm7_ver == 2) {
		if (mode320) {
#endif
			bmode = bTTLMonitor;
		}
	}
#endif

	/* �t�@�C���I�� */
	if (!FileSelectSub(FALSE, IDS_GRPCAPFILTER, path, "BMP", 3)) {
		return;
	}

	/* �L���v�`�� */
	LockVM();
	StopSnd();
#if XM7_VER == 1
	capture_to_bmp2(path, bGreenMonitor);
#elif XM7_VER >= 2 && defined(XM7DASH)
	capture_to_bmp2(path, bmode);
#elif XM7_VER == 2
	capture_to_bmp2(path, bTTLMonitor);
#else
	capture_to_bmp2(path, FALSE);
#endif
	PlaySnd();
	ResetSch();
	UnlockVM();
}

/*
 *	WAV�L���v�`��(W)
 */
static void FASTCALL OnWavCapture(HWND hWnd)
{
	char path[_MAX_PATH];

	ASSERT(hWnd);

	/* ���ɃL���v�`�����Ȃ�A�N���[�Y */
	if (hWavCapture >= 0) {
		LockVM();
		CloseCaptureSnd();
		UnlockVM();
		return;
	}

	/* �t�@�C���I�� */
	if (!FileSelectSub(FALSE, IDS_WAVCAPFILTER, path, "WAV", 4)) {
		return;
	}

	/* �L���v�`�� */
	LockVM();
	OpenCaptureSnd(path);
	UnlockVM();

	/* �������� */
	if (hWavCapture < 0) {
		LockVM();
		StopSnd();

		LoadString(hResInstance, IDS_WAVCAPERROR, path, sizeof(path));
		MessageBox(hWnd, path, "XM7", MB_ICONSTOP | MB_OK);
		SetMenuExitTimer();

		PlaySnd();
		ResetSch();
		UnlockVM();
	}
}

/*
 *	�V�K�f�B�X�N�쐬(D)
 */
static void FASTCALL OnNewDisk(HWND hWnd)
{
	char path[_MAX_PATH];
	int ret;
	BOOL err;

	ASSERT(hWnd);

	/* �^�C�g������ */
#ifdef XM7DASH
	strncpy(DiskTitle, "Default", sizeof(DiskTitle));
#endif
	ret = DialogBox(hResInstance, MAKEINTRESOURCE(IDD_TITLEDLG),
						hWnd, TitleDlgProc);
	if (ret != IDOK) {
		return;
	}

	/* �t�@�C���I�� */
	if (!FileSelectSub(FALSE, IDS_NEWDISKFILTER, path, "D77", 0)) {
		return;
	}

	/* �쐬 */
	LockVM();
	StopSnd();

	if (DiskFormat) {
		err = make_new_userdisk(path, DiskTitle, DiskMedia);
	}
	else {
		err = make_new_d77(path, DiskTitle, DiskMedia);
	}
	if (err) {
		LoadString(hResInstance, IDS_NEWDISKOK, path, sizeof(path));
		MessageBox(hWnd, path, "XM7", MB_OK);
		SetMenuExitTimer();
	}

	PlaySnd();
	ResetSch();
	UnlockVM();
}

/*
 *	�V�K�e�[�v�쐬(T)
 */
static void FASTCALL OnNewTape(HWND hWnd)
{
	char path[_MAX_PATH];

	ASSERT(hWnd);

	/* �t�@�C���I�� */
	if (!FileSelectSub(FALSE, IDS_TAPEFILTER, path, "T77", 1)) {
		return;
	}

	/* �쐬 */
	LockVM();
	StopSnd();

	if (make_new_t77(path)) {
		LoadString(hResInstance, IDS_NEWTAPEOK, path, sizeof(path));
		MessageBox(hWnd, path, "XM7", MB_OK);
		SetMenuExitTimer();
	}

	PlaySnd();
	ResetSch();
	UnlockVM();
}

#if XM7_VER == 1 && defined(BUBBLE)
/*
 *	�V�K�o�u���J�Z�b�g�쐬(B)
 */
static void FASTCALL OnNewBubble(HWND hWnd)
{
	char path[_MAX_PATH];
	int ret;
	BOOL err;

	ASSERT(hWnd);

	/* �^�C�g������ */
	strncpy(BubbleTitle, "Default", sizeof(BubbleTitle));
	ret = DialogBox(hResInstance, MAKEINTRESOURCE(IDD_MEDIATYPEDLG),
						hWnd, BubbleMediaTypeDlgProc);
	if (ret != IDOK) {
		return;
	}

	/* �t�@�C���I�� */
	if (BubbleFormat) {
		if (!FileSelectSub(FALSE, IDS_B77FILTER, path, "B77", 5)) {
			return;
		}
	}
	else {
		if (!FileSelectSub(FALSE, IDS_BBLFILTER, path, "BBL", 5)) {
			return;
		}
	}

	/* �쐬 */
	LockVM();
	StopSnd();

	if (BubbleFormat) {
#ifdef XM7DASH
		err = make_new_bubble(path, BubbleTitle, BubbleMedia);
#else
		err = make_new_bubble(path, BubbleTitle);
#endif
	}
	else {
#ifdef XM7DASH
		err = make_new_bubble(path, NULL, BubbleMedia);
#else
		err = make_new_bubble(path, NULL);
#endif
	}
	if (err) {
		LoadString(hResInstance, IDS_NEWBUBBLEOK, path, sizeof(path));
		MessageBox(hWnd, path, "XM7", MB_OK);
		SetMenuExitTimer();
	}

	PlaySnd();
	ResetSch();
	UnlockVM();
}
#endif

/*
 *	VFD��D77�ϊ�(V)
 */
static void FASTCALL OnVFD2D77(HWND hWnd)
{
	char src[_MAX_PATH];
	char dst[_MAX_PATH];
	int ret;

	ASSERT(hWnd);

	/* �t�@�C���I�� */
	if (!FileSelectSub(TRUE, IDS_VFDFILTER, src, "VFD", 0)) {
		return;
	}

	/* �^�C�g������ */
#ifdef XM7DASH
	strncpy(DiskTitle, "Default", sizeof(DiskTitle));
#endif
	ret = DialogBox(hResInstance, MAKEINTRESOURCE(IDD_TITLEDLG_2D),
						hWnd, TitleDlg2DProc);
	if (ret != IDOK) {
		SetMenuExitTimer();
		return;
	}

	/* �t�@�C���I�� */
	if (!FileSelectSub(FALSE, IDS_NEWDISKFILTER, dst, "D77", 0)) {
		return;
	}

	/* �쐬 */
	LockVM();
	StopSnd();

	if (conv_vfd_to_d77(src, dst, DiskTitle)) {
		LoadString(hResInstance, IDS_CONVERTOK, src, sizeof(src));
		MessageBox(hWnd, src, "XM7", MB_OK);
		SetMenuExitTimer();
	}

	PlaySnd();
	ResetSch();
	UnlockVM();
}

/*
 *	2D��D77�ϊ�(2)
 */
static void FASTCALL On2D2D77(HWND hWnd)
{
	char src[_MAX_PATH];
	char dst[_MAX_PATH];
	int ret;

	ASSERT(hWnd);

	/* �t�@�C���I�� */
	if (!FileSelectSub(TRUE, IDS_2DFILTER, src, "2D", 0)) {
		return;
	}

	/* �^�C�g������ */
#ifdef XM7DASH
	strncpy(DiskTitle, "Default", sizeof(DiskTitle));
#endif
	ret = DialogBox(hResInstance, MAKEINTRESOURCE(IDD_TITLEDLG_2D),
						hWnd, TitleDlg2DProc);
	if (ret != IDOK) {
		SetMenuExitTimer();
		return;
	}

	/* �t�@�C���I�� */
	if (!FileSelectSub(FALSE, IDS_NEWDISKFILTER, dst, "D77", 0)) {
		return;
	}

	/* �쐬 */
	LockVM();
	StopSnd();

	if (conv_2d_to_d77(src, dst, DiskTitle)) {
		LoadString(hResInstance, IDS_CONVERTOK, src, sizeof(src));
		MessageBox(hWnd, src, "XM7", MB_OK);
		SetMenuExitTimer();
	}

	PlaySnd();
	ResetSch();
	UnlockVM();
}

/*
 *	VTP��T77�ϊ�(P)
 */
static void FASTCALL OnVTP2T77(HWND hWnd)
{
	char src[_MAX_PATH];
	char dst[_MAX_PATH];

	ASSERT(hWnd);

	/* �t�@�C���I�� */
	if (!FileSelectSub(TRUE, IDS_VTPFILTER, src, "VTP", 1)) {
		return;
	}

	/* �t�@�C���I�� */
	if (!FileSelectSub(FALSE, IDS_TAPEFILTER, dst, "T77", 1)) {
		return;
	}

	/* �쐬 */
	LockVM();
	StopSnd();

	if (conv_vtp_to_t77(src, dst)) {
		LoadString(hResInstance, IDS_CONVERTOK, src, sizeof(src));
		MessageBox(hWnd, src, "XM7", MB_OK);
		SetMenuExitTimer();
	}

	PlaySnd();
	ResetSch();
	UnlockVM();
}

#if XM7_VER == 1 && defined(BUBBLE)
/*
 *	BBL��B77�ϊ�(L)
 */
static void FASTCALL OnBBL2B77(HWND hWnd)
{
	char src[_MAX_PATH];
	char dst[_MAX_PATH];
	int ret;

	ASSERT(hWnd);

	/* �t�@�C���I�� */
	if (!FileSelectSub(TRUE, IDS_BBLFILTER, src, "BBL", 5)) {
		return;
	}

	/* �^�C�g������ */
	strncpy(DiskTitle, "Default", sizeof(DiskTitle));
	ret = DialogBox(hResInstance, MAKEINTRESOURCE(IDD_TITLEDLG_2D),
						hWnd, TitleDlg2DProc);
	if (ret != IDOK) {
		SetMenuExitTimer();
		return;
	}

	/* �t�@�C���I�� */
	if (!FileSelectSub(FALSE, IDS_B77FILTER, dst, "B77", 5)) {
		return;
	}

	/* �쐬 */
	LockVM();
	StopSnd();

	if (conv_bbl_to_b77(src, dst, DiskTitle)) {
		LoadString(hResInstance, IDS_CONVERTOK, src, sizeof(src));
		MessageBox(hWnd, src, "XM7", MB_OK);
		SetMenuExitTimer();
	}

	PlaySnd();
	ResetSch();
	UnlockVM();
}
#endif

#if defined(XM7DASH) && defined(KBDPASTE)
/*
 *	����t��(E)
 */
static void FASTCALL OnPaste(HWND hWnd)
{
	ASSERT(hWnd);

	LockVM();
	StopSnd();

	PasteKbd(hWnd);

	PlaySnd();
	ResetSch();
	UnlockVM();
}
#endif

/*
 *	�T�E���h�o�̓��[�h�؂�ւ�
 */
static void FASTCALL OnChgSound(void)
{
	LockVM();

	/* �T�E���h���[�h�ύX */
	uStereoOut = (uStereoOut + 1) % 4;
	SetStatusMessage(IDS_SND_MONAURAL + uStereoOut);

	/* �K�p */
	ApplySnd();
	UnlockVM();
}

/*
 *	�T�C�N���X�`�[�����[�h�؂�ւ�
 */
static void FASTCALL OnChgCycleSteal(void)
{
	LockVM();

	/* �T�E���h���[�h�ύX */
	cycle_steal = !cycle_steal;
	GetCfg();

	if (cycle_steal) {
		SetStatusMessage(IDS_ENABLE_CYCLESTEAL);
	}
	else {
		SetStatusMessage(IDS_DISABLE_CYCLESTEAL);
	}

	UnlockVM();
}

#ifdef XM7DASH
/*
 *	�f�B�X�N�^�C�g���ύX
 */
#if XM7_VER == 1 && defined(SFDC)
static void FASTCALL OnSetDiskTitle(HWND hWnd, int Type, int Drive, int Index)
#else	/* XM7_VER == 1 && defined(SFDC) */
static void FASTCALL OnSetDiskTitle(HWND hWnd, int Drive, int Index)
#endif	/* XM7_VER == 1 && defined(SFDC) */
{
	char string[128];
	int ret, i;
	BOOL err;
	BYTE media;
	BOOL teject;

	ASSERT(hWnd);

#if XM7_VER == 1 && defined(SFDC)
	/* D77�`�F�b�N */
	if (fdc_ready[Type][Drive] != FDC_TYPE_D77) {
		return;
	}
#else	/* XM7_VER == 1 && defined(SFDC) */
	/* D77�`�F�b�N */
	if (fdc_ready[Drive] != FDC_TYPE_D77) {
		return;
	}
#endif	/* XM7_VER == 1 && defined(SFDC) */

	/* �^�C�g������ */
#if XM7_VER == 1 && defined(SFDC)
	strncpy(DiskTitle, fdc_name[Type][Drive][Index], sizeof(DiskTitle));
#else	/* XM7_VER == 1 && defined(SFDC) */
	strncpy(DiskTitle, fdc_name[Drive][Index], sizeof(DiskTitle));
#endif	/* XM7_VER == 1 && defined(SFDC) */
	ret = DialogBox(hResInstance, MAKEINTRESOURCE(IDD_TITLEDLG_2D),
						hWnd, TitleDlg2DProc);
	if (ret != IDOK) {
		SetMenuExitTimer();
		return;
	}

	/* �쐬 */
	LockVM();
	StopSnd();

#if XM7_VER == 1 && defined(SFDC)
	err = set_title_media(fdc_fname[Type][Drive], Index, DiskTitle);
#else	/* XM7_VER == 1 && defined(SFDC) */
	err = set_title_media(fdc_fname[Drive], Index, DiskTitle);
#endif	/* XM7_VER == 1 && defined(SFDC) */
	if (err) {
		for (i = 0; i < FDC_DRIVES; i ++) {
#if XM7_VER == 1 && defined(SFDC)
			if (fdc_ready[Type][i] == FDC_TYPE_NOTREADY) {
				continue;
			}
			media = fdc_media[Type][i];
			teject = fdc_teject[Type][i];
			fdc_setdisk(Type, i, fdc_fname[Type][i]);
			fdc_setmedia(Type, i, media);
			fdc_teject[Type][i] = teject;
#else	/* XM7_VER == 1 && defined(SFDC) */
			if (fdc_ready[i] == FDC_TYPE_NOTREADY) {
				continue;
			}
			media = fdc_media[i];
			teject = fdc_teject[i];
			fdc_setdisk(i, fdc_fname[i]);
			fdc_setmedia(i, media);
			fdc_teject[i] = teject;
#endif	/* XM7_VER == 1 && defined(SFDC) */
		}
		LoadString(hResInstance, IDS_SETTITLEOK, string, sizeof(string));
		MessageBox(hWnd, string, "XM7", MB_OK);
	}

	PlaySnd();
	ResetSch();
	UnlockVM();

	SetMenuExitTimer();
}

/*
 *	�o�u���J�Z�b�g�^�C�g���ύX
 */
#if XM7_VER == 1 && defined(BUBBLE)
static void FASTCALL OnSetBubbleTitle(HWND hWnd, int Type, int Unit, int Index)
{
	char string[128];
	int ret, i;
	BOOL err;
	BYTE media;
	BOOL teject;

	ASSERT(hWnd);

	/* �`�F�b�N */
	if (bmc_ready[Type][Unit] != BMC_TYPE_B77) {
		return;
	}

	/* �^�C�g������ */
	strncpy(DiskTitle, bmc_name[Type][Unit][Index], sizeof(DiskTitle));
	ret = DialogBox(hResInstance, MAKEINTRESOURCE(IDD_TITLEDLG_2D),
						hWnd, TitleDlg2DProc);
	if (ret != IDOK) {
		SetMenuExitTimer();
		return;
	}

	/* �쐬 */
	LockVM();
	StopSnd();

	err = set_title_media(bmc_fname[Type][Unit], Index, DiskTitle);
	if (err) {
		for (i = 0; i < BMC_UNITS_32; i ++) {
			if (bmc_ready[Type][i] == BMC_TYPE_NOTREADY) {
				continue;
			}
			media = bmc_media[Type][i];
			teject = bmc_teject[Type][i];
			bmc_setfile(Type, i, bmc_fname[Type][i]);
			bmc_setmedia(Type, i, media);
			bmc_teject[Type][i] = teject;
		}
		LoadString(hResInstance, IDS_SETTITLEOK, string, sizeof(string));
		MessageBox(hWnd, string, "XM7", MB_OK);
	}

	PlaySnd();
	ResetSch();
	UnlockVM();

	SetMenuExitTimer();
}
#endif	/* XM7_VER == 1 && defined(SFDC) */
#endif

/*
 *	�c�[��(T)���j���[
 */
static BOOL FASTCALL OnTool(HWND hWnd, WORD wID)
{
	ASSERT(hWnd);

	switch (wID) {
		/* �ݒ� */
		case IDM_CONFIG:
			OnConfig(hWnd);
			return TRUE;

#ifdef MOUSE
		/* �}�E�X���[�h�؂芷�� */
		case IDM_MOUSEMODE:
			if (bDetectMouse) {
				OnMouseMode();
			}
			return TRUE;

		/* �}�E�X���[�h�؂芷��(F11,���j���[��\��) */
		case IDM_MOUSEMODE2:
			if (!kbd_table[DIK_F11] && bDetectMouse) {
				OnMouseMode();
			}
			return TRUE;

		/* �}�E�X���[�h�L�� */
		case IDM_MOUSEON:
			if (bDetectMouse) {
				MouseModeChange(TRUE);
			}
			return TRUE;

		/* �}�E�X���[�h���� */
		case IDM_MOUSEOFF:
			if (bDetectMouse) {
				MouseModeChange(FALSE);
			}
			return TRUE;
#endif

#if XM7_VER >= 2
		/* �����A�W���X�g */
		case IDM_TIMEADJUST:
			OnTimeAdjust();
			return TRUE;
#endif

		/* ��ʃL���v�`�� */
		case IDM_GRPCAP:
			OnGrpCapture();
			return TRUE;

		/* ��ʃL���v�`��2 */
		case IDM_GRPCAP2:
			OnGrpCapture2();
			return TRUE;

		/* WAV�L���v�`�� */
		case IDM_WAVCAP:
			OnWavCapture(hWnd);
			return TRUE;

		/* �V�K�f�B�X�N */
		case IDM_NEWDISK:
			OnNewDisk(hWnd);
			return TRUE;

		/* �V�K�e�[�v */
		case IDM_NEWTAPE:
			OnNewTape(hWnd);
			return TRUE;

#if XM7_VER == 1 && defined(BUBBLE)
		/* �V�K�o�u���J�Z�b�g */
		case IDM_NEWBUBBLE:
			OnNewBubble(hWnd);
			return TRUE;
#endif

		/* VFD��D77 */
		case IDM_VFD2D77:
			OnVFD2D77(hWnd);
			return TRUE;

		/* 2D��D77 */
		case IDM_2D2D77:
			On2D2D77(hWnd);
			return TRUE;

		/* VTP��T77 */
		case IDM_VTP2T77:
			OnVTP2T77(hWnd);
			return TRUE;

#if XM7_VER == 1 && defined(BUBBLE)
		/* BBL��B77 */
		case IDM_BBL2B77:
			OnBBL2B77(hWnd);
			return TRUE;
#endif

#if defined(XM7DASH) && defined(KBDPASTE)
		/* ����t�� */
		case IDM_PASTE:
			OnPaste(hWnd);
			return TRUE;
#endif

		/* �T�E���h�o�͐؂�ւ�(���j���[��\��) */
		case IDM_CHG_SOUNDMODE:
			OnChgSound();
			return TRUE;

		/* �T�C�N���X�`�[�����[�h�؂�ւ�(���j���[��\��) */
		case IDM_CYCLESTEAL:
			OnChgCycleSteal();
			return TRUE;
	}

#if defined(XM7DASH) && defined(FMDLL)
	/* ���X�g����Z�b�g */
	if ((wID >= IDM_EXTSND0) && (wID <= IDM_EXTSND9)) {
		int index = wID - IDM_EXTSND0;
		if (bUseFmDll) {
			if (index == GetXDLSel(XDL_SND) + 1) {
				return TRUE;
			}
		}
		else {
			if (index == 0) {
				return TRUE;
			}
		}
		if (index == 0) {
			bUseFmDll = FALSE;
		}
		else {
			char string[256 + 1];
			bUseFmDll = TRUE;
			SetXDLSel(XDL_SND, index - 1);
			GetXDLFile(XDL_SND, index - 1, string, sizeof(string));
			strncpy(szFmDll, string, sizeof(szFmDll));
		}
		LockVM();
		StopSnd();
		CleanSnd();
		ApplySnd();
		PlaySnd();
		ResetSch();
		UnlockVM();
		return TRUE;
	}
#endif	/* XM7DASH */

#if defined(XM7DASH) && defined(FILTERDLL)
	/* ���X�g����Z�b�g */
	if ((wID >= IDM_EXTFLT0) && (wID <= IDM_EXTFLT9)) {
		int index = wID - IDM_EXTFLT0;
		if (bUseFilterDll) {
			if (index == GetXDLSel(XDL_FLT) + 1) {
				return TRUE;
			}
		}
		else {
			if (index == 0) {
				return TRUE;
			}
		}
		if (index == 0) {
			bUseFilterDll = FALSE;
			bAspectRatio = FALSE;
		}
		else {
			char string[256 + 1];
			bUseFilterDll = TRUE;
			SetXDLSel(XDL_FLT, index - 1);
			GetXDLFile(XDL_FLT, index - 1, string, sizeof(string));
			strncpy(szFilterDll, string, sizeof(szFilterDll));
		}
		if (bFilterDll && bUseFilterDll) {
			switch (nScalingSize) {
				case 0:						/* x1.0(640x400) */
				default:
					bDoubleSize = FALSE;
					break;

				case 1:						/* x1.5(960x600) */
					bDoubleSize = FALSE;
					break;

				case 2:						/* x2.0(1280x800) */
					bDoubleSize = TRUE;
					break;

				case 3:						/* x0.5(320x200) */
					bDoubleSize = FALSE;
					break;

				case 4:						/* x1.8(1152x720) */
					bDoubleSize = FALSE;
					break;
			}
		}
		else {
			if (bDoubleSize) {
				nScalingSize = 2;	/* x2.0(1280x800) */
			}
			else {
				nScalingSize = 0;	/* x1.0(640x400) */
			}
		}
		if (!bFullScreen) {
			LockVM();
			StopSnd();
			ReDraw(hWnd);
			PlaySnd();
			ResetSch();
			UnlockVM();

			/* ��ʍĕ`�� */
			OnRefresh(hWnd);

			/* �\�����e���X�V */
			OnSize(hWnd, 640, 400);

			InvalidateRect(hDrawWnd, NULL, FALSE);
		}
		return TRUE;
	}
#endif	/* XM7DASH */

	return FALSE;
}

/*
 *	�c�[��(T)���j���[�X�V
 */
static void FASTCALL OnToolPopup(HMENU hMenu)
{
#ifdef XM7DASH
	UINT uitem, uitem2;
	HMENU hSubMenu;
	MENUITEMINFO mii;
	char string[256+1];
	char buffer[256+1];
	int	i, j, k;
#else
#ifdef MOUSE
	MENUITEMINFO mii;
	char string[128];
#endif
#endif

	ASSERT(hMenu);

#ifdef MOUSE
	/* ���j���[���ڂ��炢������폜 */
	DeleteMenu(hMenu, IDM_MOUSEMODE, MF_BYCOMMAND);

	/* ���߂č��ڂ�˂����� */
	if (kbd_table[DIK_F11]) {
		LoadString(hResInstance, IDS_MOUSEMODE_DISF11, string, sizeof(string));
	}
	else {
		LoadString(hResInstance, IDS_MOUSEMODE_ENBF11, string, sizeof(string));
	}

	memset(&mii, 0, sizeof(mii));
	mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
	mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
	mii.fType = MFT_STRING;
	mii.fState = MFS_ENABLED;
	mii.wID = IDM_MOUSEMODE;
	mii.dwTypeData = string;
	mii.cch = strlen(string);
#if XM7_VER >= 2
	InsertMenuItem(hMenu, IDM_TIMEADJUST, MF_BYCOMMAND, &mii);
#else
	InsertMenuItem(hMenu, 2, MF_BYPOSITION, &mii);
#endif
	EnableMenuItem(hMenu, IDM_MOUSEMODE, !bDetectMouse);

	/* �}�E�X���[�h */
	CheckMenuSub(hMenu, IDM_MOUSEMODE, mos_capture);
#endif

	/* WAV�L���v�`�� �n���h�������ŃI�[�v���� */
	CheckMenuSub(hMenu, IDM_WAVCAP, (hWavCapture >= 0));

#ifdef XM7DASH
	uitem = 12;
#if XM7_VER == 1 && defined(BUBBLE)
	uitem += 2;
#endif
#if XM7_VER >= 2
	uitem += 1;
#endif
#ifdef MOUSE
	uitem += 1;
#endif
#if defined(MOUSE) || (XM7_VER >= 2)
	uitem += 1;
#endif
#ifdef S98LOG
	uitem += 1;
#endif

#ifdef FMDLL
	/* �O���������X�g�ǉ� */
	AddMenuList(hMenu, uitem ++, IDS_FMGEN_BUILDIN, IDM_EXTSND0, XDL_SND, bUseFmDll);
#endif

#ifdef FILTERDLL
	/* �O���摜�t�B���^���X�g�ǉ� */
	AddMenuList(hMenu, uitem ++, IDS_NO_FILTER, IDM_EXTFLT0, XDL_FLT, bUseFilterDll);
#endif

#ifdef KBDPASTE
	/* �y�[�X�g�҂����Ԑݒ肪�Ȃ��ꍇ */
	if ((uPasteWait == 0) && (uPasteWaitCntl == 0)) {
		/* ���j���[���ڂ���폜 */
		while (GetMenuItemCount(hMenu) > (int)uitem) {
			DeleteMenu(hMenu, uitem, MF_BYPOSITION);
		}
	}
#endif
#endif
}

/*-[ �E�B���h�E���j���[ ]---------------------------------------------------*/

/*
 *	�S�E�C���h�E�̕\����Ԃ��ꊇ���ĕύX
 */
static void FASTCALL ShowAllWindowSub(int CmdShow)
{
	int i;

	for (i=0; i<SWND_MAXNUM; i++) {
		if (hSubWnd[i]) {
			ShowWindow(hSubWnd[i], CmdShow);
		}
	}
}

/*
 *	�d�˂ĕ\��(C)
 */
static void FASTCALL OnCascade(void)
{
	/* �d�˂ĕ\�� */
	ASSERT(hDrawWnd);
	CascadeWindows(hDrawWnd, 0, NULL, 0, NULL);
}

/*
 *	���ׂĕ\��(T)
 */
static void FASTCALL OnTile(void)
{
	/* ���ׂĕ\�� */
	ASSERT(hDrawWnd);
	TileWindows(hDrawWnd, MDITILE_VERTICAL, NULL, 0, NULL);
}

/*
 *	�S�ăA�C�R����(I)
 */
static void FASTCALL OnIconic(void)
{
	ShowAllWindowSub(SW_MINIMIZE);
}

/*
 *	�A�C�R���̐���(A)
 */
static void FASTCALL OnArrangeIcon(void)
{
	/* �A�C�R���̐��� */
	ASSERT(hDrawWnd);
	ArrangeIconicWindows(hDrawWnd);
}

/*
 *	�S�ĉB��(H)
 */
static void FASTCALL OnHide(void)
{
	ShowAllWindowSub(SW_HIDE);
}

/*
 *	�S�ĕ���(R)
 */
static void FASTCALL OnRestore(void)
{
	ShowAllWindowSub(SW_RESTORE);

#ifdef XM7DASH
	if (bPopupSwnd) {
		SetForegroundWindow(hMainWnd);
	}
#endif
}

/*
 *	�S�ĕ���(O)
 */
static void FASTCALL OnClose(void)
{
	int i;
#ifdef XM7DASH
	int nflag;
#endif

	for (i=0; i<SWND_MAXNUM; i++) {
		if (hSubWnd[i]) {
			DestroyWindow(hSubWnd[i]);
			hSubWnd[i] = NULL;
		}
	}
}

/*
 *	�E�B���h�E(W)���j���[
 */
static BOOL FASTCALL OnWindow(WORD wID)
{
	int i;

	switch (wID) {
		/* �d�˂ĕ\�� */
		case IDM_CASCADE:
			OnCascade();
			return TRUE;

		/* ���ׂĕ\�� */
		case IDM_TILE:
			OnTile();
			return TRUE;

		/* �S�ăA�C�R���� */
		case IDM_ICONIC:
			OnIconic();
			return TRUE;

		/* �A�C�R���̐��� */
		case IDM_ARRANGEICON:
			OnArrangeIcon();
			return TRUE;

		/* �S�ĉB�� */
		case IDM_ALLHIDE:
			OnHide();
			return TRUE;

		/* �S�ĕ��� */
		case IDM_ALLRESTORE:
			OnRestore();
			return TRUE;

		/* �S�ĕ��� */
		case IDM_ALLCLOSE:
			OnClose();
			return TRUE;
	}

	/* �E�B���h�E�I���� */
#ifdef XM7DASH
	if ((wID >= IDM_SWND00) && (wID < IDM_SWND00 + SWND_MAXNUM)) {
#else
	if ((wID >= IDM_SWND00) && (wID <= IDM_SWND15)) {
#endif
		for (i=0; i<SWND_MAXNUM; i++) {
			if (hSubWnd[i] == NULL) {
				continue;
			}

			/* �J�E���g�_�E�����AOK */
			if (wID == IDM_SWND00) {
				ShowWindow(hSubWnd[i], SW_RESTORE);
				SetWindowPos(hSubWnd[i], HWND_TOP, 0, 0, 0, 0,
					SWP_NOMOVE | SWP_NOSIZE);
				break;
			}
			else {
				wID--;
			}
		}
	}

	return FALSE;
}

/*
 *	�E�B���h�E(W)���j���[�X�V
 */
static void FASTCALL OnWindowPopup(HMENU hMenu)
{
	int i;
	BOOL flag;
	MENUITEMINFO mii;
	UINT nID;
	int count;
	char string[128];

	ASSERT(hMenu);

#ifdef XM7DASH
	/* �t���X�N���[�����̐擪��7�̖������y�у|�b�v�A�b�v���̐擪2��+4�Ԗڂ̖����� */
	EnableMenuSub(hMenu, IDM_CASCADE, !(bFullScreen || bPopupSwnd));
	EnableMenuSub(hMenu, IDM_TILE, !(bFullScreen || bPopupSwnd));
	EnableMenuSub(hMenu, IDM_ICONIC, !bFullScreen);
	EnableMenuSub(hMenu, IDM_ARRANGEICON, !(bFullScreen || bPopupSwnd));
#else
	/* �t���X�N���[�����̐擪��7�̖����� */
	EnableMenuSub(hMenu, IDM_CASCADE, !bFullScreen);
	EnableMenuSub(hMenu, IDM_TILE, !bFullScreen);
	EnableMenuSub(hMenu, IDM_ICONIC, !bFullScreen);
	EnableMenuSub(hMenu, IDM_ARRANGEICON, !bFullScreen);
#endif
	EnableMenuSub(hMenu, IDM_ALLHIDE, !bFullScreen);
	EnableMenuSub(hMenu, IDM_ALLRESTORE, !bFullScreen);
	EnableMenuSub(hMenu, IDM_ALLCLOSE, !bFullScreen);

	/* �擪�̂V���c���č폜 */
	while (GetMenuItemCount(hMenu) > 7) {
		DeleteMenu(hMenu, 7, MF_BYPOSITION);
	}

	/* �L���ȃT�u�E�C���h�E���Ȃ���΁A���̂܂܃��^�[�� */
	flag = FALSE;
	for (i=0; i<SWND_MAXNUM; i++) {
		if (hSubWnd[i] != NULL) {
			flag = TRUE;
		}
	}
	if (!flag) {
		return;
	}

	/* ���j���[�\���̏����� */
	memset(&mii, 0, sizeof(mii));
	mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
	mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
	mii.fType = MFT_STRING;
	mii.fState = MFS_ENABLED;

	/* �Z�p���[�^�}�� */
	mii.fType = MFT_SEPARATOR;
	InsertMenuItem(hMenu, 7, TRUE, &mii);
	mii.fType = MFT_STRING;

	/* �E�C���h�E�^�C�g�����Z�b�g */
	count = 0;
	nID = IDM_SWND00;
	for (i=0; i<SWND_MAXNUM; i++) {
		if (hSubWnd[i] != NULL) {
			/* ���j���[�}�� */
			mii.wID = nID;
			memset(string, 0, sizeof(string));
			GetWindowText(hSubWnd[i], string, sizeof(string) - 1);
			mii.dwTypeData = string;
			mii.cch = strlen(string);
			InsertMenuItem(hMenu, count + 8, TRUE, &mii);
			EnableMenuSub(hMenu, nID, !bFullScreen);

			/* ���� */
			nID++;
			count++;
		}
	}
}

/*-[ �w���v���j���[ ]-------------------------------------------------------*/

#if defined(XM7DASH) && defined(RES_DLL)
/*
 *	����ύX(L)
 */
static void FASTCALL OnLangage(void)
{
	HMENU hMenu;

	if (bExistResourceDll) {
		/* �T�u�E�B���h�E��S�ĕ��� */
		OnClose();

		bLanguageMode = !bLanguageMode;
		if (bLanguageMode) {
			hResInstance = hInstRes;
		}
		else {
			hResInstance = hAppInstance;
		}

		LockVM();

		/* ���C�����j���[�������[�h */
		hMenu = GetMenu(hMainWnd);
		SetMenu(hMainWnd, NULL);
		DestroyMenu(hMenu);
		hMenu = LoadMenu(hResInstance, MAKEINTRESOURCE(IDR_MAINMENU));
		SetMenu(hMainWnd, hMenu);

		/* ���f�B�A���j���[�������[�h */
		DestroyMenu(hMediaMenu);
		hMediaMenu = LoadMenu(hResInstance, MAKEINTRESOURCE(IDR_MEDIAMENU));

		/* �q�X�g�����j���[�������[�h */
		DestroyMenu(hHistoryMenu);
		hHistoryMenu = LoadMenu(hResInstance, MAKEINTRESOURCE(IDR_HISTORYMENU));

		/* �A�X�y�N�g��ݒ胁�j���[�������[�h */
		DestroyMenu(hAspectMenu);
		hAspectMenu = LoadMenu(hResInstance, MAKEINTRESOURCE(IDR_ASPECTMENU));

		/* ��ʃ��b�Z�[�W�������[�h */
		LoadMessageScreen();

		UnlockVM();
	}
}
#endif

/*
 *	�w���v(H)���j���[
 */
static BOOL FASTCALL OnHelp(HWND hWnd, WORD wID)
{
	switch (wID) {
		/* �o�[�W������� */
		case IDM_ABOUT:
			OnAbout(hWnd);
			return TRUE;

#if defined(XM7DASH) && defined(RES_DLL)
		/* ����ύX */
		case IDM_LANGUAGE:
			OnLangage();
			return TRUE;
#endif
	}

	return FALSE;
}

#if defined(XM7DASH) && defined(RES_DLL)
/*
 *	�w���v(H)���j���[�X�V
 */
static void FASTCALL OnHelpPopup(HMENU hMenu)
{
	int i;
	BOOL flag;
	MENUITEMINFO mii;
	UINT nID;
	int count;
	char string[128];

	ASSERT(hMenu);

	/* ���\�[�XDLL���Ȃ���Ή������Ȃ� */
	if ((!bUseLanguageMode) ||
		(!bExistResourceDll)) {
		return;
	}

	/* �擪��1���폜 */
	if (GetMenuItemCount(hMenu) > 1) {
		DeleteMenu(hMenu, 0, MF_BYPOSITION);
	}

	/* ���j���[�\���̏����� */
	memset(&mii, 0, sizeof(mii));
	mii.cbSize = 44;	/* sizeof(mii)��WINVER>=0x0500���� */
	mii.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
	mii.fType = MFT_STRING;
	mii.fState = MFS_ENABLED;

	/* ���� */
	mii.wID = IDM_LANGUAGE;
	LoadString(hResInstance, IDS_LANGUAGE, string, sizeof(string));
#if 1	/* V1.2L12/V2.9L52/V3.4L52�����̉��ݒ� */
	if (!strlen(string)) {
		strncpy(string, "&Japanese Mode", sizeof(string));
	}
#endif
	mii.dwTypeData = string;
	mii.cch = strlen(string);
	InsertMenuItem(hMenu, 0, TRUE, &mii);
}
#endif

/*-[ �R���e�L�X�g���j���[ ]-------------------------------------------------*/

#ifdef XM7DASH
/*
 *	���f�B�A�^�C�g���ύX(&T)
 */
static BOOL FASTCALL OnMediaChangeTitle(HWND hWnd, WORD wID)
{
	ASSERT(hWnd);

	if ((wID >= IDM_D0MEDIA00) && (wID <= IDM_D0MEDIA15)) {
#if XM7_VER == 1 && defined(SFDC)
		OnSetDiskTitle(hWnd, FDC_M, 0, wID - IDM_D0MEDIA00);
#else	/* XM7_VER == 1 && defined(SFDC) */
		OnSetDiskTitle(hWnd, 0, wID - IDM_D0MEDIA00);
#endif	/* XM7_VER == 1 && defined(SFDC) */
		return TRUE;
	}
	if ((wID >= IDM_D1MEDIA00) && (wID <= IDM_D1MEDIA15)) {
#if XM7_VER == 1 && defined(SFDC)
		OnSetDiskTitle(hWnd, FDC_M, 1, wID - IDM_D1MEDIA00);
#else	/* XM7_VER == 1 && defined(SFDC) */
		OnSetDiskTitle(hWnd, 1, wID - IDM_D1MEDIA00);
#endif	/* XM7_VER == 1 && defined(SFDC) */
		return TRUE;
	}
	if ((wID >= IDM_D2MEDIA00) && (wID <= IDM_D2MEDIA15)) {
#if XM7_VER == 1 && defined(SFDC)
		OnSetDiskTitle(hWnd, FDC_M, 2, wID - IDM_D2MEDIA00);
#else	/* XM7_VER == 1 && defined(SFDC) */
		OnSetDiskTitle(hWnd, 2, wID - IDM_D2MEDIA00);
#endif	/* XM7_VER == 1 && defined(SFDC) */
		return TRUE;
	}
	if ((wID >= IDM_D3MEDIA00) && (wID <= IDM_D3MEDIA15)) {
#if XM7_VER == 1 && defined(SFDC)
		OnSetDiskTitle(hWnd, FDC_M, 3, wID - IDM_D3MEDIA00);
#else	/* XM7_VER == 1 && defined(SFDC) */
		OnSetDiskTitle(hWnd, 3, wID - IDM_D3MEDIA00);
#endif	/* XM7_VER == 1 && defined(SFDC) */
		return TRUE;
	}
#if XM7_VER == 1 && defined(SFDC)
	if ((wID >= IDM_D4MEDIA00) && (wID <= IDM_D4MEDIA15)) {
		OnSetDiskTitle(hWnd, FDC_S, 0, wID - IDM_D4MEDIA00);
		return TRUE;
	}
	if ((wID >= IDM_D5MEDIA00) && (wID <= IDM_D5MEDIA15)) {
		OnSetDiskTitle(hWnd, FDC_S, 1, wID - IDM_D5MEDIA00);
		return TRUE;
	}
	if ((wID >= IDM_D6MEDIA00) && (wID <= IDM_D6MEDIA15)) {
		OnSetDiskTitle(hWnd, FDC_S, 2, wID - IDM_D6MEDIA00);
		return TRUE;
	}
	if ((wID >= IDM_D7MEDIA00) && (wID <= IDM_D7MEDIA15)) {
		OnSetDiskTitle(hWnd, FDC_S, 3, wID - IDM_D7MEDIA00);
		return TRUE;
	}
#endif	/* XM7_VER == 1 && defined(SFDC) */
#if XM7_VER == 1 && defined(BUBBLE)
	if ((wID >= IDM_B0MEDIA00) && (wID <= IDM_B0MEDIA15)) {
		OnSetBubbleTitle(hWnd, BMC_32, 0, wID - IDM_B0MEDIA00);
		return TRUE;
	}
	if ((wID >= IDM_B1MEDIA00) && (wID <= IDM_B1MEDIA15)) {
		OnSetBubbleTitle(hWnd, BMC_32, 1, wID - IDM_B1MEDIA00);
		return TRUE;
	}
	if ((wID >= IDM_B2MEDIA00) && (wID <= IDM_B2MEDIA15)) {
		OnSetBubbleTitle(hWnd, BMC_128, 0, wID - IDM_B2MEDIA00);
		return TRUE;
	}
	if ((wID >= IDM_B3MEDIA00) && (wID <= IDM_B3MEDIA15)) {
		OnSetBubbleTitle(hWnd, BMC_128, 1, wID - IDM_B3MEDIA00);
		return TRUE;
	}
#endif	/* XM7_VER == 1 && defined(BUBBLE) */

	return FALSE;
}

/*
 *	�q�X�g������폜(&D)
 */
static BOOL FASTCALL OnHistoryDelete(HWND hWnd, WORD wID)
{
	/* �q�X�g���E�N���b�N���j���[���� */
	if ((wID >= IDM_STATE_FILE0) && (wID <= IDM_STATE_FILE9)) {
		DeleteHistory(hWnd, wID);
		return TRUE;
	}
	if ((wID >= IDM_D3_FILE0) && (wID <= IDM_D0_FILE9)) {
		DeleteHistory(hWnd, wID);
		return TRUE;
	}
#if XM7_VER == 1 && defined(SFDC)
	if ((wID >= IDM_D7_FILE0) && (wID <= IDM_D4_FILE9)) {
		DeleteHistory(hWnd, wID);
		return TRUE;
	}
#endif	/* XM7_VER == 1 && defined(SFDC) */
	if ((wID >= IDM_T_FILE0) && (wID <= IDM_T_FILE9)) {
		DeleteHistory(hWnd, wID);
		return TRUE;
	}
#if XM7_VER == 1 && defined(BUBBLE)
	if ((wID >= IDM_B3_FILE0) && (wID <= IDM_B0_FILE9)) {
		DeleteHistory(hWnd, wID);
		return TRUE;
	}
#endif	/* XM7_VER == 1 && defined(BUBBLE) */

	return FALSE;
}

#ifdef FILTERDLL
/*
 *	�A�X�y�N�g��ݒ�(&A)
 */
static BOOL FASTCALL OnAspectSetting(HWND hWnd, WORD wID)
{
	/* �q�X�g���E�N���b�N���j���[���� */
	if (wID == IDM_ASPECTRATIO) {
		AspectSetting(hWnd, wID);
		return TRUE;
	}

	return FALSE;
}
#endif

/*
 *	�R���e�L�X�g���j���[����̌Ăяo��
 */
static BOOL FASTCALL OnSubMenu(HWND hWnd, WORD wID)
{
	switch (wID) {
		/* ���f�B�A�^�C�g���ύX(&T) */
		case IDM_MEDIATITLE:
			OnMediaChangeTitle(hWnd, wMenuID);
			return TRUE;

		/* �q�X�g������폜(&D) */
		case IDM_HISTORY_DELETE:
			OnHistoryDelete(hWnd, wMenuID);
			return TRUE;

#ifdef FILTERDLL
		/* �A�X�y�N�g��ݒ�(&A) */
		case IDM_ASPECTSETTING:
			OnAspectSetting(hWnd, wMenuID);
			return TRUE;
#endif
	}

	return FALSE;
}
#endif

/*-[ ���j���[�R�}���h���� ]-------------------------------------------------*/

/*
 *	���j���[�R�}���h����
 */
void FASTCALL OnCommand(HWND hWnd, WORD wID)
{
	ASSERT(hWnd);

	if (OnFile(hWnd, wID)) {
		return;
	}
	if (OnDisk(wID)) {
		return;
	}
	if (OnTape(wID)) {
		return;
	}
	if (OnView(hWnd, wID)) {
		return;
	}
	if (OnDebug(hWnd, wID)) {
		return;
	}
	if (OnTool(hWnd, wID)) {
		return;
	}
	if (OnWindow(wID)) {
		return;
	}
	if (OnHelp(hWnd, wID)) {
		return;
	}
#ifdef XM7DASH
	if (OnSubMenu(hWnd, wID)) {
		return;
	}
#endif
}

/*
 *	���j���[�R�}���h�X�V����
 */
void FASTCALL OnMenuPopup(HWND hWnd, HMENU hSubMenu, UINT uPos)
{
	HMENU hMenu;

	ASSERT(hWnd);
	ASSERT(hSubMenu);

	/* ���C�����j���[�̍X�V���`�F�b�N */
	hMenu = GetMenu(hWnd);
	if (GetSubMenu(hMenu, uPos) != hSubMenu) {
		return;
	}

	/* ���b�N���K�v */
	LockVM();

	switch (uPos) {
		/* �t�@�C�� */
#ifdef XM7DASH
		case FILE_MENU:
#else
		case 0:
#endif
			OnFilePopup(hSubMenu);
			break;

#ifdef XM7DASH
 #if XM7_VER == 1 && defined(SFDC)
		/* 1MB�f�B�X�N */
		case SFD_MENU:
			OnDiskPopup(hSubMenu, FDC_S);
			break;

		/* 320KB�f�B�X�N */
		case MFD_MENU:
			OnDiskPopup(hSubMenu, FDC_M);
			break;
 #else	/* XM7_VER == 1 && defined(SFDC) */
		/* �f�B�X�N */
		case MFD_MENU:
			OnDiskPopup(hSubMenu);
			break;
 #endif	/* XM7_VER == 1 && defined(SFDC) */
#else
		/* �h���C�u1 */
		case 1:
			OnDiskPopup(hSubMenu, 1);
			break;

		/* �h���C�u0 */
		case 2:
			OnDiskPopup(hSubMenu, 0);
			break;
#endif

#if XM7_VER == 1 && defined(BUBBLE) && defined(XM7DASH)
		/* �J�Z�b�g */
		case CASETTE_MENU:
			OnCassettePopup(hSubMenu);
			break;
#else	/* XM7_VER == 1 && defined(BUBBLE) && defined(XM7DASH) */
		/* �e�[�v */
#ifdef XM7DASH
		case TAPE_MENU:
#else
		case 3:
#endif
			OnTapePopup(hSubMenu);
			break;
#endif	/* XM7_VER == 1 && defined(BUBBLE) && defined(XM7DASH) */

		/* �\�� */
#ifdef XM7DASH
		case VIEW_MENU:
#else
		case 4:
#endif
			OnViewPopup(hSubMenu);
			break;

		/* �f�o�b�O */
#ifdef XM7DASH
		case DEBUG_MENU:
#else
		case 5:
#endif
			OnDebugPopup(hSubMenu);
			break;

		/* �c�[�� */
#ifdef XM7DASH
		case TOOL_MENU:
#else
		case 6:
#endif
			OnToolPopup(hSubMenu);
			break;

		/* �E�B���h�E */
#ifdef XM7DASH
		case WINDOW_MENU:
#else
		case 7:
#endif
			OnWindowPopup(hSubMenu);
			break;

#if defined(XM7DASH) && defined(RES_DLL)
		/* �w���v */
		case HELP_MENU:
			OnHelpPopup(hSubMenu);
			break;
#endif
	}

	/* �A�����b�N */
	UnlockVM();
}

#ifdef XM7DASH
/*
 *	�R���e�L�X�g���j���[����
 */
void FASTCALL OnContextualMenu(HWND hWnd, WORD wID, int x, int y)
{
	ASSERT(hWnd);

	if (OnFileContextualMenu(hWnd, wID, x, y)) {
		return;
	}
	if (OnDiskContextualMenu(hWnd, wID, x, y)) {
		return;
	}
	if (OnTapeContextualMenu(hWnd, wID, x, y)) {
		return;
	}
	if (OnViewContextualMenu(hWnd, wID, x, y)) {
		return;
	}
}
#endif

/*-[ �h���b�O���h���b�v�E�R�}���h���C������ ]-------------------------------*/

/*
 *	�t�@�C���h���b�v�T�u
 */
void FASTCALL OnDropSub(char *path)
{
	char dir[_MAX_DIR];
	char ext[_MAX_EXT];
	char InitDir[_MAX_DRIVE + _MAX_PATH];

	ASSERT(path);

	/* �g���q�������� */
	_splitpath(path, InitDir, dir, NULL, ext);
	strncat(InitDir, dir, sizeof(InitDir) - strlen(InitDir) - 1);

	/* D77 */
	if (stricmp(ext, ".D77") == 0) {
#ifdef XM7DASH
		strncpy(InitialDir[DISK_IMAGE_DIR], InitDir, sizeof(InitialDir[DISK_IMAGE_DIR]));
#else
		strncpy(InitialDir[0], InitDir, sizeof(InitDir));
#endif
		LockVM();
		StopSnd();
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		fdc_setdisk(FDC_M, 0, path);
		fdc_setdisk(FDC_M, 1, NULL);
		fdc_setdisk(FDC_M, 2, NULL);
		fdc_setdisk(FDC_M, 3, NULL);
		if (fdc_ready[FDC_M][0] != FDC_TYPE_NOTREADY) {
			if (fdc_medias[FDC_M][0] >= 2) {
				fdc_setdisk(FDC_M, 1, path);
				fdc_setmedia(FDC_M, 1, 1);
			}
			if ((boot_mode != BOOT_BASIC) &&
				(boot_mode != BOOT_DOS) &&
				(boot_mode != BOOT_BASIC_RAM)) {
				boot_mode = BOOT_BASIC;
			}
			system_reset();
			StatePath[0] = '\0';
			SetAllMRUFile();
		}
		if (sfdc_enable) {
			fdc_setdisk(FDC_S, 0, path);
			fdc_setdisk(FDC_S, 1, NULL);
			fdc_setdisk(FDC_S, 2, NULL);
			fdc_setdisk(FDC_S, 3, NULL);
			if (fdc_ready[FDC_S][0] != FDC_TYPE_NOTREADY) {
				if (fdc_medias[FDC_S][0] >= 2) {
					fdc_setdisk(FDC_S, 1, path);
					fdc_setmedia(FDC_S, 1, 1);
				}
				if (availableSFDBOOT) {
					if (boot_mode != BOOT_DOS_SFD) {
						boot_mode = BOOT_DOS_SFD;
					}
					system_reset();
					StatePath[0] = '\0';
					SetAllMRUFile();
				}
			}
		}
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		fdc_setdisk(0, path);
		fdc_setdisk(1, NULL);
#ifdef XM7DASH
		fdc_setdisk(2, NULL);
		fdc_setdisk(3, NULL);
#endif
		if ((fdc_ready[0] != FDC_TYPE_NOTREADY) && (fdc_medias[0] >= 2)) {
			fdc_setdisk(1, path);
			fdc_setmedia(1, 1);
		}
#if XM7_VER == 1 && defined(XM7DASH)
		if ((fdc_ready[0] != FDC_TYPE_NOTREADY) &&
			(boot_mode != BOOT_BASIC) &&
			(boot_mode != BOOT_DOS) &&
			(boot_mode != BOOT_BASIC_RAM)) {
			boot_mode = BOOT_BASIC;
		}
#endif	/* XM7_VER == 1 && defined(XM7DASH) */
		system_reset();
#ifdef XM7DASH
		StatePath[0] = '\0';
		SetAllMRUFile();
#endif
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		PlaySnd();
		ResetSch();
		UnlockVM();
	}

	/* 2D/2DD/VFD */
#if XM7_VER >= 3
	if ((stricmp(ext, ".2D") == 0) || (stricmp(ext, ".2DD") == 0) ||
		(stricmp(ext, ".VFD") == 0)) {
#else
	if ((stricmp(ext, ".2D") == 0) || (stricmp(ext, ".VFD") == 0)) {
#endif
#ifdef XM7DASH
		strncpy(InitialDir[DISK_IMAGE_DIR], InitDir, sizeof(InitialDir[DISK_IMAGE_DIR]));
#else
		strncpy(InitialDir[0], InitDir, sizeof(InitDir));
#endif
		LockVM();
		StopSnd();
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		fdc_setdisk(FDC_M, 0, path);
		fdc_setdisk(FDC_M, 1, NULL);
		fdc_setdisk(FDC_M, 2, NULL);
		fdc_setdisk(FDC_M, 3, NULL);
		if ((fdc_ready[FDC_M][0] != FDC_TYPE_NOTREADY) &&
			(boot_mode != BOOT_BASIC) &&
			(boot_mode != BOOT_DOS) &&
			(boot_mode != BOOT_BASIC_RAM)) {
			boot_mode = BOOT_BASIC;
		}
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		fdc_setdisk(0, path);
		fdc_setdisk(1, NULL);
#ifdef XM7DASH
		fdc_setdisk(2, NULL);
		fdc_setdisk(3, NULL);
#endif
#if XM7_VER == 1 && defined(XM7DASH)
		if ((fdc_ready[0] != FDC_TYPE_NOTREADY) &&
			(boot_mode != BOOT_BASIC) &&
			(boot_mode != BOOT_DOS) &&
			(boot_mode != BOOT_BASIC_RAM)) {
			boot_mode = BOOT_BASIC;
		}
#endif
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		system_reset();
#ifdef XM7DASH
		StatePath[0] = '\0';
		SetAllMRUFile();
#endif
		PlaySnd();
		ResetSch();
		UnlockVM();
	}

#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	if (sfdc_enable) {
		/* 2HD */
		if (stricmp(ext, ".2HD") == 0) {
#ifdef XM7DASH
			strncpy(InitialDir[DISK_IMAGE_DIR], InitDir, sizeof(InitialDir[DISK_IMAGE_DIR]));
#else
			strncpy(InitialDir[0], InitDir, sizeof(InitialDir[0]));
#endif
			LockVM();
			StopSnd();
			fdc_setdisk(FDC_S, 0, path);
			fdc_setdisk(FDC_S, 1, NULL);
			fdc_setdisk(FDC_S, 2, NULL);
			fdc_setdisk(FDC_S, 3, NULL);
			if ((fdc_ready[FDC_S][0] != FDC_TYPE_NOTREADY) &&
				(availableSFDBOOT)) {
				if (boot_mode != BOOT_DOS_SFD) {
					boot_mode = BOOT_DOS_SFD;
				}
				system_reset();
#ifdef XM7DASH
				StatePath[0] = '\0';
				SetAllMRUFile();
#endif
			}
			PlaySnd();
			ResetSch();
			UnlockVM();
		}
	}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */

	/* T77 */
	if (stricmp(ext, ".T77") == 0) {
#ifdef XM7DASH
		strncpy(InitialDir[TAPE_IMAGE_DIR], InitDir, sizeof(InitialDir[TAPE_IMAGE_DIR]));
#else
		strncpy(InitialDir[1], InitDir, sizeof(InitDir));
#endif
		LockVM();
		tape_setfile(path);
		UnlockVM();
	}

#if XM7_VER == 1 && defined(BUBBLE)
#ifdef XM7DASH
	if (bmc_enable[BMC_32] || bmc_enable[BMC_128]) {
		/* B77 */
		if (stricmp(ext, ".B77") == 0) {
#ifdef XM7DASH
			strncpy(InitialDir[BUBBLE_IMAGE_DIR], InitDir, sizeof(InitialDir[BUBBLE_IMAGE_DIR]));
#else
			strncpy(InitialDir[5], InitDir, sizeof(InitialDir[5]));
#endif
			LockVM();
			StopSnd();
			if (bmc_enable[BMC_32]) {
				bmc_setfile(BMC_32, 0, path);
				bmc_setfile(BMC_32, 1, NULL);
				if (bmc_ready[BMC_32][0] != BMC_TYPE_NOTREADY) {
					if (bmc_medias[BMC_32][0] >= 2) {
						bmc_setfile(BMC_32, 1, path);
						bmc_setmedia(BMC_32, 1, 1);
					}
					if (availableBBLBOOT) {
						if (boot_mode != BOOT_BUBBLE) {
							boot_mode = BOOT_BUBBLE;
							mainmem_bubblemode_boot();
						}
						system_reset();
#ifdef XM7DASH
						StatePath[0] = '\0';
						SetAllMRUFile();
#endif
					}
				}
			}
			if (bmc_enable[BMC_128]) {
				bmc_setfile(BMC_128, 0, path);
				bmc_setfile(BMC_128, 1, NULL);
				if (bmc_ready[BMC_128][0] != BMC_TYPE_NOTREADY) {
					if (bmc_medias[BMC_128][0] >= 2) {
						bmc_setfile(BMC_128, 1, path);
						bmc_setmedia(BMC_128, 1, 1);
					}
					if (availableBBLBOOT) {
						if (boot_mode != BOOT_BUBBLE128) {
							boot_mode = BOOT_BUBBLE128;
							mainmem_bubblemode_boot();
						}
						system_reset();
#ifdef XM7DASH
						StatePath[0] = '\0';
						SetAllMRUFile();
#endif
					}
				}
			}
			PlaySnd();
			ResetSch();
			UnlockVM();
		}

		/* BBL */
		if (stricmp(ext, ".BBL") == 0) {
#ifdef XM7DASH
			strncpy(InitialDir[BUBBLE_IMAGE_DIR], InitDir, sizeof(InitialDir[BUBBLE_IMAGE_DIR]));
#else
			strncpy(InitialDir[5], InitDir, sizeof(InitialDir[5]));
#endif
			LockVM();
			StopSnd();
			if (bmc_enable[BMC_32]) {
				bmc_setfile(BMC_32, 0, path);
				bmc_setfile(BMC_32, 1, NULL);
				if ((bmc_ready[BMC_32][0] != BMC_TYPE_NOTREADY) &&
					(availableBBLBOOT)) {
					if (boot_mode != BOOT_BUBBLE) {
						boot_mode = BOOT_BUBBLE;
						mainmem_bubblemode_boot();
					}
					system_reset();
#ifdef XM7DASH
					StatePath[0] = '\0';
					SetAllMRUFile();
#endif
				}
			}
			if (bmc_enable[BMC_128]) {
				bmc_setfile(BMC_128, 0, path);
				bmc_setfile(BMC_128, 1, NULL);
				if ((bmc_ready[BMC_128][0] != BMC_TYPE_NOTREADY) &&
					(availableBBLBOOT)) {
					if (boot_mode != BOOT_BUBBLE128) {
						boot_mode = BOOT_BUBBLE128;
						mainmem_bubblemode_boot();
					}
					system_reset();
#ifdef XM7DASH
					StatePath[0] = '\0';
					SetAllMRUFile();
#endif
				}
			}
			PlaySnd();
			ResetSch();
			UnlockVM();
		}
	}
#else
	if (bmc_enable) {
		/* B77 */
		if (stricmp(ext, ".B77") == 0) {
			strncpy(InitialDir[5], InitDir, sizeof(InitialDir[5]));
			LockVM();
			StopSnd();
			if (bmc_enable) {
				bmc_setfile(0, path);
				bmc_setfile(1, NULL);
				if (bmc_ready[0] != BMC_TYPE_NOTREADY) {
					if (bmc_medias[0] >= 2) {
						bmc_setfile(1, path);
						bmc_setmedia(1, 1);
					}
				}
			}
			PlaySnd();
			ResetSch();
			UnlockVM();
		}
	}

	/* BBL */
	if (stricmp(ext, ".BBL") == 0) {
		strncpy(InitialDir[5], InitDir, sizeof(InitDir));
		LockVM();
		bmc_setfile(0, path);
		bmc_setfile(1, NULL);
		UnlockVM();
	}
#endif
#endif

	/* XM7 */
	if (stricmp(ext, ".XM7") == 0) {
#ifdef XM7DASH
		strncpy(InitialDir[STATE_FILE_DIR], InitDir, sizeof(InitDir));
#else
		strncpy(InitialDir[2], InitDir, sizeof(InitDir));
#endif
		LockVM();
		StopSnd();
		StateLoad(path);
		GetCfg();
		PlaySnd();
		ResetSch();
		UnlockVM();
	}

	/* �\�����e���X�V */
	if (hDrawWnd) {
		InvalidateRect(hDrawWnd, NULL, FALSE);
	}
}

/*
 *	�X�e�[�^�X�o�[
 *	�t�@�C���h���b�v�T�u
 */
void FASTCALL OnBarDropSub(char *path, POINT point)
{
	char dir[_MAX_DIR];
	char ext[_MAX_EXT];
	char InitDir[_MAX_DRIVE + _MAX_PATH];
	int drive;
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	int type;
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */

	ASSERT(path);

	/* �g���q�������� */
	_splitpath(path, InitDir, dir, NULL, ext);
	strncat(InitDir, dir, sizeof(InitDir) - strlen(InitDir) - 1);

	/* �f�B�X�N�C���[�W */
#ifdef XM7DASH
 #if XM7_VER == 1 && defined(SFDC)
	if ((point.x >= uPaneX[0]) && (point.x < uPaneX[8])) {
		/* �h���C�u���� */
		if (point.x >= uPaneX[7]) {
			type = FDC_M;
			drive = 0;
		}
		else if (point.x >= uPaneX[6]) {
			type = FDC_M;
			drive = 1;
		}
		else if (point.x >= uPaneX[5]) {
			type = FDC_M;
			drive = 2;
		}
		else if (point.x >= uPaneX[4]) {
			type = FDC_M;
			drive = 3;
		}
		else if (point.x >= uPaneX[3]) {
			type = FDC_S;
			drive = 0;
		}
		else if (point.x >= uPaneX[2]) {
			type = FDC_S;
			drive = 1;
		}
		else if (point.x >= uPaneX[1]) {
			type = FDC_S;
			drive = 2;
		}
		else {
			type = FDC_S;
			drive = 3;
		}
		if (type == FDC_S && !sfdc_enable) {
			OnDropSub(path);
			return;
		}
 #else	/* XM7_VER == 1 && defined(SFDC) */
	if ((point.x >= uPaneX[0]) && (point.x < uPaneX[4])) {
		/* �h���C�u���� */
		if (point.x >= uPaneX[3]) {
			drive = 0;
		}
		else if (point.x >= uPaneX[2]) {
			drive = 1;
		}
		else if (point.x >= uPaneX[1]) {
			drive = 2;
		}
		else {
			drive = 3;
		}
 #endif	/* XM7_VER == 1 && defined(SFDC) */
#else
	if ((point.x >= uPaneX[0]) && (point.x < uPaneX[2])) {
		/* �h���C�u���� */
		if (point.x >= uPaneX[1]) {
			drive = 0;
		}
		else {
			drive = 1;
		}
#endif

		/* D77 */
		if (stricmp(ext, ".D77") == 0) {
#ifdef XM7DASH
			strncpy(InitialDir[DISK_IMAGE_DIR], InitDir, sizeof(InitDir));
#else
			strncpy(InitialDir[0], InitDir, sizeof(InitDir));
#endif
			LockVM();
			StopSnd();
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
			fdc_setdisk(type, drive, path);
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
			fdc_setdisk(drive, path);
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
			PlaySnd();
			ResetSch();
			UnlockVM();
			return;
		}

		/* 2D/2DD/2HD/VFD */
#if XM7_VER >= 3
		if ((stricmp(ext, ".2D") == 0) || (stricmp(ext, ".2DD") == 0) ||
			(stricmp(ext, ".VFD") == 0)) {
#elif XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		if ((stricmp(ext, ".2D") == 0) || (stricmp(ext, ".2HD") == 0) ||
			(stricmp(ext, ".VFD") == 0)) {
#else
		if ((stricmp(ext, ".2D") == 0) || (stricmp(ext, ".VFD") == 0)) {
#endif
#ifdef XM7DASH
			strncpy(InitialDir[DISK_IMAGE_DIR], InitDir, sizeof(InitDir));
#else
			strncpy(InitialDir[0], InitDir, sizeof(InitDir));
#endif
			LockVM();
			StopSnd();
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
			fdc_setdisk(type, drive, path);
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
			fdc_setdisk(drive, path);
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
			PlaySnd();
			ResetSch();
			UnlockVM();
			return;
		}
	}

	/* �f�B�X�N�C���[�W�ȊO�E�͈͊O */
	OnDropSub(path);
}

/*
 *	�t�@�C���h���b�v
 */
void FASTCALL OnDropFiles(HANDLE hDrop)
{
	char path[_MAX_PATH];
	POINT point;
	POINT spoint;
	HWND hwnd;

	ASSERT(hDrop);

	/* �t�@�C�����󂯎�� */
	DragQueryPoint(hDrop, &point);
	DragQueryFile(hDrop, 0, path, sizeof(path));
	DragFinish(hDrop);

	/* ���� */
	spoint = point;
	ClientToScreen(hMainWnd, &spoint);
	hwnd = WindowFromPoint(spoint);
	if (hwnd == hStatusBar) {
		/* �X�e�[�^�X�o�[��ւ̃h���b�v */
		OnBarDropSub(path, point);
	}
	else {
		/* �h���[�E�B���h�E���ւ̃h���b�v�͏]������ */
		OnDropSub(path);
	}

#ifdef XM7DASH
	LockVM();
	SetAllMRUFile();
	UnlockVM();
#endif
}

/*
 *	�R�}���h���C������
 */
void FASTCALL OnCmdLine(LPSTR lpCmdLine)
{
	char dir[_MAX_DIR];
	char ext[_MAX_EXT];
	char path[_MAX_PATH];
	char fullpath[_MAX_PATH];
	char d77_path[_MAX_PATH];
	char InitDir[_MAX_PATH];
	LPSTR p;
	LPSTR q;
	BOOL flag;
	int drive;
#if XM7_VER == 1 && defined(XM7DASH)
 #ifdef SFDC
	int sdrive;
 #endif
 #ifdef BUBBLE
	char bbl_path[_MAX_PATH];
	int unit1, unit2;
 #endif
	BOOL boot;
#elif XM7_VER == 1 && defined(BUBBLE)
	int unit;
	char bbl_path[_MAX_PATH];
#endif
	BOOL tape_set;

	ASSERT(lpCmdLine);

	/* ���[�N������ */
	drive = 0;
#if XM7_VER == 1 && defined(XM7DASH)
 #ifdef SFDC
	sdrive = 0;
 #endif
 #ifdef BUBBLE
	unit1 = unit2 = 0;
 #endif
	boot = FALSE;
#elif XM7_VER == 1 && defined(BUBBLE)
	unit = 0;
#endif
	tape_set = FALSE;
	d77_path[0] = '\0';
#if XM7_VER == 1 && defined(BUBBLE) && defined(XM7DASH)
	bbl_path[0] = '\0';
#endif

	/* �t�@�C�������X�L�b�v */
	p = lpCmdLine;
	flag = FALSE;
	for (;;) {
		/* �I���`�F�b�N */
		if (*p == '\0') {
			return;
		}

		/* �N�H�[�g�`�F�b�N */
		if (*p == '"') {
			flag = !flag;
		}

		/* �X�y�[�X�`�F�b�N */
		if ((*p == ' ') && !flag) {
			break;
		}

		/* ���� */
		p++;
	}

	/* VM�����b�N */
	LockVM();
	StopSnd();

	/* �R�}���h���C���I�v�V�������I���܂Ń��[�v */
	while (*p) {
		path[0] = '\0';

		/* �X�y�[�X��ǂݔ�΂� */
		for (;;) {
			if (*p != ' ') {
				break;
			}

			/* ���� */
			p++;
		}

		if (*p == '"') {
			/* �N�H�[�g�`�F�b�N */
			p++;
			q = path;

			/* �N�H�[�g���o��܂ő����� */
			for (;;) {
				*q = *p++;

				/* �N�H�[�g���I���`�F�b�N */
				if (*q == '\0') {
					path[0] = '\0';
					break;
				}

				/* �N�H�[�g�`�F�b�N */
				if (*q == '"') {
					*q = '\0';
					break;
				}

				/* ���� */
				q++;
			}
		}
		else if (*p) {
			/* �N�H�[�g�Ȃ� */
			q = path;

			/* �X�y�[�X���o�邩�����񂪏I������܂ő����� */
			for (;;) {
				*q = *p++;

				/* ��؂蕶���`�F�b�N */
				if ((*q == '\0') || (*q == ' ')) {
					*q = '\0';
					break;
				}

				/* ���� */
				q++;
			}
		}

		/* �I���`�F�b�N */
		if (!path[0]) {
			break;
		}

		/* �t���p�X�𐶐� */
		_fullpath(fullpath, path, _MAX_PATH);

		/* �g���q�������� */
		_splitpath(fullpath, InitDir, dir, NULL, ext);
		strncat(InitDir, dir, sizeof(InitDir) - strlen(InitDir) - 1);

		/* D77/2D/2DD/VFD */
#if XM7_VER >= 3
		if ((stricmp(ext, ".D77") == 0) || (stricmp(ext, ".VFD") == 0) ||
			(stricmp(ext, ".2D") == 0) || (stricmp(ext, ".2DD") == 0)) {
#elif XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		if ((stricmp(ext, ".D77") == 0) || (stricmp(ext, ".VFD") == 0) ||
			(stricmp(ext, ".2D") == 0) || (stricmp(ext, ".2HD") == 0)) {
#else
		if ((stricmp(ext, ".D77") == 0) || (stricmp(ext, ".VFD") == 0) ||
			(stricmp(ext, ".2D") == 0)) {
#endif

#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
			if (drive == 0 && sdrive == 0) {
				/* 1���ڂ̏ꍇ�A�����p�X��ۑ� */
				strncpy(InitialDir[DISK_IMAGE_DIR], InitDir, sizeof(InitialDir[DISK_IMAGE_DIR]));

				/* D77��1�����w�肵���ꍇ�̂��߂Ƀt�@�C������ۑ� */
				if (stricmp(ext, ".D77") == 0) {
					strncpy(d77_path, fullpath, sizeof(d77_path));
				}

#ifdef XM7DASH
				/* 320KB/1MB���Ƀh���C�u0�`3�̃}�E���g������ */
				fdc_setdisk(FDC_M, 0, NULL);
				fdc_setdisk(FDC_M, 1, NULL);
				fdc_setdisk(FDC_M, 2, NULL);
				fdc_setdisk(FDC_M, 3, NULL);
				fdc_setdisk(FDC_S, 0, NULL);
				fdc_setdisk(FDC_S, 1, NULL);
				fdc_setdisk(FDC_S, 2, NULL);
				fdc_setdisk(FDC_S, 3, NULL);
#endif
			}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */

#ifdef XM7DASH
			/* 4���܂Ń}�E���g�\ */
 #if XM7_VER == 1 && defined(SFDC)
			if (drive < 4 && stricmp(ext, ".2HD") != 0) {
 #else	/* XM7_VER == 1 && defined(SFDC) */
			if (drive < 4) {
 #endif	/* XM7_VER == 1 && defined(SFDC) */
#else
			/* 2���܂Ń}�E���g�\ */
			if (drive < 2) {
#endif
#if !(XM7_VER == 1 && defined(SFDC) && defined(XM7DASH))
				if (drive == 0) {
					/* 1���ڂ̏ꍇ�A�����p�X��ۑ� */
#ifdef XM7DASH
					strncpy(InitialDir[DISK_IMAGE_DIR], InitDir, sizeof(InitDir));
#else
					strncpy(InitialDir[0], InitDir, sizeof(InitDir));
#endif

					/* D77��1�����w�肵���ꍇ�̂��߂Ƀt�@�C������ۑ� */
					if (stricmp(ext, ".D77") == 0) {
						strncpy(d77_path, fullpath, sizeof(d77_path));
					}
#ifdef XM7DASH
					/* �h���C�u0�`3�̃}�E���g������ */
					fdc_setdisk(0, NULL);
					fdc_setdisk(1, NULL);
					fdc_setdisk(2, NULL);
					fdc_setdisk(3, NULL);
#endif
				}
#endif	/* !(XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)) */

#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
				/* �f�B�X�N���}�E���g���� */
				fdc_setdisk(FDC_M, drive, fullpath);

				/* �}�E���g�����Ȃ�h���C�u�ԍ�(=�}�E���g����)��+1 */
				if (fdc_ready[FDC_M][drive] != FDC_TYPE_NOTREADY) {
					drive ++;
					if (drive == 1 && !boot &&
						boot_mode != BOOT_BASIC &&
						boot_mode != BOOT_DOS &&
						boot_mode != BOOT_BASIC_RAM) {
						boot_mode = BOOT_BASIC;
					}
					boot = TRUE;
				}
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
				/* �f�B�X�N���}�E���g���� */
				fdc_setdisk(drive, fullpath);

				/* �}�E���g�����Ȃ�h���C�u�ԍ�(=�}�E���g����)��+1 */
				if (fdc_ready[drive] != FDC_TYPE_NOTREADY) {
					drive ++;
#if XM7_VER == 1 && defined(XM7DASH)
					if (drive == 1 && !boot &&
						boot_mode != BOOT_BASIC &&
						boot_mode != BOOT_DOS &&
						boot_mode != BOOT_BASIC_RAM) {
						boot_mode = BOOT_BASIC;
					}
					boot = TRUE;
#endif	/* XM7_VER == 1 && defined(XM7DASH) */
				}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
			}

#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
			/* 4���܂Ń}�E���g�\ */
			if (sdrive < 4 && sfdc_enable &&
				stricmp(ext, ".VFD") != 0 && stricmp(ext, ".2D") != 0) {
				/* �f�B�X�N���}�E���g���� */
				fdc_setdisk(FDC_S, sdrive, fullpath);

				/* �}�E���g�����Ȃ�h���C�u�ԍ�(=�}�E���g����)��+1 */
				if (fdc_ready[FDC_S][sdrive] != FDC_TYPE_NOTREADY) {
					sdrive ++;
					if ((sdrive == 1) && !boot && (availableSFDBOOT)) {
						boot_mode = BOOT_DOS_SFD;
						boot = TRUE;
					}
				}
			}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
		}

		/* T77 */
		if (stricmp(ext, ".T77") == 0) {
			/* �L���Ȃ̂�1�̂� */
			if (!tape_set) {
				/* �����p�X��ۑ� */
#ifdef XM7DASH
				strncpy(InitialDir[TAPE_IMAGE_DIR], InitDir, sizeof(InitDir));
#else
				strncpy(InitialDir[1], InitDir, sizeof(InitDir));
#endif

				/* �e�[�v���}�E���g */
				tape_setfile(fullpath);

				/* �}�E���g�����Ȃ�e�[�v�}�E���g�֎~�t���O�𗧂Ă� */
				if (tape_fileh != -1) {
					tape_set = TRUE;
				}
			}
		}

#if XM7_VER == 1 && defined(BUBBLE)
#ifdef XM7DASH
		/* B77/BBL */
		if (((stricmp(ext, ".B77") == 0) || (stricmp(ext, ".BBL") == 0)) &&
			(bmc_enable[BMC_32] || bmc_enable[BMC_128])) {

			if (unit1 == 0 && unit2 == 0) {
				/* 1�ڂ̏ꍇ�A�����p�X��ۑ� */
				strncpy(InitialDir[BUBBLE_IMAGE_DIR], InitDir, sizeof(InitialDir[BUBBLE_IMAGE_DIR]));

				/* 1�����w�肵���ꍇ�̂��߂Ƀt�@�C������ۑ� */
				if (stricmp(ext, ".BBL") == 0) {
					strncpy(bbl_path, fullpath, sizeof(bbl_path));
				}

				/* 32KB/128KB���Ƀ��j�b�g1�̃}�E���g������ */
				bmc_setfile(BMC_32, 0, NULL);
				bmc_setfile(BMC_32, 1, NULL);
				bmc_setfile(BMC_128, 0, NULL);
				bmc_setfile(BMC_128, 1, NULL);
			}

			/* 2�܂Ń}�E���g�\ */
			if (unit1 < 2 && bmc_enable[BMC_32]) {
				/* �o�u���J�Z�b�g���}�E���g���� */
				bmc_setfile(BMC_32, unit1, fullpath);

				/* �}�E���g�����Ȃ烆�j�b�g�ԍ�(=�}�E���g��)��+1 */
				if (bmc_ready[BMC_32][unit1] != BMC_TYPE_NOTREADY) {
					unit1 ++;
					if ((unit1 == 1) && !boot && (availableBBLBOOT)) {
						if (boot_mode != BOOT_BUBBLE) {
							boot_mode = BOOT_BUBBLE;
							mainmem_bubblemode_boot();
						}
						boot = TRUE;
					}
				}
			}

			/* 2�܂Ń}�E���g�\ */
			if (unit2 < 2 && bmc_enable[BMC_128]) {
				/* �o�u���J�Z�b�g���}�E���g���� */
				bmc_setfile(BMC_128, unit2, fullpath);

				if (bmc_ready[BMC_128][unit2] != BMC_TYPE_NOTREADY) {
					unit2 ++;
					if ((unit2 == 1) && !boot && (availableBBLBOOT)) {
						if (boot_mode != BOOT_BUBBLE128) {
							boot_mode = BOOT_BUBBLE128;
							mainmem_bubblemode_boot();
						}
						boot = TRUE;
					}
				}
			}
		}
#else
		/* B77/BBL */
		if (((stricmp(ext, ".B77") == 0) || (stricmp(ext, ".BBL") == 0)) &&
			bmc_enable) {

			if (unit == 0) {
				/* 1�ڂ̏ꍇ�A�����p�X��ۑ� */
				strncpy(InitialDir[5], InitDir, sizeof(InitialDir[5]));

				/* BBL��1�����w�肵���ꍇ�̂��߂Ƀt�@�C������ۑ� */
				if (stricmp(ext, ".BBL") == 0) {
					strncpy(bbl_path, fullpath, sizeof(bbl_path));
				}

				/* ���j�b�g1�̃}�E���g������ */
				bmc_setfile(0, NULL);
				bmc_setfile(1, NULL);
			}

			/* 2�܂Ń}�E���g�\ */
			if (unit < 2 && bmc_enable) {
				/* �o�u���J�Z�b�g���}�E���g���� */
				bmc_setfile(unit, path);

				/* �}�E���g�����Ȃ烆�j�b�g�ԍ�(=�}�E���g��)��+1 */
				if (bmc_ready[unit] != BMC_TYPE_NOTREADY) {
					unit ++;
				}
			}
		}
#endif
#endif

		/* XM7 */
		if (stricmp(ext, ".XM7") == 0) {
#ifdef XM7DASH
			strncpy(InitialDir[STATE_FILE_DIR], InitDir, sizeof(InitialDir[STATE_FILE_DIR]));
#else
			strncpy(InitialDir[2], InitDir, sizeof(InitDir));
#endif
			StateLoad(fullpath);
			GetCfg();

			/* �X�e�[�g���[�h���Ƀ}�E���g���s����̂ŏ�����ł��؂� */
			drive = 0;
#if XM7_VER == 1 && defined(XM7DASH)
 #ifdef SFDC
			sdrive = 0;
 #endif
			boot = FALSE;
#elif XM7_VER == 1 && defined(BUBBLE)
			unit = 0;
#endif
			break;
		}
	}

	/* �f�B�X�N�C���[�W�t�@�C���w�萔��1�̏ꍇ�̓��ꏈ�� */
	if (drive == 1) {
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
		/* D77�̏ꍇ�A2���ڂ�����΃h���C�u1�Ƀ}�E���g */
		if (d77_path[0]) {
			if ((fdc_ready[FDC_M][0] != FDC_TYPE_NOTREADY) && (fdc_medias[FDC_M][0] >= 2)) {
				fdc_setdisk(FDC_M, 1, d77_path);
				fdc_setmedia(FDC_M, 1, 1);
			}
		}
#else	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
#ifndef XM7DASH
		/* �h���C�u1�̃}�E���g������ */
		fdc_setdisk(1, NULL);
#endif

		/* D77�̏ꍇ�A2���ڂ�����΃h���C�u1�Ƀ}�E���g */
		if (d77_path[0]) {
			if ((fdc_ready[0] != FDC_TYPE_NOTREADY) && (fdc_medias[0] >= 2)) {
				fdc_setdisk(1, d77_path);
				fdc_setmedia(1, 1);
			}
		}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */
	}
#if XM7_VER == 1 && defined(SFDC) && defined(XM7DASH)
	if (sdrive == 1) {
		/* D77�̏ꍇ�A2���ڂ�����΃h���C�u1�Ƀ}�E���g */
		if (d77_path[0]) {
			if ((fdc_ready[FDC_S][0] != FDC_TYPE_NOTREADY) && (fdc_medias[FDC_S][0] >= 2)) {
				fdc_setdisk(FDC_S, 1, d77_path);
				fdc_setmedia(FDC_S, 1, 1);
			}
		}
	}
#endif	/* XM7_VER == 1 && defined(SFDC) && defined(XM7DASH) */

#if XM7_VER == 1 && defined(BUBBLE)
	/* �o�u���C���[�W�t�@�C���w�萔��1�̏ꍇ�̓��ꏈ�� */
#ifdef XM7DASH
	if (unit1 == 1) {
		/* B77�̏ꍇ�A2���ڂ�����΃h���C�u1�Ƀ}�E���g */
		if (bbl_path[0]) {
			if ((bmc_ready[BMC_32][0] != BMC_TYPE_NOTREADY) && (bmc_medias[BMC_32][0] >= 2)) {
				bmc_setfile(BMC_32, 1, bbl_path);
				bmc_setmedia(BMC_32, 1, 1);
			}
		}
	}
	if (unit2 == 1) {
		/* B77�̏ꍇ�A2���ڂ�����΃h���C�u1�Ƀ}�E���g */
		if (bbl_path[0]) {
			if ((bmc_ready[BMC_128][0] != BMC_TYPE_NOTREADY) && (bmc_medias[BMC_128][0] >= 2)) {
				bmc_setfile(BMC_128, 1, bbl_path);
				bmc_setmedia(BMC_128, 1, 1);
			}
		}
	}
#else
	if (unit == 1) {
		/* B77�̏ꍇ�A2���ڂ�����΃h���C�u1�Ƀ}�E���g */
		if (bbl_path[0]) {
			if ((bmc_ready[0] != BMC_TYPE_NOTREADY) && (bmc_medias[0] >= 2)) {
				bmc_setfile(1, bbl_path);
				bmc_setmedia(1, 1);
			}
		}
	}
#endif
#endif

#if XM7_VER == 1 && defined(XM7DASH)
	/* �u�[�g�\�ȃC���[�W���}�E���g���ꂽ�ꍇ�AVM���Z�b�g */
	if (boot) {
#else	/* XM7_VER == 1 && defined(XM7DASH) */
	/* �f�B�X�N�C���[�W���}�E���g���ꂽ�ꍇ�AVM���Z�b�g */
	if (drive >= 1) {
#endif	/* XM7_VER == 1 && defined(XM7DASH) */
		system_reset();
#ifdef XM7DASH
		StatePath[0] = '\0';
		SetAllMRUFile();
#endif
	}

#ifdef XM7DASH
	SetAllMRUFile();
#endif

	/* VM���A�����b�N */
	PlaySnd();
	ResetSch();
	UnlockVM();

	/* �\�����e���X�V */
	if (hDrawWnd) {
		InvalidateRect(hDrawWnd, NULL, FALSE);
	}
}
#endif	/* _WIN32 */
