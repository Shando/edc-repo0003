#ifndef PROCESSOR_HPP
#define PROCESSOR_HPP

#include <emulator/emulator.hpp>

#endif
