string disassemble_arm_instruction(uint32 pc);
string disassemble_thumb_instruction(uint32 pc);
string disassemble_registers();
