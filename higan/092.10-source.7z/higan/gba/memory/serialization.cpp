void Bus::serialize(serializer& s) {
  s.integer(idleflag);
}
