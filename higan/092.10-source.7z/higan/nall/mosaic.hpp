#ifndef NALL_MOSAIC_HPP
#define NALL_MOSAIC_HPP

#define NALL_MOSAIC_INTERNAL_HPP
#include <nall/mosaic/bitstream.hpp>
#include <nall/mosaic/context.hpp>
#include <nall/mosaic/parser.hpp>
#undef NALL_MOSAIC_INTERNAL_HPP

#endif
