string BsxSatellaview = R"(

database revision=2013-01-22

release
  cartridge
    rom name=program.rom size=0x80000 type=MaskROM
  information
    title:    鮫亀 キャラカセット
    name:     Same Game - Character Cassette
    region:   JP
    revision: 1.0
    board:    BSMC-CR-01
    serial:   BSMC-ZS5J-JPN
    sha256:   80c34b50817d58820bc8c88d2d9fa462550b4a76372e19c6467cbfbc8cf5d9ef
    configuration
      rom name=program.rom size=0x80000 type=MaskROM

)";
