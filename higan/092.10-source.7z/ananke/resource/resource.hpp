namespace resource {
  extern const uint8_t home[606];
  extern const uint8_t up[652];
  extern const uint8_t folder[1176];
  extern const uint8_t file[844];
  extern const uint8_t archive[1067];
};
