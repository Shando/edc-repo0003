
This is a short, simple program which checksums various ranges of memory,
and uses the checksum to try to identify the system.  Right now, it can
distinguish between Inty 1, Inty 2 and Sears SVA.  It can also determine
if an ECS is attached.
