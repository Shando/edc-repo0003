This demo illustrates bankswitching.  See the source for details.

