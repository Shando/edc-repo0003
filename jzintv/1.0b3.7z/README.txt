============================================================================
 jzIntv  -- Joe Zbiciak's Intellivision Emulator for Linux
============================================================================

Welcome to jzIntv.  


Important Info
--------------

 jzintv homepage:   http://spatula-city.org/~im14u2c/intv
 Documentation:     Look under jzintv/doc and jzintv/doc/jzintv
 Author:            Joe Zbiciak (intvnut AT gmail.com)
 Credits:           Lots and lots.  See the home page!

Quick Start
-----------

Run 'jzintv --help' to get usage information.  You'll need an EXEC image,
a GROM image, and a GAME image in order to do anything.  You can use
the stock "exec.bin," "grom.bin" and game ROM images that come with the
Intellivision Lives! CD.

Documentation
-------------

The 'jzintv/doc' directory contains all the documentation I have to
share at the moment.


Binaries
--------

You don't have any?  Go buy an Intellivision Lives! CD, you cheapskate!
Go get it at http://www.intellivisionlives.com/ , ok?  Either that,
or build a ROM dumper.  In any case, I'm not going to encourage ROM 
piracy.

