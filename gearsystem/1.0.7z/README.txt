
Gearsystem (https://github.com/drhelius/Gearsystem)

-----------------------------------------------------

Copyright � 2013 by Ignacio Sanchez

-----------------------------------------------------

Gearsystem is a Sega Master System / Game Gear emulator written in C++ that runs on iOS, Raspberry Pi, Mac, Windows and Linux.

The main focus of this emulator is readability of source code with very high compatibility.

-----------------------------------------------------

Features

    - Highly accurate Z80 core.
    - Multi-Mapper support: SEGA, Codemasters, and ROM only cartridges.
    - External RAM support with save files.
    - Automatic region detection: NTSC-JAP, NTSC-USA, PAL-EUR.
    - SMS2 only 224 mode support.
    - Internal database for rom detection.
    - Sound emulation using SDL Audio and Sms_Snd_Emu library.
    - Integrated disassembler. It can dump the full disassembled memory to a text file or access it in real time.
    - Compressed rom support (ZIP deflate).
    - Multi platform. Runs on Windows, Linux, Mac OS X, Raspberry Pi and iOS.

-----------------------------------------------------

License


Gearsystem - Sega Master System / Game Gear Emulator

Copyright (C) 2013 Ignacio Sanchez

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses/