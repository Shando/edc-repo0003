Hatari for Windows was built using the mingw32 version of the gcc compiler,
using the following libraries (those dll were also built with mingw32-gcc) :

SDL.dll			version 1.2.15
http://www.libsdl.org/download-1.2.php

libpng-3.dll		version 1.6.3
http://sourceforge.net/projects/libpng/

readline.dll		version 6.3.3
http://www.gnu.org/s/readline/

libtermcap-0.dll	version 1.3.1
http://ftp.gnu.org/gnu/termcap/

zlib1.dll		version 1.2.8
http://zlib.net/

capsimg.dll		version 5.1
http://softpres.org/download/

