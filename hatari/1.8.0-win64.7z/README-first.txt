

                           Hatari binary for Windows

                                 Version 1.8.0

                           http://hatari.berlios.de/


This is a binary release of Hatari for Windows. Hatari is an Atari ST,
STE, TT and Falcon emulator with a focus on high compatibility.
This binary has not been tested very well - so feel free to report
problems if you find any. Please refer to the files in the "doc"
subdirectory for more information about Hatari in general.

With Hatari 1.8.0, 2 binaries are distributed :

 - hatari.exe is the most compatible version, to be used for STF/STE emulation
   for all your games/demos.
 - hatari_falcon.exe is an experimental version using a new cpu emulation
   that adds better support for 68030 and DSP. In most cases, it should give
   better results that hatari.exe if you want to run Falcon's programs. But it's
   still work in progress, so some programs will not run correctly yet.

This binary release ships with EmuTOS (the file "tos.img"). EmuTOS is
an open source TOS clone licensed under the GPL. Please visit the
official EmuTOS page (http://emutos.sourceforge.net/) for more
information and for obtaining versions in other languages or the
source code.
However, if you want to play games or watch demos, you should better
use an original TOS ROM image since many games and demos do not work
very well with EmuTOS yet.
