(c) 1999, TILE Technology, edward.patel@tiletech.e.se

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
See the GNU General Public License for more details.

This is an emulator of a Jupiter ACE from 1983. The Jupiter ACE 
is the real *outsider* micro from the 80's. Instead of having
BASIC as the programming language it had FORTH. It was designed
by two guys who had worked at Sinclair Research Ltd and was
responsible for the famous Sinclair ZX81 and ZX Spectrum. 
They are Steven Vickers and Richard Altwasser.
For a FAQ (1999) see http://users.aol.com/autismuk/ace/faq.htm

Turn it around, press on its keys and have a go at some
forth. Try also to load the 'tapes', i.e "load frogger" then "run".

It was also made with the help of VisKit, a 3D API.
VisKit is available from http://www.viskit.com

The ROM?
The distribution includes a copy of the Jupiter ACE ROM image. 
AFAIK there are no problems with this - I have asked Boldfield 
Computing if they mind it being here and I the answer can be 
found in boldcomp.txt, they also offer some original ACE tapes.
http://members.aol.com/boldcomp/page.htm 

Have fun!
