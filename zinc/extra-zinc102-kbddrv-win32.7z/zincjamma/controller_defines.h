/***************************************************************************
 file:			controller_defines.h
 description:	definitions of jamma controller specific stuff
 copyright:		(C)1997-2002 Drunken Muppets (www.impactemu.com)
****************************************************************************/

#ifndef _CONTROLLER_DEFINES_H
#define _CONTROLLER_DEFINES_H

typedef struct
{
	unsigned long	controls;
	unsigned long	players[4];
	unsigned long	reserved[10];
} jamma_t;

#define JAMMA_CTRL_COIN1	0x10
#define	JAMMA_CTRL_COIN2	0x20
#define JAMMA_CTRL_COIN3	0x40
#define JAMMA_CTRL_COIN4	0x80
#define JAMMA_CTRL_TEST		0x01
#define JAMMA_CTRL_SERVICE	0x02



#endif // _CONTROLLER_DEFINES_H